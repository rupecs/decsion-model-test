"""Reproducible local bootstrap CLI. Does not call an external teacher or GPU."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from .schemas import ROOT, read_yaml, validate, questions, load_rows
from .coverage_planner import plan, apportion
from .generator import generate, GENERATOR_VERSION
from .splitter import split, assert_disjoint
from .clef_converter import convert
from .coverage_report import report


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, data):
    Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')


def write_jsonl(path, rows):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    temp.replace(path)


def sample_reference(rows, output):
    selected=[]
    for cls in ('factual_information','general_advice','personal_advice'):
        candidates=[r for r in rows if r['labels']['D6']==cls and r['metadata']['conversation_type']=='single']
        preferred_category = {'factual_information':'C02','general_advice':'C08','personal_advice':'C03'}[cls]
        candidates = [r for r in candidates if r['metadata']['call_category']==preferred_category] or candidates
        if cls == 'factual_information':
            candidates = [r for r in candidates if r['labels']['D1'] and not r['metadata']['contrastive']] or candidates
        candidates = [r for r in candidates if not r['metadata']['disclaimer'] and not r['metadata']['asr_imperfections']] or candidates
        if cls == 'personal_advice':
            candidates=[r for r in candidates if not r['labels']['D3'] and r['labels']['D4']] or candidates
        if candidates: selected.append(candidates[0])
    write_json(output/'reference_examples.json',{'questions':questions(),'examples':selected})
    lines=['# Three reference examples', '', 'The six shared questions apply to every example.', '', '| Decision | Question |', '|---|---|']
    lines.extend(f"| {key} | {q['instructions']} |" for key,q in questions().items())
    for i,r in enumerate(selected,1):
        lines.extend(['',f"## Example {i}: {r['labels']['D6']}",'',f"Customer: {r['customer_context']}",'',f"Agent: {r['agent_response']}",'','```json',json.dumps(r['labels'],indent=2),'```'])
    lines.extend(['','Synthetic bootstrap labels, not independently reviewed.',''])
    (output/'reference_examples.md').write_text('\n'.join(lines))


def legacy_run(config, distribution, output, total, seed, resume=False, dry_run=False):
    if total < 4:
        raise ValueError('At least four records required for four splits')
    config_path,dist_path=Path(config),Path(distribution)
    cfg=read_yaml(config_path); dist=read_yaml(dist_path)
    tax_path=ROOT/'config/dataset/call_taxonomy.yaml'
    taxonomy=read_yaml(tax_path)
    scaled={**dist,'total':total,'classes':apportion(dist['classes'],total),'categories':apportion(dist['categories'],total),'splits':apportion(dist['splits'],total)}
    matrix=plan(dist,taxonomy,total,seed)
    settings={'mode':'bootstrap','target':total,'seed':seed,'config_sha256':sha(config_path),'distribution_sha256':sha(dist_path),'taxonomy_sha256':sha(tax_path),'question_schema_sha256':sha(ROOT/'config/dataset/question_schema_v1.yaml'),'generator_sha256':sha(ROOT/'src/decision_guardrail/data_generation/generator.py')}
    settings['source_hashes'] = {str(p.relative_to(ROOT)):sha(p) for p in
        sorted((ROOT/'src/decision_guardrail/data_generation').glob('*.py')) +
        sorted((ROOT/'config/dataset').glob('*.yaml')) +
        [ROOT/'docs/annotation_standard.md', ROOT/'docs/legal_reference_mapping.md']}
    if dry_run:
        return {'settings':settings,'allocation':matrix,'split_targets':scaled['splits'],'external_teacher_calls':0,'api_cost_usd':0,'status':'bootstrap_unverified','teacher_run_estimate':None}
    out=Path(output)
    manifest=out/'manifest.json'
    if out.exists() and any(out.iterdir()):
        if not resume:
            raise ValueError('Destination is nonempty; use a new output directory or --resume')
        if manifest.exists():
            old=json.loads(manifest.read_text())
            if old['settings'] != settings:
                raise ValueError('Resume configuration or generator differs')
            for name,digest in old['files'].items():
                if sha(out/name) != digest:
                    raise ValueError(f'Resume artifact hash differs: {name}')
            return {'resumed':True,'records':old['record_count'],'output':str(out)}
        # Interrupted local runs replay deterministically into temporary files.
        if not (out/'job.json').exists() or json.loads((out/'job.json').read_text()) != settings:
            raise ValueError('Unrecognised or incompatible incomplete output')
        # Validate a deterministic replay completely before adding missing files.
        # Existing partial artifacts are compared, never overwritten.
        with tempfile.TemporaryDirectory(prefix='dataset-resume-') as temporary:
            staged=Path(temporary)/'replay'
            result=run(config,distribution,staged,total,seed)
            for current in out.rglob('*'):
                if current.is_file():
                    expected=staged/current.relative_to(out)
                    if not expected.is_file() or sha(current)!=sha(expected):
                        raise ValueError(f'Incomplete resume artifact differs: {current.relative_to(out)}')
            added=[]
            for source in sorted(staged.rglob('*')):
                if source.is_file():
                    destination=out/source.relative_to(staged)
                    if not destination.exists():
                        destination.parent.mkdir(parents=True,exist_ok=True)
                        with destination.open('xb') as handle: handle.write(source.read_bytes())
                        added.append(str(destination.relative_to(out)))
            return {**result,'output':str(out),'resumed':True,'added_paths':added,'overwritten_paths':[]}
    out.mkdir(parents=True,exist_ok=True)
    write_json(out/'job.json',settings)
    rows=generate(matrix,taxonomy,cfg,seed)
    for r in rows: validate(r)
    splits=split(rows,scaled['splits'],seed)
    assert_disjoint(splits)
    for name,group in splits.items():
        for r in group: r['metadata']['split']=name
        write_jsonl(out/'splits'/f'{name}.jsonl',group)
        write_jsonl(out/'clef'/f'{name}.jsonl',[convert(r) for r in group])
    write_jsonl(out/'master_dataset.jsonl',rows)
    write_json(out/'questions.json',questions())
    write_json(out/'allocation.json',matrix)
    summary=report(rows,out/'reports',scaled,cfg,{k:len(v) for k,v in splits.items()})
    sample_reference(rows,out)
    write_json(out/'manifest.json',{'dataset_version':GENERATOR_VERSION,'schema_version':'financial_advice_v1','legal_reference_version':'AU-2026-10-17-v1','generated_at_utc':datetime.now(timezone.utc).isoformat(),'record_count':len(rows),'annotation_status':'bootstrap_unverified','settings':settings,'provenance':{'generator':GENERATOR_VERSION,'annotator':'construction_rules','verifier':None,'human_reviewed':False},'files':{str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'},'limits':{'independent_template_holdout':False,'independent_teacher_verified':False,'gemma_tokenizer_checked':False,'unsloth_runtime_checked':False}})
    return {'records':len(rows),'output':str(out),'splits':summary['splits'],'api_cost_usd':0,'annotation_status':'bootstrap_unverified'}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',default=str(ROOT/'config/dataset/generation_v4.yaml'))
    p.add_argument('--distribution',default=str(ROOT/'config/dataset/distribution_pilot.yaml'))
    p.add_argument('--target',type=int,default=20)
    p.add_argument('--output',required=True)
    p.add_argument('--seed',type=int,default=3407)
    p.add_argument('--resume',action='store_true')
    p.add_argument('--dry-run',action='store_true')
    p.add_argument('--max-cost',type=float,default=0)
    p.add_argument('--max-samples',type=int)
    p.add_argument('--teacher-config',help='Not available for this explicitly local bootstrap')
    args=p.parse_args(argv)
    try:
        if args.teacher_config:
            raise ValueError('This pipeline is local bootstrap only; independent teacher integration is not implemented')
        if args.max_cost<0 or (args.max_samples is not None and args.max_samples<args.target):
            raise ValueError('Invalid cost/sample ceiling')
        result=run(args.config,args.distribution,args.output,args.target,args.seed,args.resume,args.dry_run)
        print(json.dumps(result,indent=2))
    except (ValueError,OSError) as exc:
        p.exit(2,str(exc)+'\n')
    return 0


def run(config, distribution, output, total, seed, resume=False, dry_run=False):
    from .v4_pipeline import run_v4
    return run_v4(config, distribution, output, total, seed, resume, dry_run)


if __name__=='__main__':
    sys.exit(main())
