"""Apply explicit cell eligibility instead of re-crossing every reply/context."""
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from .context_v5_review import digest, sha, write_json, write_rows
from .natural_context_review import duplicate_bodies, full_turn_echoes
from ..training_readiness import annotation_fingerprint
from ..schema import decision_violations

SOURCE = 'data/generated/streaming_context_v7_development'
DISPOSITIONS = 'data/authored/streaming_context_v7_coherent/pairing_dispositions.json'
REVIEW = 'data/reviews/claude_streaming_context_v7_review/affected_ids.json'


def select_pairings(rows: list[dict], dispositions: list[dict]) -> tuple[list[dict], list[dict]]:
    """Retain exact reviewed cells; no inferred labels or automatic rewrites."""
    by_id = {r['id']: r for r in rows}
    decisions = {d['source_record_id']: d for d in dispositions}
    if len(by_id) != len(rows) or len(decisions) != len(dispositions) or set(decisions) != set(by_id):
        raise ValueError('Pairing dispositions must cover every source cell exactly once')
    retained, dropped = [], []
    for source in rows:
        d = decisions[source['id']]
        if d['input_labels_sha256'] != annotation_fingerprint(source):
            raise ValueError('Stale pairing disposition')
        if any(d[k] != source['metadata'][k] for k in ('family', 'context_kind', 'speech_act')):
            raise ValueError('Pairing metadata does not match its explicit cell')
        if not d.get('reason'):
            raise ValueError('Pairing disposition needs a reason')
        row = deepcopy(source)
        row['metadata'].update(split=None, native_export_eligible=False, exposed_development_only=True,
                               pairing_revision='coherent-cell-selection-v1', source_record_id=source['id'])
        row['annotation'].update(status='pending_independent_annotation', independent_review=False)
        row['annotation']['provenance'] = 'Codex construction; exposed in Claude v7 model review, not independent held-out validation'
        if d['action'] == 'drop_incoherent_pairing':
            row['metadata']['exclusion_reason'] = d['reason']
            dropped.append(row)
        elif d['action'] == 'retain_development_pairing':
            if decision_violations(row['labels']):
                raise ValueError('Inconsistent retained labels')
            retained.append(row)
        else:
            raise ValueError('Unknown pairing disposition')
    if duplicate_bodies(retained) or full_turn_echoes(retained):
        raise ValueError('Repeated reply body or copied full customer turn')
    return retained, dropped


def build(root: Path, output: Path) -> dict:
    if output.exists():
        raise ValueError('Choose a new output path; preserve the reviewed batch')
    source = root / SOURCE
    previous = json.loads((source / 'manifest.json').read_text())
    for name, expected in previous['files'].items():
        p = (source / name).resolve()
        if not p.is_relative_to(source.resolve()) or sha(p) != expected:
            raise ValueError('Source artifact hash mismatch: ' + name)
    rows = [json.loads(l) for l in (source / 'records.jsonl').read_text().splitlines()]
    dispositions = json.loads((root / DISPOSITIONS).read_text())
    retained, dropped = select_pairings(rows, dispositions)
    flagged = set(json.loads((root / REVIEW).read_text())['Z03_reply_references_absent_context'])
    if len(flagged) != 49 or {r['id'] for r in dropped} != flagged:
        raise ValueError('Coherence exclusions must match all 49 reviewed pairings')
    report = dict(status='coherent_development_revision_not_a_full_dataset_release', records=len(retained), source_records=len(rows),
        excluded_incoherent_pairings=len(dropped), families=len({r['metadata']['family'] for r in retained}),
        distinct_replies=len({r['input']['agent_response'] for r in retained}),
        training_ready=False, approved_training_records=0, same_context_duplicate_bodies=0, full_turn_echoes=0,
        unresolved_review_flagged_pairings=0, class_counts=dict(Counter(r['labels']['D7'] for r in retained)),
        limitations=['All rows are exposed development examples with no split assignment or annotation approval.',
                     'Removes the 49 reviewed incoherent pairings; bounded checks cannot prove complete semantic coherence.',
                     'This remains a method review batch, not the full replacement corpus.',
                     'Native token coverage and an authorized new-contract GPU smoke/reload remain pending.'])
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='coherent-context-', dir=output.parent) as temp:
        stage = Path(temp) / 'revision'
        stage.mkdir()
        write_rows(stage / 'records.jsonl', retained)
        write_rows(stage / 'excluded_incoherent_pairings.jsonl', dropped)
        write_json(stage / 'pairing_dispositions.json', dispositions)
        write_json(stage / 'quality_report.json', report)
        for name in ('withdrawn_v6_counterexamples.jsonl', 'exposed_v6_review_units.json', 'annotation_ledger.json'):
            (stage / name).write_bytes((source / name).read_bytes())
        write_rows(stage / 'review_queue.jsonl', [dict(record_id=r['id'], input_labels_sha256=annotation_fingerprint(r),
                   status='pending_independent_annotation', exposed_development_only=True) for r in retained])
        page = (source / 'review.html').read_text()
        start = '<script id="data" type="application/json">'
        before, _, tail = page.partition(start)
        _, _, after = tail.partition('</script>')
        if not before or not after:
            raise ValueError('Review template data boundary missing')
        payload = json.dumps(retained, ensure_ascii=False).replace('<', '\\u003c')
        page = before + start + payload + '</script>' + after
        page = page.replace('Context matters: natural replacement examples', 'Coherent pairings: 151 retained development cases')
        page = page.replace('Choose a family to compare the same responses across generic requests, disclosed needs and multiple turns.',
                            '49 incoherent pairings are excluded. Choose a family to inspect retained responses in their actual contexts.')
        (stage / 'review.html').write_text(page)
        (stage / 'README.md').write_text('# Coherent development revision\n\n151 retained pairs; 49 incoherent pairs excluded. No replies or labels were rewritten.\n'
            'All rows remain exposed development material with split=null and zero training approval. This is not a full replacement release.\n'
            'The old 200-case batch is preserved. See pairing_dispositions.json and excluded_incoherent_pairings.jsonl.\n')
        source_files = [root / DISPOSITIONS, root / REVIEW, source / 'manifest.json', Path(__file__).resolve()]
        write_json(stage / 'manifest.json', dict(status=report['status'], training_ready=False, records=len(retained),
            source_hashes={str(p.relative_to(root)): sha(p) for p in source_files},
            files={str(p.relative_to(stage)): sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}))
        stage.rename(output)
    return report
