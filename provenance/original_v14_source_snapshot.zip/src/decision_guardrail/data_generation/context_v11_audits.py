"""Naturalness and context dependence diagnostics, with explicit failed gates."""
from collections import Counter,defaultdict
import re
from .context_v10_audits import word_baseline


def naturalness_report(rows):
    n=len(rows);personal=[r for r in rows if r['labels']['D7']=='personal_advice']
    texts=[r['input']['agent_response'] for r in rows]
    turns=Counter(turn for r in rows for turn in r['input']['customer_context'].splitlines()[1:])
    refs=[ref for r in rows for ref in r['metadata']['source_refs'] if 'audible_stages:' in ref['scenario_id']]
    trajectories={ref['scenario_id'] for ref in refs}
    def fraction(fn):return sum(fn(r) for r in rows)/n
    bytarget=defaultdict(set)
    for r in rows:bytarget[r['input']['agent_response']].add(r['labels']['D7'])
    swaps={t for t,classes in bytarget.items() if len(classes)>1}
    combined=[{**r,'input':{**r['input'],'both':r['input']['customer_context']+'\n'+r['input']['agent_response']}} for r in rows]
    return dict(
        fractions=dict(mixed_content=fraction(lambda r:r['metadata']['mixed_content']),
          single_exchange=fraction(lambda r:len(r['input']['customer_context'].splitlines())==1),
          two_three_exchanges=fraction(lambda r:2<=len(r['input']['customer_context'].splitlines())<=5),
          four_plus_exchanges=fraction(lambda r:len(r['input']['customer_context'].splitlines())>=7),
          controlled_asr=fraction(lambda r:r['metadata']['asr_imperfections']),
          nonterminal_voice_prefix=fraction(lambda r:any('audible_stages:' in x['scenario_id'] and not x['is_final'] for x in r['metadata']['source_refs']))),
        partial_only_rows=sum(all(not ref['is_final'] for ref in r['metadata']['source_refs']) for r in rows),
        complete_response_available_rows=sum(any(ref['is_final'] for ref in r['metadata']['source_refs']) for r in rows),
        scope_drift_rows=sum(r['metadata']['intentional_speech_act_drift'] for r in rows),
        self_quotation_rows=sum('my answer is:' in t.lower() for t in texts),
        invented_speaker_rows=sum(bool(re.search(r'fictional adviser|imagined conversation|illustrative speaker|a second speaker',t,re.I)) for t in texts),
        counterweight_rows=sum(bool(re.search(r'I have framed this comparison around|The comparison here starts with|The point carried forward|For this discussion I|I am using .+ as the comparison criterion',t,re.I)) for t in texts),
        personal_i_would_fraction=sum(bool(re.search(r'\bI would\b',r['input']['agent_response'],re.I)) for r in personal)/max(1,len(personal)),
        i_would_by_class=dict(Counter(r['labels']['D7'] for r in rows if re.search(r'\bI would\b',r['input']['agent_response'],re.I))),
        max_noninitial_turn_repetitions=max(turns.values(),default=0),top_repeated_noninitial_turns=[list(item) for item in turns.most_common(20)],
        distinct_customer_contexts=len({r['input']['customer_context'] for r in rows}),
        authored_speech_trajectories=len(trajectories),nonterminal_prefix_rows=sum(any('audible_stages:' in x['scenario_id'] and not x['is_final'] for x in r['metadata']['source_refs']) for r in rows),
        observed_identical_target_D7_swap_rows=sum(r['input']['agent_response'] in swaps for r in rows),
        word_baselines={**{field:word_baseline(rows,field) for field in ('customer_context','agent_response')},'both':word_baseline(combined,'both')},
        semantic_naturalness='Authored construction, pending independent review; numerical gates do not certify realism.')


def paired_topic_diagnostic(rows,reference):
    """Same topic-group cohort for both releases; never a training/eval split."""
    import hashlib
    from .context_v5_release import Groups
    groups=Groups()
    for corpus in (reference,rows):
        for r in corpus:groups.union(r['metadata']['parent_topic'],r['metadata']['split_group'])
    def evaluate(corpus):
        diagnostic=[]
        for r in corpus:
            group=groups.find(r['metadata']['parent_topic'])
            split='test' if int(hashlib.sha256(group.encode()).hexdigest()[:8],16)%5==0 else 'train'
            diagnostic.append({**r,'metadata':{**r['metadata'],'split':split}})
        result=word_baseline(diagnostic,'agent_response')
        counts=Counter(r['labels']['D7'] for r in diagnostic if r['metadata']['split']=='test')
        result.update(test_class_counts=dict(counts),majority_baseline=max(counts.values())/sum(counts.values()))
        return result
    return dict(reference_v10=evaluate(reference),candidate=evaluate(rows),
        protocol='Common union of v10/v11 topic groups; SHA256 group modulo 5 chooses test. Diagnostic only, includes development designs, never an independent challenge or model-training split.')
