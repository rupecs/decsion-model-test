"""V5 export: v4 transaction (deduplicate, split, export) plus third-audit acceptance gates.

v4_pipeline.py is imported, not modified, so the v4 release still replays byte-identically.
"""
from collections import Counter,defaultdict
import csv
import json
from pathlib import Path
import re
import tempfile
from .schemas import ROOT,CLASSES,questions,read_yaml,validate
from .coverage_planner import plan,apportion
from .v5_generator import generate,GENERATOR_VERSION,PROFILES_PATH,FRAMINGS,SERVICE,SENSITIVE_PRODUCT_CATEGORIES
from .v4_pipeline import digest,dump,jsonl,key,split_balanced,report
from .clef_converter import convert

SELF_LABEL=r'\b(general|broad|category|untailored|not assessed|not an assessment)\b'
SENSITIVE_SUBINTENTS={'investment_scam','romance_scam','bank_impersonation','scam_recovery','account_takeover','financial_abuse','job_loss','illness',
    'natural_disaster','reduced_hours','hardship_application','hardship_complaint','death_notification','funeral_payment','arrears_notice',
    'missed_repayment','disputed_debt','collection_call'}


def precision(rows,predicate):
    c=Counter(r['labels']['D6'] for r in rows if predicate(r));n=sum(c.values())
    return {'n':n,'by_class':dict(c),'max_precision':round(max(c.values())/n,4) if n else None}


def response_metrics(rows):
    profiles=read_yaml(PROFILES_PATH)
    advice=[r for r in rows if r['labels']['D2']];personal=[r for r in rows if r['labels']['D6']=='personal_advice']
    framed=lambda r:any(r['agent_response'].startswith(f) or r['agent_response'].startswith(f.replace("I have not","I haven’t")) for f in FRAMINGS)
    mirrored=[r['id'] for r in rows if r['labels']['D6']=='general_advice' and r['metadata']['profile_disclosure_present'] and r['metadata']['general_opinion_source']!='neutral_opinions']
    interest_on_non_interest=[r['id'] for r in rows if 'simple interest at a hypothetical' in r['agent_response'] and r['metadata']['product_type'] in ('offset_deposit','foreign_currency_deposit')]
    bare=[r['id'] for r in rows if r['metadata']['disclosure_present'] and not r['metadata']['profile_disclosure_present'] and re.search(r'(That option|that product)',r['agent_response'])]
    credit_bare=[r['id'] for r in rows if any(c in r['customer_context'] for c in ('fixed-rate home loan ending','comparing personal loans','credit card balance in full')) and re.search(r'(That option|that product)',r['agent_response'])]
    return {
        'untailored_framing':precision(rows,framed),
        'self_label_terms':precision(rows,lambda r:re.search(SELF_LABEL,r['agent_response'],re.I)),
        'question_ending':precision(rows,lambda r:r['agent_response'].rstrip().endswith('?')),
        'for_you':precision(rows,lambda r:re.search(r'\bfor you\b',r['agent_response'])),
        'recommend_by_class':precision(rows,lambda r:re.search(r'\brecommend',r['agent_response'],re.I))['by_class'],
        'i_recommend_by_class':precision(rows,lambda r:re.search(r'\bI recommend\b',r['agent_response']))['by_class'],
        'ordinary_in_targets':sum(bool(re.search(r'\bordinary\b',r['agent_response'],re.I)) for r in rows),
        'general_after_profile_disclosure':sum(r['labels']['D6']=='general_advice' and r['metadata']['profile_disclosure_present'] for r in rows),
        'general_after_disclosure_mirroring_profile_opinion':len(mirrored),
        'unsupported_suitability_claims':sum('unsupported_suitability_claim' in r['metadata']['conduct_flags'] for r in rows),
        'unsupported_suitability_share_of_personal':round(sum('unsupported_suitability_claim' in r['metadata']['conduct_flags'] for r in personal)/len(personal),4),
        'interest_arithmetic_on_offset_or_currency':len(interest_on_non_interest),
        'credit_context_bare_referents':len(credit_bare),
        'advice_in_sensitive_subintents':sum(r['labels']['D2'] and r['metadata']['sub_intent'] in SENSITIVE_SUBINTENTS for r in rows),
        'advice_in_sensitive_share_of_advice':round(sum(r['labels']['D2'] and r['metadata']['sub_intent'] in SENSITIVE_SUBINTENTS for r in rows)/len(advice),4),
        'advice_by_service_only_category':sum(r['labels']['D2'] and r['metadata']['call_category'] in SERVICE for r in rows),
        'mixed_content_share_of_advice':round(sum(r['metadata']['mixed_content'] for r in advice)/len(advice),4),
        'voice_style_share':round(sum(r['metadata']['voice_style'] for r in rows)/len(rows),4),
        'asr_share':round(sum(r['metadata']['asr_imperfections'] for r in rows)/len(rows),4),
        'target_contraction_share':round(sum(r['metadata']['target_contractions'] for r in rows)/len(rows),4),
        'target_repeats_previous_agent_turn':sum(('AGENT: '+r['agent_response']) in r['customer_context'] for r in rows),
        'midsentence_capital_after_intro':sum(bool(re.search(r'(For context, |I should also say that |One thing to mention: |My situation is that )(My|The|Our|Most)\b',r['customer_context'])) for r in rows),
        'legal_review_required':sum(r['metadata']['legal_review_required'] for r in rows),
    }


GATES=[('untailored framing class precision <=0.6',lambda m:m['untailored_framing']['max_precision']<=.6),
    ('self-label term class precision <=0.6',lambda m:m['self_label_terms']['max_precision']<=.6),
    ('question-ending class precision <=0.7',lambda m:m['question_ending']['max_precision']<=.7),
    ('"for you" class precision <=0.8',lambda m:m['for_you']['max_precision']<=.8),
    ('"recommend" appears in >=3 classes',lambda m:len(m['recommend_by_class'])>=3),
    ('no "ordinary" scope marker in targets',lambda m:m['ordinary_in_targets']==0),
    ('no general opinion after disclosure drawn from the mirroring set',lambda m:m['general_after_disclosure_mirroring_profile_opinion']==0),
    ('unsupported suitability <=15% of personal',lambda m:m['unsupported_suitability_share_of_personal']<=.15),
    ('no interest arithmetic on offset/currency balances',lambda m:m['interest_arithmetic_on_offset_or_currency']==0),
    ('no bare referent in two-option credit contexts',lambda m:m['credit_context_bare_referents']==0),
    ('no advice in service-only categories',lambda m:m['advice_by_service_only_category']==0),
    ('mixed content 15-20% of advice',lambda m:.15<=m['mixed_content_share_of_advice']<=.22),
    ('voice >=20% and ASR 8-16% of records',lambda m:m['voice_style_share']>=.2 and .08<=m['asr_share']<=.16),
    ('no target repeats the previous agent turn',lambda m:m['target_repeats_previous_agent_turn']==0),
    ('no mid-sentence capital after disclosure intro',lambda m:m['midsentence_capital_after_intro']==0)]


def run_v5(config,distribution,output,total,seed,resume=False,dry_run=False):
    config=Path(config).resolve();distribution=Path(distribution).resolve();out=Path(output)
    if total<4:raise ValueError('At least four records required')
    cfg=read_yaml(config);dist=read_yaml(distribution);tax=read_yaml(ROOT/'config/dataset/call_taxonomy.yaml')
    matrix=plan(dist,tax,total,seed);sizes=apportion(dist['splits'],total)
    sources=[config,distribution,ROOT/'config/dataset/call_taxonomy.yaml',PROFILES_PATH,ROOT/'config/dataset/question_schema_v1.yaml']+[ROOT/'src/decision_guardrail/data_generation'/n for n in
        ('v5_generator.py','v5_pipeline.py','v4_pipeline.py','clef_converter.py','schemas.py','coverage_planner.py','splitter.py')]
    settings={'generator':GENERATOR_VERSION,'target':total,'seed':seed,'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources}}
    if dry_run:return {'settings':settings,'external_teacher_calls':0,'api_cost_usd':0,'split_targets':sizes}
    if out.exists() and any(out.iterdir()):
        if not resume:raise ValueError('Destination must be new; no artifact is overwritten')
        manifest=out/'manifest.json'
        if not manifest.exists():raise ValueError('Incomplete output; preserve it and use a new output directory')
        saved=json.loads(manifest.read_text())
        if saved['settings']!=settings:raise ValueError('Resume settings or source differ')
        for name,sha in saved['files'].items():
            if digest(out/name)!=sha:raise ValueError(f'Resume artifact hash differs: {name}')
        return {'resumed':True,'records':saved['record_count'],'output':str(out)}
    rows=generate(matrix,tax,cfg,seed)
    dedup={};rejected=[]
    for r in rows:
        validate(r);k=key(r)
        if k in dedup:rejected.append({'id':r['id'],'duplicate_of':dedup[k]['id'],'reason':'duplicate_export_state'})
        else:dedup[k]=r
    accepted=list(dedup.values())
    if len(accepted)!=total:raise ValueError('Deduplication left a quota shortfall; no duplicate rows will be exported')
    if total==2000:splits=split_balanced(accepted,sizes,seed)
    else:
        from .splitter import split
        splits=split(accepted,sizes,seed)
    for s,rs in splits.items():
        for r in rs:r['metadata']['split']=s
    metrics=report(accepted,splits)
    metrics['generator']=GENERATOR_VERSION
    metrics['response_side']=response_metrics(accepted)
    metrics['notes']=['Contexts and presentation layers (framing, disclaimers, speech style) are sampled per scenario before target classes.',
        'General opinions after a disclosure come from a set addressing an unrelated facet; legal adjudication is still required.',
        'Collections, bereavement and vulnerability calls are service-only; scam, complaint and hardship calls keep flagged advice edge cases.',
        'Shared response rules remain; these are context-grouped development splits, not an independent benchmark.',
        'Labels are construction labels pending independent annotation and qualified legal review.']
    failures=[]
    if metrics['context_ngram_violations']:failures.append('customer-context ngram cue')
    if total==2000:
        for s in ('validation','calibration','test'):
            if min(metrics['split_classes'][s].values())<30:failures.append(f'{s} class minimum')
        if metrics['credit_only_recommendations_by_split']['train']<80:failures.append('credit coverage')
        if any(not v['within_majority_plus_10pp'] for s,v in metrics['advice_only_context_baseline'].items() if s!='train'):failures.append('advice-only context baseline')
        metrics['acceptance_gates']={name:bool(check(metrics['response_side'])) for name,check in GATES}
        failures+=[n for n,ok in metrics['acceptance_gates'].items() if not ok]
    if failures:raise ValueError('Acceptance gates failed: '+'; '.join(failures))
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='v5-dataset-',dir=out.parent) as temporary:
        staged=Path(temporary)/'result';staged.mkdir()
        jsonl(staged/'master_dataset.jsonl',accepted);jsonl(staged/'rejected_candidates.jsonl',rejected)
        dump(staged/'questions.json',questions());dump(staged/'quality_report.json',metrics)
        index=[];master_lines={r['id']:n for n,r in enumerate(accepted,1)}
        for s,rs in splits.items():
            jsonl(staged/'splits'/f'{s}.jsonl',rs);jsonl(staged/'clef'/f'{s}.jsonl',[convert(r) for r in rs])
            for n,r in enumerate(rs,1):index.append({'record_id':r['id'],'master_line':master_lines[r['id']],'split':s,'split_line':n,'clef_line':n,'scenario_family_id':r['metadata']['scenario_family_id']})
        with (staged/'record_index.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=['record_id','master_line','split','split_line','clef_line','scenario_family_id']);writer.writeheader();writer.writerows(index)
        legal=[{'record_id':r['id'],'master_line':master_lines[r['id']],'split':r['metadata']['split'],'labels':r['labels'],'notes':r['metadata']['annotation_notes'],'conduct_flags':r['metadata']['conduct_flags'],'status':'pending_qualified_review'} for r in accepted if r['metadata']['legal_review_required']]
        jsonl(staged/'legal_review_queue.jsonl',legal)
        (staged/'quality_report.md').write_text('# Direct v5 dataset\n\nGenerated directly by v5_generator.py. All exports use the same deduplicated rows. quality_report.json lists every acceptance gate, including the response-side cue checks added after the third audit.\n\nLabels are construction labels pending independent annotation and qualified legal review; legal_review_queue.jsonl lists the records that need adjudication. Shared response rules still limit generalisation claims from these splits.\n')
        dump(staged/'manifest.json',{'dataset_version':GENERATOR_VERSION,'schema_version':'financial_advice_v1','record_count':len(accepted),'settings':settings,'provenance':{'generator':GENERATOR_VERSION,'annotator':'authored_response_spec','independent_verifier':None,'human_legal_reviewed':False},'generation_timestamp_policy':'omitted_to_keep_content_replays_byte_identical','files':{str(p.relative_to(staged)):digest(p) for p in sorted(staged.rglob('*')) if p.is_file() and p.name!='manifest.json'}})
        if out.exists():out.rmdir()
        staged.rename(out)
    return {'records':len(accepted),'output':str(out),'splits':sizes,'api_cost_usd':0,'annotation_status':'v5_construction_labels_pending_independent_review','acceptance_gates':metrics['acceptance_gates'] if total==2000 else None}
