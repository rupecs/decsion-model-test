"""V6 local bootstrap: protected service calls, paired advice, content-family holdouts.
No prior corpus or reviewer record ID is read. Generic language frames are shared;
substantive response content families and canonical bodies must not cross splits.
"""
from collections import Counter,defaultdict,deque
import re
from .schemas import ROOT,CLASSES,VERSION,read_yaml,validate
from .coverage_planner import apportion

GENERATOR_VERSION='final-bootstrap-v6'
PROFILES_PATH=ROOT/'config/dataset/scenario_profiles_v5.yaml'
HELDOUT_PROFILES_PATH=ROOT/'config/dataset/scenario_profiles_v6_heldout.yaml'
from .v6_content import EXTRA_SERVICE_FACTS,OTHER_POOLS,HELDOUT_CREDIT,SAFE_DETAIL,SERVICE_CONTACT_DETAILS,SERVICE_PREPARATION
SERVICE={'C03','C04','C06','C11','C12','C13','C17','C18','C20'}
SENSITIVE_PRODUCT_CATEGORIES={'C03','C06','C11'}
QUESTIONS=[
    'Could you talk me through the options?', 'What would you say about this?',
    'Could we discuss that product?', 'What is your view of it?',
    'What should I understand before making a choice?', 'Could you explain the product category?',
    'How would you describe the alternatives?', 'Can you give me a view on that option?',
    'What is worth knowing about this product?', 'What would you tell a caller asking about that?',
    'Could you address that point?', 'How do you see that choice?',
]
CREDIT_QUESTIONS=['Could you comment on either of those?','What would you say about those two things?',
    'Do you have a view on either of them?','Could you address one of those for me?']
BROAD_REQUESTS=[
    'Please keep the discussion general.', 'A broad product view would help.',
    'I am asking for a general view rather than a personal assessment.',
    'Could you speak about the category as a whole?',
]
# Class-neutral untailored framings (T01): the same strings precede facts, opinions,
# tailored recommendations, refusals and credit recommendations.
FRAMINGS=['Speaking generally rather than about your situation: ','Without assessing your circumstances: ',
    'I have not assessed what suits you. ','This is not an assessment of your situation. ']
DISCLOSURE_INTROS=['For context, ','One thing to mention: ','My situation is that ','I should also say that ']
DISCLAIMERS=[
    'This is general information, not a personal assessment. ',
    'I am not presenting this as personal advice. ',
    'This discussion does not replace an individual advice assessment. ',
]
ACTUAL=[
    'Because of {basis}, I recommend that you {action}.',
    'Taking account of {basis}, I would {action} for this situation.',
    'My recommendation is that you {action}; it reflects {basis}.',
    'Based on {basis}, my choice for you would be to {action}.',
    'For the circumstances you described — {basis} — I suggest that you {action}.',
]
IMPLICIT_NAMED=[
    'My choice for you is {product}.',
    '{Product} is the option I would pick for you.',
    'For you, I would go with {product}.',
    'The choice I favour for you is {product}.',
    'I would put you in {product}.',
]
IMPLICIT_BARE=['That option would be my recommendation for you.','I would choose that product for you.']
CLARIFICATIONS=[
    'Are you asking about {product} itself, or about the earlier service issue?',
    'Which aspect of {product} did you want to ask about?',
    'What part of {product} is your question about?',
    'Is your question about keeping {product}, or understanding it?',
    'Are you asking for an opinion about {product} or something else?',
]
CLARIFICATIONS_BARE=['Would you like to clarify what you mean by that product?']
REFUSALS=[
    'I am unable to give an opinion on whether {product} suits you.',
    'I cannot assess whether {product} is right for you in this conversation.',
    'I am not able to make an individual suitability judgement about {product}.',
    'I can’t make that choice about {product} for you in this conversation.',
]
FOLLOWUPS=[' Would you like me to go through any part of that again?',' Would you like that in writing as well?',
    ' Is there another part of this you want to cover?']
FACT_CLOSERS=[' I can arrange that information for you.',' I can send those details through for you.',' I can set up a follow-up call for you.']
SCAFFOLDS=[('Does that explanation itself select a product for me?','It describes the features; it does not select a product for you.'),
    ('Is that just how the product works?','Yes, that describes how it works under its terms.'),
    ('So that is a description rather than a choice?','That is right; it explains the features.'),
    ('Could you say a bit more about how it works?',None)]
SERVICE_ACKS=['I can help with that request.','Let me check what applies to that.','Thanks, I can look into that.','I can explain how that works.']
SERVICE_OTHER=['Could you repeat the final part of your question?','Would you like to add anything before I respond?',
    'Which part of your question would you like me to address first?','Is there anything else about this request you want to mention?',
    'Could you tell me a little more about what you need?','Would you prefer to continue now or call back later?']
VOICE_PREFIXES=['Yeah, look, ','Hi, ','Right, so ','G’day, ','Okay, so ']
CONTRACTIONS=[(r'\bI am\b','I’m'),(r'\bdo not\b','don’t'),(r'\bcannot\b','can’t'),(r'\bcould not\b','couldn’t'),
    (r'\bI would\b','I’d'),(r'\bit is\b','it’s'),(r'\bthat is\b','that’s'),(r'\bdoes not\b','doesn’t'),(r'\bI have not\b','I haven’t')]
CREDIT=[
    {'id':'home_loan','context':'I also have a fixed-rate home loan ending next month and I prefer stable repayments.',
     'responses':['For the home loan you described, I would favour another fixed-rate loan over a variable-rate loan.',
                  'Given your preference for stable repayments, I recommend refinancing to a fixed-rate home loan.',
                  'I would choose a fixed-rate refinance for your home loan rather than move to a variable rate.']},
    {'id':'personal_loan','context':'I am also comparing personal loans for a planned car purchase and want a fixed repayment schedule.',
     'responses':['For that planned car purchase, I would favour a fixed-rate personal loan.',
                  'I recommend a personal loan with a fixed repayment schedule for the borrowing you described.',
                  'I would choose a fixed-rate personal loan for your stated borrowing preference.']},
    {'id':'credit_card','context':'I also pay my credit card balance in full each month, use it only for domestic purchases and want low ongoing costs.',
     'responses':['For that credit-card use, I would choose a credit card without an ongoing annual fee.',
                  'I recommend a no-annual-fee credit card for your domestic, paid-in-full card use.',
                  'I would favour a no-annual-fee credit card for the use you described.']},
]
# Service alternatives carry explicit product scope; never inferred from wording.
SERVICE_ALTERNATIVES={
    'C04':[('Use an official banking support channel for access help, and do not disclose your password or a security code.',False),('Digital banking support can explain the authentication checks for this request.',False),('A shared-device login should be closed when you finish using it.',False)],
    'C13':[('Customer-detail changes should be requested through a verified banking channel.',False),('The bank can explain which identity or authority checks apply to this detail-change request.',False),('Do not send identity documents to an unsolicited caller.',False)],
    'C20':{'tax_statement':[('A deposit-account interest statement records interest credited for the relevant reporting period.',True),('Interest-statement periods and statement dates describe the records being requested.',True)],
           'government_deposit':[('A sender reference and payment date help identify a government payment into a transaction account.',True),('A transaction-account payment record may show a sender reference.',True)],
           'withholding_tax':[('Withholding from deposit interest can depend on the applicable tax rules and details held by the bank.',True),('A savings-account statement may show interest and tax withheld as separate entries.',True)],
           'payment_reference':[('The reference on a transaction-account payment may help identify its sender.',True),('The transaction date and sender reference can help locate the payment record.',True)],
           'tax_agent_referral':[('A registered tax agent can address individual tax-deduction questions.',False),('Individual deductions depend on tax rules and circumstances that a tax agent can assess.',False)]},
    'C12':{'arrears_notice':[('The arrears notice should show the overdue amount, the date it was calculated and how to contact the collections team.',False),('If any amount on the notice looks wrong, you can ask the collections team to explain how it was calculated.',False)],
           'missed_repayment':[('A missed repayment can usually be paid through the loan’s normal repayment channels once you know the overdue amount.',False),('The lending team can confirm the overdue amount and whether any default interest applies under the loan terms.',False)],
           'disputed_debt':[('You can ask for a statement showing how the disputed loan balance was calculated.',False),('A disputed debt can be raised as a complaint, and you can ask for collection activity details while it is reviewed.',False)],
           'repayment_arrangement':[('A repayment arrangement request usually needs your income, essential expenses and the amount you can afford to repay.',False),('The collections or hardship team assesses each arrangement request; you can ask how long the assessment takes.',False)],
           'collection_call':[('You can tell the collections team your preferred contact times and method.',False),('You can ask the collections team to put any agreed contact arrangement in writing.',False)]},
    'C17':{'death_notification':[('Notifying the bank of a deposit-account holder’s death usually starts with a death certificate or other evidence the estates team accepts.',True),('The estates team can explain what happens to the deceased holder’s deposit accounts after notification.',True)],
           'executor_documents':[('An executor is usually asked for the will, a death certificate and identification, and sometimes probate, before acting on a deposit account.',True),('Whether probate is needed for the deposit account can depend on the balance and the bank’s estate process.',True)],
           'estate_account':[('Deposit-account funds are usually released to the executor or administrator once the bank’s estate requirements are met.',True),('The estates team can explain how statements for the estate’s deposit accounts are provided during administration.',True)],
           'funeral_payment':[('Some estate processes allow a funeral invoice to be paid from the deceased person’s deposit account before the estate is finalised.',True),('A funeral-payment request usually needs the funeral director’s invoice and evidence of the death.',True)],
           'power_of_attorney':[('The bank checks that a power of attorney is valid and covers the transaction account before registering the attorney.',True),('A registered attorney can act on the transaction account within the authority the document gives.',True)]},
    'C18':{'interpreter':[('An interpreter can be arranged for the call, and you can choose the language.',False),('You can ask for an interpreter at any time during the call.',False)],
           'hearing_support':[('The bank can continue this conversation by text chat or the National Relay Service if that is easier.',False),('You can ask for written follow-up of anything discussed on this call.',False)],
           'financial_abuse':[('A specialist support team can talk with you privately and agree on a safe way to contact you.',False),('You can ask the bank not to send letters or messages to an address or phone your partner can access.',False)],
           'trusted_person':[('A trusted person can join the call if you give consent; they cannot act on the account without authority.',False),('The bank can record that you want a support person present for future calls.',False)],
           'accessible_statements':[('Deposit-account statements may be available in large print, braille or an accessible electronic format.',True),('You can ask for your deposit-account statements in a format that works with your screen reader.',True)]},
}
INTEREST_PROFILES=('savings_access','term_deposit','savings_conditions')


def contract(text):
    for pattern,repl in CONTRACTIONS:text=re.sub(pattern,repl,text)
    return text


def evidence(field,text,fragment):
    start=text.index(fragment)
    return {'field':field,'start':start,'end':start+len(fragment),'text':fragment}


def lower_first(text):
    return text if text.startswith('I ') or text.startswith('I’') else text[0].lower()+text[1:]


def choose_profile(cat,sub,profiles,rng):
    stage=next(iter(profiles.values())).get('bank_split','train')
    if stage=='train':
        if cat=='C09':choices=['diversified_fund','company_shares','superannuation','margin_lending']
        elif cat=='C15':choices=['income_cover','motor_cover']
        elif cat=='C19':choices=['merchant_payments','foreign_currency_deposit','term_deposit','savings_access']
        elif cat=='C16':choices=['foreign_currency_deposit','savings_access']
        elif cat=='C10' or sub=='loan_offset':choices=['offset_deposit','savings_access','margin_lending']
        else:choices=['savings_access','term_deposit','savings_conditions','offset_deposit']
    else:
        segment={'C09':'investment','C15':'insurance','C16':'currency','C19':'business','C10':'offset'}.get(cat,'deposit')
        choices=[k for k,v in profiles.items() if v['segment']==segment]
    key=rng.choice(choices);return key,profiles[key]


def speak(text,case,first=False):
    """Context-level speech style, sampled per scenario before any target class (T09)."""
    if case['voice']:
        text=contract(text)
        if first:text=case['voice_prefix']+lower_first(text)
    if case['asr']:
        text=re.sub(r'[,?’]','',text).replace('  ',' ').lower()
        if first:text='um '+text
    return text


def render(turns,case):
    customer=[i for i,(r,_) in enumerate(turns) if r=='CUSTOMER']
    out=[(r,speak(t,case,first=(i==customer[0])) if r=='CUSTOMER' else t) for i,(r,t) in enumerate(turns)]
    return out


def conversation(case,length,sub,profile,rng):
    """Construct context once. All target classes reuse these exact bytes."""
    service=sub['customer']
    if profile is None:
        detail=case['service_detail']
        service_turn=(service+' '+detail).strip()
        if length=='single':turns=[('CUSTOMER',service_turn)]
        elif length=='two_three':
            turns=[('CUSTOMER',service_turn),('AGENT',rng.choice(SERVICE_ACKS)),
                   ('CUSTOMER','Could you clarify what information is needed for that request?')]
        else:
            turns=[('CUSTOMER',service_turn),('AGENT',rng.choice(SERVICE_ACKS)),
                ('CUSTOMER','I can contact you through an official channel. What should I have ready?'),
                ('AGENT','The support team can explain the checks for this request.'),
                ('CUSTOMER','I do not want to provide sensitive details on this call.'),
                ('AGENT','You do not need to read out passwords or security codes here.'),
                ('CUSTOMER','Can you address my original request?')]
    else:
        topic=f"I also wanted to ask about {profile['product']}."
        detail=(rng.choice(DISCLOSURE_INTROS)+lower_first(case['disclosure'])+' ') if case['disclosed'] else ''
        credit=('Separately, '+lower_first(case['credit']['context'])+' ') if case['credit'] else ''
        question=rng.choice(CREDIT_QUESTIONS if case['credit'] else QUESTIONS)
        if case['general_request']:question+=' '+rng.choice(BROAD_REQUESTS)
        service_fact=sub['fact'].format(**case)
        if length=='single':turns=[('CUSTOMER',service+' '+topic+' '+detail+credit+question)]
        elif length=='two_three':turns=[('CUSTOMER',service),('AGENT',service_fact),('CUSTOMER',topic+' '+detail+credit+question)]
        else:
            ask,answer=case['scaffold']
            if answer is None:answer=case['scaffold_fact']
            turns=[('CUSTOMER',service),('AGENT',service_fact),
                ('CUSTOMER',topic+' '+detail+credit),('AGENT',case['context_fact']),
                ('CUSTOMER',ask),('AGENT',answer),('CUSTOMER',question)]
    turns=render(turns,case)
    case['rendered_customer_turns']=[t for r,t in turns if r=='CUSTOMER']
    case['context_agent_turns']=[t for r,t in turns if r=='AGENT']
    if len(turns)==1:return turns[0][1]
    return '\n'.join(f'{r}: {t}' for r,t in turns)


def finish(body,case,cls,rng,spans_src,allow_framing=True,question=False,factual=False):
    """Apply class-independent presentation layers and compute spans on final text."""
    prefix=''
    # Questions never carry a disclaimer or framing (v2 audit F15 defect).
    if question:pass
    elif allow_framing and case['framing']:prefix=case['framing_text']
    elif case['disclaimer']:prefix=case['disclaimer_text']
    suffix=''
    if not question:
        # Closers and follow-up questions are class-independent (T05/T06).
        roll=rng.random()
        if roll<.14:suffix=rng.choice(FACT_CLOSERS)
        elif roll<.32:suffix=rng.choice(FOLLOWUPS)
    contracted=rng.random()<.25
    text=prefix+body+suffix
    if contracted:text=contract(text)
    spans={}
    for name,fragment in spans_src.items():
        frag=contract(fragment) if contracted else fragment
        if frag in text:spans[name]=evidence('agent_response',text,frag)
    return text,prefix,suffix,contracted,spans


def record(case,sub,profile,cls,variant,rng,profiles):
    d1=d2=d3=d4=d5=False;src={};notes=[];credit_recommendation=False;mixed=False
    product=profile['product'] if profile else None
    fields={'product':product,'Product':product[0].upper()+product[1:] if product else '','basis':case.get('basis'),'action':case.get('action')}
    context=case['context'];question=False;allow_framing=True;opinion_set=None
    if cls=='factual_information':
        d5=True
        if profile:
            used=set(case['context_agent_turns'])|case.setdefault('used_targets',set())
            pool=[f for f in profile['facts'] if f not in used]
            procedural=[f for f in profile['procedural'] if f not in used]
            if procedural and (not pool or (variant==0 and rng.random()<.3)):
                body=rng.choice(procedural);case['used_targets'].add(body);rule=f"{case['profile_id']}:procedural:{profile['procedural'].index(body)}";notes.append('Operational recommendation treated as procedural (D5) under the annotation standard; hard negative.')
            elif variant and case['disclosed'] and case['profile_id'] in INTEREST_PROFILES:
                fact=rng.choice(pool)
                body=f'Using your illustrative balance of {case["amount"]}, simple interest at a hypothetical annual rate of 4% would be {case["interest"]} for one year before tax. '+fact
                rule=f"{case['profile_id']}:interest_arithmetic"
            else:
                fact=rng.choice(pool);body=fact;rule=f"{case['profile_id']}:fact:{profile['facts'].index(fact)}"
            case['used_targets'].add(body.split('. ')[-1] if body.startswith('Using your') else body)
            d1=True;src['D5']=body.split('. ')[0] if '. ' in body else body
        else:
            if variant==0:body=sub['fact'].format(**case);d1=sub['product_scope']=='in_scope';rule=case['sub_intent']+':service_fact'
            else:
                alts=([(t,sub['product_scope']=='in_scope') for t in EXTRA_SERVICE_FACTS[case['sub_intent']]] if case['sub_intent'] in EXTRA_SERVICE_FACTS else SERVICE_ALTERNATIVES[case['category']])
                alts=alts[case['sub_intent']] if isinstance(alts,dict) else alts
                body,d1=alts[(variant-1)%len(alts)];rule=f"{case['category']}:{case['sub_intent']}:service_alternative:{(variant-1)%len(alts)}"
            src['D5']=body.split('. ')[0] if '. ' in body else body
    elif cls=='general_advice':
        d1=d2=True
        # T02: after a disclosure, the opinion addresses a facet unrelated to it.
        opinion_set='neutral_opinions' if case['disclosed'] else rng.choice(['opinions','neutral_opinions'])
        opinion=rng.choice(profile[opinion_set]);body=opinion
        rule=f"{case['profile_id']}:{opinion_set}:{profile[opinion_set].index(opinion)}"
        if rng.random()<.18:
            body=rng.choice([fact for fact in profile['facts'] if fact not in case['context_agent_turns']] or profile['procedural'])+' '+opinion;mixed=True
        src['D2']=opinion
        if case['disclosed'] or case['credit']:notes.append('General opinion after disclosure; the opinion addresses a facet unrelated to the disclosure. Legal adjudication of reasonable expectations (RG 244.46-244.49) is still required.')
    elif cls=='personal_advice':
        d1=d2=d4=True
        if case['disclosed'] and variant==0:
            template=rng.choice(ACTUAL);opinion=template.format(**fields);d3=True;rule='actual:'+str(ACTUAL.index(template))
            src['D3']=case['basis']
        else:
            allow_framing=False
            options=IMPLICIT_NAMED
            if 'implicit_variants' not in case:case['implicit_variants']=rng.sample(options,2)
            template=case['implicit_variants'][variant];opinion=template.format(**fields)
            rule='expected_only:'+str((IMPLICIT_NAMED+IMPLICIT_BARE).index(template))
            notes.append('Suitability opinion appears personalised, without an observable statement of which circumstances were used.')
        body=opinion
        if rng.random()<.18:
            body=rng.choice([fact for fact in profile['facts'] if fact not in case['context_agent_turns']] or profile['procedural'])+' '+opinion;mixed=True
        src['D2']=opinion
        if d3 and case['framing']:notes.append('Untailored framing precedes a tailored recommendation; substance governs (RG 244.47).')
    else:
        if case['credit'] and variant==0:
            body=rng.choice(case['credit']['responses']);rule=case['credit']['id']+':recommendation';credit_recommendation=True
        elif profile:
            if variant:
                template=rng.choice(REFUSALS);rule='nonadvisory:refusal:'+str(REFUSALS.index(template))
            else:
                options=CLARIFICATIONS
                template=rng.choice(options);question=True;allow_framing=False
                rule='nonadvisory:question:'+str((CLARIFICATIONS+CLARIFICATIONS_BARE).index(template))
            body=template.format(**fields);d1=True
        else:
            body=rng.choice(OTHER_POOLS[case['planned_split']]);question=True;allow_framing=False;rule='service_question:'+case['planned_split']+':'+str(OTHER_POOLS[case['planned_split']].index(body))
    text,prefix,suffix,contracted,spans=finish(body,case,cls,rng,src,allow_framing,question,factual=cls=='factual_information')
    if d1:
        if profile and product in text:spans['D1_target']=evidence('agent_response',text,product)
        elif profile and product in context:
            spans['D1_context_product']=evidence('customer_context',context,product)
            reference=next((x for x in ('That option','that product') if x in text),None)
            if reference:spans['D1_target_reference']=evidence('agent_response',text,reference)
        elif not profile:
            first=case['rendered_customer_turns'][0]
            spans['D1_context_scope']=evidence('customer_context',context,first)
    if d4 and case['disclosed']:
        disclosure=case['rendered_disclosure']
        if disclosure in context:spans['D4_context']=evidence('customer_context',context,disclosure)
    lab={'D1':d1,'D2':d2,'D3':d3,'D4':d4,'D5':d5,'D6':cls}
    unsupported=d4 and not case['disclosed']
    meta={'call_category':case['category'],'sub_intent':case['sub_intent'],'product_type':case['credit']['id'] if credit_recommendation else case['profile_id'] or 'service_or_credit',
        'scenario_family_id':case['id'],'source_template_id':case['source_family'],
        'response_rule_id':(case['profile_id']+':'+rule if profile and not credit_recommendation else rule),
        'response_content_family_id':('credit:'+case['credit']['id'] if credit_recommendation else 'profile:'+case['profile_id'] if profile else 'service_question:'+case['planned_split'] if question else case['source_family']),
        'planned_split':case['planned_split'],
        'source':'direct_synthetic_context_crossing','annotation_status':'final_bootstrap_v6_pending_independent_and_legal_review',
        'generator':GENERATOR_VERSION,'human_reviewed':False,'independent_teacher_verified':False,
        'conversation_type':case['length'],'disclosure_present':case['disclosed'] or bool(case['credit']),
        'profile_disclosure_present':case['disclosed'],'general_request_present':case['general_request'],
        'disclaimer':bool(prefix) and prefix in DISCLAIMERS,'untailored_framing':bool(prefix) and prefix in FRAMINGS,
        'general_opinion_source':opinion_set,'mixed_content':mixed,'followup_question':bool(suffix) and suffix.strip().endswith('?'),
        'voice_style':case['voice'],'asr_imperfections':case['asr'],'target_contractions':contracted,
        'credit_only_recommendation':credit_recommendation,
        'context_sampled_before_target_class':True,'contrastive':profile is not None,
        'controlled_factor':'target_response_content' if profile else 'service_explanation_vs_clarification',
        'conduct_flags':['credit_conduct_not_assessed'] if credit_recommendation else (['unsupported_suitability_claim'] if unsupported else []),
        'legal_review_required':(cls=='general_advice' and (case['disclosed'] or bool(case['credit']))) or (d3 and case['framing']) or unsupported,
        'annotation_notes':notes,'evaluation_role':'context_grouped_development_not_independent_template_benchmark',
        'difficulty':'complex' if case['length']=='four_plus' else ('boundary' if d4 or cls=='general_advice' or prefix else 'straightforward'),
        'difficulty_basis':'content heuristic only','personalisation':'actual_and_expected' if d3 else ('reasonable_expectation_only' if d4 else 'not_applicable'),
        'context_dependent':None,
        'boundaries':(['B19'] if credit_recommendation else ['B18'] if profile and case['profile_id'] in INTEREST_PROFILES else []),
        'annotation':{'generator':GENERATOR_VERSION,'annotator':'authored_response_spec','independent_teacher_verified':False,'human_reviewed':False,'legal_references':['Corporations Act ss763A,764A,765A,766B','ASIC RG244.24–244.49']}}
    if case['category'] in SENSITIVE_PRODUCT_CATEGORIES and d2:meta['scenario_purpose']='deliberate_product_advice_edge_case_not_measured_traffic'
    row={'id':'UNASSIGNED','schema_version':VERSION,'customer_context':context,'agent_response':text,'labels':lab,'metadata':meta,'evidence':spans}
    validate(row);return row


def make_case(cat,sub,family,profiles,rng,length,profile=True,credit=None,settings=None,descriptor=None):
    s=settings
    amount=rng.randrange(12,950)*100;months=rng.choice([3,6,9,12,18,24])
    case={'id':descriptor['id'],'category':cat,'sub_intent':sub['id'],'amount':f'${amount:,}','interest':f'${amount*.04:,.0f}','months':months,
        'profile_id':None,'disclosed':False,'credit':credit,'length':length,
        'source_family':descriptor['source_family'],'planned_split':descriptor['split'],
        'general_request':profile and rng.random()<s['general_request_fraction'],
        'framing':rng.random()<s['framing_fraction'],'disclaimer':rng.random()<s['disclaimer_fraction'],
        'voice':rng.random()<s['voice_fraction'],'asr':rng.random()<s['asr_fraction']}
    case['framing_text']=rng.choice(FRAMINGS);case['disclaimer_text']=rng.choice(DISCLAIMERS);case['voice_prefix']=rng.choice(VOICE_PREFIXES)
    j=descriptor['local_index']//5
    case['service_detail']=(' '.join([SAFE_DETAIL.get(sub['id'],''), SERVICE_CONTACT_DETAILS[j%len(SERVICE_CONTACT_DETAILS)],SERVICE_PREPARATION[(j//len(SERVICE_CONTACT_DETAILS))%len(SERVICE_PREPARATION)]]).strip()) if not profile else ''
    if profile:
        pid,p=choose_profile(cat,sub['id'],profiles,rng);case['profile_id']=pid
        case['disclosed']=descriptor['disclosed']
        case['disclosure']=p['disclosure'].format(**case);case['basis']=p['basis'].format(**case);case['action']=p['personal_action'].format(**case)
        if pid in INTEREST_PROFILES:case['disclosure']+=f' The illustrative balance for this discussion is {case["amount"]}.'
        case['scaffold']=rng.choice(SCAFFOLDS)
        facts=list(p['facts']);rng.shuffle(facts)
        case['context_fact']=facts[0];case['scaffold_fact']=facts[1]
    else:p=None
    case['context']=conversation(case,length,sub,p,rng)
    if profile and case['disclosed']:
        rendered=speak(lower_first(case['disclosure']),case)
        case['rendered_disclosure']=rendered
    return case,p


def layout(matrix,taxonomy,config,seed,split_sizes):
    """Allocate class footprints first; no text or label keywords enter this step."""
    import random
    from .v4_pipeline import split_balanced
    rng=random.Random(seed)
    counts={k:sum(v.values()) for k,v in matrix.items()}
    demand={c:sum(v[c] for v in matrix.values()) for c in CLASSES}
    total=sum(counts.values())
    if total!=2000:raise ValueError('V6 is a frozen 2000-record pilot; use v5 for structural small runs')
    active={k:n for k,n in counts.items() if k not in SERVICE}
    service={k:n for k,n in counts.items() if k in SERVICE}
    core=demand['general_advice']
    # Protected calls consume factual/other rows, not four-outcome advice groups.
    service_other=apportion(service,270)
    service_factual=sum(service.values())-sum(service_other.values())
    groups=apportion(active,core)
    remaining={k:active[k]-2*groups[k] for k in active}
    extras=allocate_extras(groups,remaining,{'personal_advice':demand['personal_advice']-core,
        'factual_information':demand['factual_information']-service_factual,
        'other':demand['other']-sum(service_other.values())})
    descriptors=[];number=0
    for cat,g in groups.items():
        bycat=[]
        for j in range(g):
            number+=1
            descriptor={'id':f'V6_SCENARIO_{number:04}','source_family':f'V6_SCENARIO_{number:04}',
                'category':cat,'sub':taxonomy[cat]['sub_intents'][j%5], 'local_index':j,
                'disclosed':rng.random()<config['disclosure_fraction'],'outcomes':[('general_advice',0),('personal_advice',0)]}
            bycat.append(descriptor);descriptors.append(descriptor)
        for cls in ('personal_advice','factual_information','other'):
            indices=list(range(g));rng.shuffle(indices)
            if cls=='personal_advice':indices.sort(key=lambda i:not bycat[i]['disclosed'])
            for i in indices[:extras[cls][cat]]:bycat[i]['outcomes'].append((cls,1 if cls=='personal_advice' else 0))
    other_cases=[d for d in descriptors if any(c=='other' for c,v in d['outcomes'])]
    rng.shuffle(other_cases);credit_ids={d['id'] for d in other_cases[:150]}
    for d in descriptors:d['credit_topic']=d['id'] in credit_ids
    for cat,n in service.items():
        o=service_other[cat];f=n-o
        for j in range(o):
            number+=1;sub=taxonomy[cat]['sub_intents'][j%5]
            # Category-wide authentication/KYC alternatives are one shared content
            # bank; keep them in train. Other service intents own their full bank.
            source='service:'+cat if cat in ('C04','C13') else 'service:'+sub['id']
            descriptors.append({'id':f'V6_SCENARIO_{number:04}','source_family':source,
                'category':cat,'sub':sub,'local_index':j,'disclosed':False,'credit_topic':False,
                'outcomes':[('factual_information',v) for v in range(f//o+(j<f%o))]+[('other',0)]})
    skeleton=[]
    for d in descriptors:
        for cls,v in d['outcomes']:
            skeleton.append({'labels':{'D6':cls},'metadata':{'source_template_id':d['source_family'],'scenario_family_id':d['id'],'call_category':d['category']},'_descriptor':d})
    forced=[r for r in skeleton if r['metadata']['call_category'] in ('C04','C13')]
    remaining_rows=[r for r in skeleton if r not in forced]
    capacities=dict(split_sizes);capacities['train']-=len(forced)
    partitions=split_balanced(remaining_rows,capacities,seed)
    partitions['train']+=forced
    for split,rs in partitions.items():
        for r in rs:r['_descriptor']['split']=split
    return descriptors


def generate(matrix,taxonomy,config,seed,split_sizes=None):
    import random
    rng=random.Random(seed)
    if split_sizes is None:split_sizes={'train':1500,'validation':200,'calibration':150,'test':150}
    descriptors=layout(matrix,taxonomy,config,seed,split_sizes)
    settings={k:config[k] for k in ('general_request_fraction','disclaimer_fraction','framing_fraction','disclosure_fraction','voice_fraction','asr_fraction')}
    training=read_yaml(PROFILES_PATH)
    for p in training.values():p['bank_split']='train'
    heldout=read_yaml(HELDOUT_PROFILES_PATH)
    banks={'train':training}
    for split in ('validation','calibration','test'):
        banks[split]={k:{**v,'bank_split':split} for k,v in heldout.items() if v['split']==split}
    rows=[]
    lengths=[]
    for kind,n in apportion(config['exchanges'],sum(d['category'] not in SERVICE for d in descriptors)).items():lengths.extend([kind]*n)
    rng.shuffle(lengths)
    for family,d in enumerate(descriptors,1):
        split=d['split'];profiles=banks[split]
        credit=rng.choice(CREDIT if split=='train' else HELDOUT_CREDIT[split]) if d['credit_topic'] else None
        length=lengths.pop() if d['category'] not in SERVICE else rng.choice(['single','two_three','four_plus'])
        case,p=make_case(d['category'],d['sub'],family,profiles,rng,length,profile=d['category'] not in SERVICE,credit=credit,settings=settings,descriptor=d)
        for cls,v in d['outcomes']:
            if cls=='other' and p and not credit:v=rng.choice([0,1])
            rows.append(record(case,d['sub'],p,cls,v,rng,profiles))
    rng.shuffle(rows)
    for i,r in enumerate(rows,1):r['id']=f'V6_{i:06}';r['metadata']['split']=r['metadata']['planned_split']
    if len({(r['customer_context'],r['agent_response']) for r in rows})!=len(rows):raise ValueError('Duplicate rendered state; revise substantive cases')
    if Counter(r['labels']['D6'] for r in rows)!=Counter({c:sum(v[c] for v in matrix.values()) for c in CLASSES}):raise ValueError('Class quota mismatch')
    if Counter(r['metadata']['call_category'] for r in rows)!=Counter({k:sum(v.values()) for k,v in matrix.items()}):raise ValueError('Category quota mismatch')
    return rows


def allocate_extras(groups,remaining,needs):
    """Small integral max-flow: exact class/call margins, one extra per class/case."""
    capacities=defaultdict(dict)
    def edge(a,b,n):capacities[a][b]=n;capacities[b].setdefault(a,0)
    for cls,n in needs.items():
        edge('source',cls,n)
        for cat,g in groups.items():edge(cls,cat,g)
    for cat,n in remaining.items():edge(cat,'sink',n)
    residual={a:dict(bs) for a,bs in capacities.items()};flow=0
    while True:
        parents={'source':None};q=deque(['source'])
        while q and 'sink' not in parents:
            a=q.popleft()
            for b,n in residual[a].items():
                if n>0 and b not in parents:parents[b]=a;q.append(b)
        if 'sink' not in parents:break
        amount=10**9;b='sink'
        while parents[b] is not None:a=parents[b];amount=min(amount,residual[a][b]);b=a
        b='sink'
        while parents[b] is not None:
            a=parents[b];residual[a][b]-=amount;residual[b][a]+=amount;b=a
        flow+=amount
    if flow!=sum(needs.values()) or any(residual['source'].get(c,0) for c in needs):raise ValueError('Crossed class/call extra quotas infeasible')
    if any(residual[cat]['sink'] for cat in remaining):raise ValueError('Product-category quotas not filled by extras')
    return {cls:{cat:capacities[cls][cat]-residual[cls][cat] for cat in groups} for cls in needs}
