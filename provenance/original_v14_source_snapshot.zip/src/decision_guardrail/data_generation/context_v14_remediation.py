"""Reproducible correction working package, never a release or training export."""
from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import json
import re
from pathlib import Path

from .dialogue_exposure import design_ids, design_fingerprint, fingerprint, read_jsonl, sha
from .dialogue_release_audit import coverage
from .context_v6_release import native_questions, validate_rows

SOURCE = 'data/generated/streaming_context_v13_release'
REVIEW = 'data/reviews/claude_streaming_context_v13_review'
CHANGES = 'data/authored/streaming_context_v13_relabel/comparison_step_relabels.json'
SOURCE_MANIFEST = 'bf316a2f2c897fac989fe6f94858d78058e6bf4ef9543059108bfa6f19653d10'
LISTS = ('analysis/comparison_step_ids.json', 'analysis/comparison_step_ids_consistency_extension.json')


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def write_rows(path: Path, rows: list[dict]) -> None:
    path.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows))


def correct(rows: list[dict], proposals: dict, ids: set[str]) -> tuple[list[dict], list[dict]]:
    entries = proposals['entries']
    if len(entries) != len(ids) or {x['record_id'] for x in entries} != ids:
        raise ValueError('Correction ledger must match every reviewed comparison ID exactly')
    by_id = {r['id']: r for r in rows}
    if len(by_id) != len(rows) or not ids <= by_id.keys():
        raise ValueError('Duplicate source ID or unresolved correction')
    corrected = deepcopy(rows)
    destination = {r['id']: r for r in corrected}
    changes = []
    for entry in entries:
        old = by_id[entry['record_id']]
        bound = hashlib.sha256(json.dumps(dict(input=old['input'], labels=old['labels']),
                                         sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        if (bound != entry['input_labels_sha256_before'] or old['labels'] != entry['labels_before'] or
                old['input']['agent_response'] != entry['agent_response'] or
                old['metadata']['split'] != entry['split'] or not old['labels']['D2']):
            raise ValueError('Correction source mismatch: ' + old['id'])
        expected = dict(D1=old['labels']['D1'], D2=False, D3=False, D4=False, D5=True, D6=False,
                        D7='factual_information')
        if entry['labels_after'] != expected:
            raise ValueError('Unexpected comparison-step correction: ' + old['id'])
        row = destination[old['id']]
        row['labels'] = expected
        row['advice_present'] = False
        row['annotation'].update(profile='fact', status='pending_independent_annotation', independent_review=False,
                                 rationale='Comparison procedure only; no available product endorsement. Proposed correction under the existing contract.')
        row['annotation']['evidence']['context_support_spans'] = []
        row['metadata']['proposed_correction'] = dict(source_release=SOURCE, source_record_id=old['id'],
                                                     issue='Z01', approved=False)
        changes.append(dict(record_id=old['id'], split=entry['split'], input_labels_sha256_before=bound,
                            labels_before=old['labels'], labels_after=expected, status='proposed_not_independently_approved'))
    return corrected, changes


def stable_cues(rows: list[dict]) -> dict:
    contexts = defaultdict(Counter)
    for row in rows:
        contexts[row['input']['customer_context']][row['labels']['D7']] += 1
    counts = defaultdict(Counter)
    for context, classes in contexts.items():
        words = re.findall(r"[a-z0-9']+", context.casefold())
        grams = {tuple(words[i:i+n]) for n in range(1, 6) for i in range(len(words)-n+1)}
        for gram in sorted(grams):
            counts[gram].update(classes)
    cues = []
    for gram, classes in counts.items():
        total = sum(classes.values())
        winner, count = sorted(classes.items(), key=lambda pair: (-pair[1], pair[0]))[0]
        if total >= 30 and count / total > .8:
            cues.append(dict(phrase=' '.join(gram), support=total, dominant_class=winner, precision=count / total))
    return dict(context_cues_support30_precision80=len(cues), context_cues=sorted(cues,
                key=lambda item: (-item['precision'], -item['support'], item['phrase']))[:100])


def build(root: Path, output: Path) -> dict:
    root = root.resolve()
    if output.exists() or not output.resolve().is_relative_to(root):
        raise ValueError('Use a new output directory inside the project')
    source, review = root / SOURCE, root / REVIEW
    if sha(source / 'manifest.json') != SOURCE_MANIFEST:
        raise ValueError('Wrong frozen source manifest')
    manifest = json.loads((source / 'manifest.json').read_text())
    for name, expected in manifest['files'].items():
        if sha(source / name) != expected:
            raise ValueError('Frozen source artifact changed: ' + name)
    rows = read_jsonl(source / 'records.jsonl')
    designs = read_jsonl(source / 'designs.jsonl')
    ids = set()
    for name in LISTS:
        values = json.loads((review / name).read_text())
        if len(values) != len(set(values)) or ids.intersection(values):
            raise ValueError('Review correction lists overlap or duplicate IDs')
        ids.update(values)
    if len(ids) != 783:
        raise ValueError('Expected the reviewed 783 corrections')
    proposals = json.loads((root / CHANGES).read_text())
    if proposals['source_manifest_sha256'] != SOURCE_MANIFEST:
        raise ValueError('Correction proposal has wrong source manifest')
    corrected, changes = correct(rows, proposals, ids)
    _, questions = native_questions(root)
    try:
        result, _ = validate_rows(corrected, [], questions)
        integrity = dict(passed=True, report=result)
    except ValueError as error:
        # A working package records a failed gate; it must never publish around it.
        integrity = dict(passed=False, error=str(error).split(': [', 1)[0], cue_diagnostics=stable_cues(corrected))
    blind = read_jsonl(review / 'blind_sample_review.jsonl')
    exposed_ids = ids | {r['id'] for r in blind}
    if not exposed_ids <= {r['id'] for r in rows}:
        raise ValueError('Unresolved review exposure')
    exposed_designs = set().union(*(design_ids(r) for r in rows if r['id'] in exposed_ids))
    retained = [r for r in corrected if not design_ids(r).intersection(exposed_designs)]
    excluded = [dict(record_id=r['id'], design_ids=sorted(design_ids(r)), split=r['metadata']['split'],
                     reason='review_exposed_design_lineage') for r in corrected if design_ids(r).intersection(exposed_designs)]
    # Extend the previous ledger without modifying frozen policies or their loaders.
    ledger_path = root / 'data/reviews/dialogue_exposure_ledger_v2.json'
    ledger = json.loads(ledger_path.read_text())
    for name, expected in {**ledger['review_files'], **ledger['source_files']}.items():
        if sha(root / name) != expected:
            raise ValueError('Previous cumulative exposure source changed: ' + name)
    ledger['review_files'][REVIEW + '/blind_sample_review.jsonl'] = sha(review / 'blind_sample_review.jsonl')
    ledger['review_id_lists'] = {REVIEW + '/' + name: sha(review / name) for name in LISTS}
    ledger['source_files'].update({SOURCE + '/' + name: sha(source / name)
                                  for name in ('records.jsonl', 'designs.jsonl', 'manifest.json')})
    ledger['reviewed_record_ids'] = sorted(set(ledger['reviewed_record_ids']) | exposed_ids)
    ledger['reviewed_design_ids'] = sorted(set(ledger['reviewed_design_ids']) | exposed_designs)
    ledger['representative_design_ids'] = sorted(set(ledger['representative_design_ids']) | exposed_designs)
    selected = [d for d in designs if d['design_id'] in exposed_designs]
    ledger['goal_fingerprints'] = sorted(set(ledger['goal_fingerprints']) | {fingerprint(d['customer_goal']) for d in selected})
    ledger['design_fingerprints'] = sorted(set(ledger['design_fingerprints']) | {design_fingerprint(d) for d in selected})
    ledger['context_fingerprints'] = sorted(set(ledger['context_fingerprints']) |
        {fingerprint(r['input']['customer_context']) for r in rows if design_ids(r).intersection(exposed_designs)})
    ledger['review_record_counts'][REVIEW + '/blind_sample_review.jsonl'] = len(blind)
    ledger['exposure_interpretation'] = 'Conservative: the 783 reviewed comparison IDs and 120 blind rows expose whole design lineages, even in train. No silent policy relaxation.'
    partitions, failures = coverage(retained)
    boundary = {}
    for split in ('train', 'validation', 'calibration', 'test'):
        selected_rows = [r for r in corrected if r['metadata']['split'] == split]
        boundary[split] = {name: len({r['metadata']['contrast_family'] for r in selected_rows
            if (r['labels']['D3'], r['labels']['D4']) == pair})
            for name, pair in (('D3_only', (True, False)), ('D4_only', (False, True)))}
    queues = [dict(record_id=r['id'], split=r['metadata']['split'], issues=
                  (['Z02_explicit_pick_only_coverage'] if r['labels']['D4'] and not r['labels']['D3'] else []) +
                  (['Z03_category_actual_application'] if r['metadata'].get('context_kind') == 'category_question' and r['labels']['D2'] else []))
              for r in corrected if (r['labels']['D4'] and not r['labels']['D3']) or
              (r['metadata'].get('context_kind') == 'category_question' and r['labels']['D2'])]
    report = dict(status='correction_working_package_not_a_release', training_ready=False, approved_training_records=0,
                  source_records=len(rows), proposed_label_corrections=len(changes), integrity=integrity,
                  corrected_splits=dict(Counter(r['metadata']['split'] for r in corrected)),
                  corrections_by_split=dict(Counter(c['split'] for c in changes)),
                  corrected_classes=dict(Counter(r['labels']['D7'] for r in corrected)),
                  corrected_boundary_design_support_before_exposure=boundary,
                  blind_review_rows=len(blind), conservative_exposed_record_ids=len(exposed_ids),
                  exposed_design_ids=len(exposed_designs), retained_after_exposure=len(retained), excluded_after_exposure=len(excluded),
                  retained_splits=dict(Counter(r['metadata']['split'] for r in retained)),
                  retained_coverage=partitions, retained_coverage_failures=failures,
                  adjudication_issue_counts=dict(Counter(issue for r in queues for issue in r['issues'])),
                  no_native_exports=True, full_successor_published=False,
                  blockers=['corrected source fails customer-context cue gate; author substantive contrasts, never rebalance with wrappers',
                            'fresh designs required to restore >10000 rows, 60-70% training and every coverage floor',
                            'genuine product endorsements needed for discordant support',
                            'bare-disclosure suitability contrasts need authorship and D3/D4 adjudication',
                            'category versus actual-use pairs need individual adjudication',
                            'independent annotation, native coverage, approved D1-D7 GPU smoke/reload, independent challenge remain pending'])
    output.mkdir(parents=True)
    write_rows(output / 'corrected_source_development_only.jsonl', corrected)
    write_rows(output / 'unexposed_working_pool_not_release.jsonl', retained)
    write_rows(output / 'excluded_exposure.jsonl', excluded)
    write_rows(output / 'adjudication_queue.jsonl', queues)
    write_json(output / 'label_changes.json', changes)
    write_json(output / 'exposure_ledger.json', ledger)
    write_json(output / 'exposure_policy.json', dict(format='dialogue_exposure_policy_v1',
        ledger=str((output / 'exposure_ledger.json').relative_to(root)), sha256=sha(output / 'exposure_ledger.json')))
    write_json(output / 'report.json', report)
    inputs = [source / 'manifest.json', source / 'records.jsonl', source / 'designs.jsonl', root / CHANGES,
              review / 'blind_sample_review.jsonl', review / 'review_report.md', ledger_path,
              Path(__file__).resolve(), *(review / name for name in LISTS)]
    write_json(output / 'manifest.json', dict(status=report['status'], training_ready=False,
        source_hashes={str(p.relative_to(root)): sha(p) for p in inputs},
        files={p.name: sha(p) for p in sorted(output.iterdir()) if p.is_file()}))
    return report
