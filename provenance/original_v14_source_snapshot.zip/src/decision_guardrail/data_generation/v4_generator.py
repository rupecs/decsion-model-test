"""Direct, context-crossed synthetic dataset construction without review-ID patches.

Each core scenario is shared across factual/general/personal/other target responses.
Customer wording is sampled once per scenario, before assigning response classes.
All labels follow explicit response specifications, not record indices or keywords.
"""
from collections import Counter,defaultdict,deque
import hashlib
import json
import random
import re
from .schemas import ROOT,CLASSES,VERSION,read_yaml,validate
from .coverage_planner import apportion

GENERATOR_VERSION='direct-context-crossed-v4'
ADMIN={'C04','C13','C20'}
QUESTIONS=[
    'Could you talk me through the options?', 'What would you say about this?',
    'Could we discuss that product?', 'What is your view of it?',
    'What should I understand before making a choice?', 'Could you explain the product category?',
    'How would you describe the alternatives?', 'Can you give me a view on that option?',
    'What is worth knowing about this product?', 'What would you tell a caller asking about that?',
    'Could you address that point?', 'How do you see that choice?',
]
BROAD_REQUESTS=[
    'Please keep the discussion general.', 'A broad product view would help.',
    'I am asking for a general view rather than a personal assessment.',
    'Could you speak about the category as a whole?',
]
GENERAL_SCOPE=[
    'Speaking about the product category, not assessing your situation: ',
    'I have not assessed what suits you. My category-level opinion is this: ',
    'This is a broad product opinion rather than a recommendation tailored to you: ',
    'I can give an untailored view of the category: ',
]
DISCLOSURE_INTROS=['For context, ','One thing to mention: ','My situation is that ','I should also say that ']
DISCLAIMERS=[
    'This is general information, not a personal assessment. ',
    'I am not presenting this as personal advice. ',
    'This discussion does not replace an individual advice assessment. ',
]
ACTUAL=[
    'Because of {basis}, I recommend that you {action}.',
    'Taking account of {basis}, I would {action} for this situation.',
    'My recommendation is that you {action}; it reflects {basis}.',
    'Based on {basis}, my choice for you would be to {action}.',
    'For the circumstances you described — {basis} — I suggest that you {action}.',
]
IMPLICIT=[
    'My choice for you is {product}.',
    '{Product} is the option I would pick for you.',
    'For you, I would go with {product}.',
    'That option would be my recommendation for you.',
    'I would choose that product for you.',
    'The choice I favour for you is {product}.',
]
CLARIFICATIONS=[
    'Are you asking about {product} itself, or about the earlier service issue?',
    'Which aspect of {product} did you want to ask about?',
    'Would you like to clarify what you mean by that product?',
    'What part of {product} is your question about?',
    'Is your question about keeping {product}, or understanding it?',
    'Are you asking for an opinion about {product} or something else?',
]
REFUSALS=[
    'I am unable to give an opinion on whether {product} suits you.',
    'I cannot assess whether {product} is right for you in this conversation.',
    'I am not able to make an individual suitability judgement about {product}.',
    'I do not have a suitability assessment to offer about {product}.',
]
CREDIT=[
    {'id':'ordinary_home_loan','context':'I also have an ordinary fixed-rate home loan ending next month and I prefer stable repayments.',
     'responses':['For the ordinary home loan you described, I would favour another fixed-rate loan over a variable-rate loan.',
                  'Given your preference for stable repayments, my pick would be an ordinary fixed-rate home loan.',
                  'I would choose a fixed-rate refinance for your ordinary home loan rather than move to a variable rate.']},
    {'id':'ordinary_personal_loan','context':'I am also comparing ordinary personal loans for a planned car purchase and want a fixed repayment schedule.',
     'responses':['For that planned car purchase, I would favour an ordinary fixed-rate personal loan.',
                  'My preference for the borrowing you described would be an ordinary personal loan with a fixed repayment schedule.',
                  'I would choose a fixed-rate personal loan for your stated borrowing preference.']},
    {'id':'ordinary_credit_card','context':'I also pay my credit card balance in full each month, use it only for domestic purchases and want low ongoing costs.',
     'responses':['For that credit-card use, I would choose an ordinary credit card without an ongoing annual fee.',
                  'My choice for your domestic, paid-in-full card use would be an ordinary credit card with no annual fee.',
                  'I would favour a no-annual-fee ordinary credit card for the use you described.']},
]


def evidence(field,text,fragment):
    start=text.index(fragment)
    return {'field':field,'start':start,'end':start+len(fragment),'text':fragment}


def choose_profile(cat,sub,profiles,rng):
    if cat=='C09':choices=['diversified_fund','company_shares','superannuation','margin_lending']
    elif cat=='C15':choices=['income_cover','motor_cover']
    elif cat=='C19':choices=['merchant_payments','foreign_currency_deposit','term_deposit','savings_access']
    elif cat=='C16':choices=['foreign_currency_deposit','savings_access']
    elif cat=='C10' or sub=='loan_offset':choices=['offset_deposit','savings_access','margin_lending']
    else:choices=['savings_access','term_deposit','savings_conditions','offset_deposit']
    key=rng.choice(choices);return key,profiles[key]


def conversation(case,length,sub,profile,rng):
    """Construct context once. All target classes reuse these exact bytes."""
    service=sub['customer']
    if profile is None:
        service+=' '+case['service_detail']
        if length=='single':return service
        turns=[('CUSTOMER',service),('AGENT',sub['fact'].format(**case)),
               ('CUSTOMER','Could you clarify what information is needed for that request?')]
        if length=='four_plus':
            turns=[('CUSTOMER',service),('AGENT',sub['fact'].format(**case)),
                ('CUSTOMER','I can contact you through an official channel. What should I have ready?'),
                ('AGENT','The support team can explain the checks for this request.'),
                ('CUSTOMER','I do not want to provide sensitive details on this call.'),
                ('AGENT','You do not need to read out passwords or security codes here.'),
                ('CUSTOMER','Can you address my original request?')]
        return '\n'.join(f'{r}: {t}' for r,t in turns)
    topic=f"I also wanted to ask about {profile['product']}."
    detail=(rng.choice(DISCLOSURE_INTROS)+case['disclosure']+' ') if case['disclosed'] else ''
    credit=(case['credit']['context']+' ') if case['credit'] else ''
    question=rng.choice(QUESTIONS)
    if case['general_request']:question+=' '+rng.choice(BROAD_REQUESTS)
    if length=='single':return service+' '+topic+' '+detail+credit+question
    service_fact=sub['fact'].format(**case)
    turns=[('CUSTOMER',service),('AGENT',service_fact),('CUSTOMER',topic+' '+detail+credit+question)]
    if length=='four_plus':
        # A product explanation and a genuine follow-up occur before the target.
        turns=[('CUSTOMER',service),('AGENT',service_fact),
            ('CUSTOMER',topic+' '+detail+credit),('AGENT',rng.choice(profile['facts'])),
            ('CUSTOMER','Does that explanation itself select a product for me?'),
            ('AGENT','It describes the features; it does not select a product for you.'),
            ('CUSTOMER',question)]
    return '\n'.join(f'{r}: {t}' for r,t in turns)


def record(case,sub,profile,cls,variant,rng):
    d1=d2=d3=d4=d5=False;spans={};scope_basis='authored_response_specification'
    product=profile['product'] if profile else None
    fields={'product':product,'Product':product[0].upper()+product[1:] if product else '',
            'basis':case.get('basis'),'action':case.get('action')}
    context=case['context'];notes=[];credit_recommendation=False
    if cls=='factual_information':
        d5=True
        if profile:
            # The two fact variants explain different features, not polite endings.
            options=profile['facts'];fact=options[variant % len(options)]
            body=fact;d1=True;rule=f"{case['profile_id']}:fact:{variant % len(options)}"
            if variant and case['disclosed']:
                body=f'Using your illustrative balance of {case["amount"]}, simple interest at a hypothetical annual rate of 4% would be {case["interest"]} for one year before tax. '+fact
                # This is explicitly arithmetic on a fictional assumption, not a quote.
                if case['profile_id'] not in ('savings_access','term_deposit','savings_conditions','offset_deposit','foreign_currency_deposit'):
                    body=options[(variant+1)%len(options)]
        else:
            body=sub['fact'].format(**case);d1=sub['product_scope']=='in_scope';rule=case['sub_intent']+':service_fact'
            if variant:
                alternatives={
                    'C04':['Use an official banking support channel for access help, and do not disclose your password or a security code.','Digital banking support can explain the authentication checks for this request.','A shared-device login should be closed when you finish using it.'],
                    'C13':['Customer-detail changes should be requested through a verified banking channel.','The bank can explain which identity or authority checks apply to this detail-change request.','Do not send identity documents to an unsolicited caller.'],
                    'C20':['The payment reference and date can help the bank trace a deposit into the transaction account.','A statement can show interest credited to a deposit account during the statement period.','A registered tax agent can address individual tax deductions; the bank does not determine them in this enquiry.']}
                body=alternatives[case['category']][(variant-1)%3]
                if case['category']=='C20':
                    tax_facts={
                        'tax_statement':['A deposit-account interest statement records interest credited for the relevant reporting period.','Interest-statement periods and statement dates describe the records being requested.'],
                        'government_deposit':['A sender reference and payment date help identify a government payment into a transaction account.','A transaction-account payment record may show a sender reference.'],
                        'withholding_tax':['Withholding from deposit interest can depend on the applicable tax rules and details held by the bank.','A savings-account statement may show interest and tax withheld as separate entries.'],
                        'payment_reference':['The reference on a transaction-account payment may help identify its sender.','The transaction date and sender reference can help locate the payment record.'],
                        'tax_agent_referral':['A registered tax agent can address individual tax-deduction questions.','Individual deductions depend on tax rules and circumstances that a tax agent can assess.']}
                    body=tax_facts[case['sub_intent']][variant-1]
                # Each alternative has explicit scope, never inferred by a regex.
                d1=case['category']=='C20' and case['sub_intent']!='tax_agent_referral'
                rule=case['category']+':service_fact_alternative:'+str((variant-1)%3)
    elif cls=='general_advice':
        d1=d2=True
        scope=rng.choice(GENERAL_SCOPE);opinion=rng.choice(profile['opinions'])
        body=scope+opinion;rule=case['profile_id']+':untailored:'+str(profile['opinions'].index(opinion))
        spans['D2']=evidence('agent_response',body,opinion)
        notes.append('RG244.46–244.49 boundary: no actual consideration is asserted by this authored target; independently review reasonable expectations in full context.')
    elif cls=='personal_advice':
        d1=d2=d4=True
        if case['disclosed'] and variant==0:
            template=rng.choice(ACTUAL);body=template.format(**fields);d3=True;rule='actual:'+str(ACTUAL.index(template))
            spans['D3']=evidence('agent_response',body,case['basis'])
        else:
            if 'implicit_variants' not in case:case['implicit_variants']=rng.sample(IMPLICIT,2)
            template=case['implicit_variants'][variant];body=template.format(**fields);rule='expected_only:'+str(IMPLICIT.index(template))
            notes.append('Suitability opinion appears personalised, without an observable statement of which circumstances were used. It is not a claim of an adequate assessment.')
        spans['D2']=evidence('agent_response',body,body)
        if case['disclosed']:spans['D4_context']=evidence('customer_context',context,case['disclosure'])
    else:
        if case['credit'] and variant==0:
            body=rng.choice(case['credit']['responses']);rule=case['credit']['id']+':recommendation';credit_recommendation=True
        elif profile:
            templates=REFUSALS if variant else CLARIFICATIONS
            template=rng.choice(templates);body=template.format(**fields);d1=True;rule='nonadvisory:'+str(templates.index(template))+('refusal' if variant else 'question')
        else:
            body=rng.choice(['Could you repeat the final part of your question?',
                             'Would you like to add anything before I respond?',
                             'Which part of your question would you like me to address first?'])
            rule=case['category']+':clarification'
    # Disclaimers are independent of target class, not an advice-detection flag.
    disclaimer=case['disclaimer']
    prefix=case['disclaimer_text'] if disclaimer else ''
    if prefix:
        body=prefix+body
        for e in spans.values():
            if e['field']=='agent_response':e['start']+=len(prefix);e['end']+=len(prefix)
    if d1:
        if profile and product in body:
            spans['D1_target']=evidence('agent_response',body,product)
        elif profile:
            spans['D1_context_product']=evidence('customer_context',context,product)
            # Target reference links to the product antecedent, not a fabricated mention.
            reference=next((x for x in ('That option','that product') if x in body),None)
            if reference:spans['D1_target_reference']=evidence('agent_response',body,reference)
        else:
            spans['D1_context_scope']=evidence('customer_context',context,sub['customer'])
    if d5:
        fragment=body[len(prefix):].split('. ')[0]
        spans['D5']=evidence('agent_response',body,fragment)
    lab={'D1':d1,'D2':d2,'D3':d3,'D4':d4,'D5':d5,'D6':cls}
    meta={'call_category':case['category'],'sub_intent':case['sub_intent'],'product_type':case['credit']['id'] if credit_recommendation else case['profile_id'] or 'service_or_credit',
        'scenario_family_id':case['id'],'source_template_id':case['id'],'response_rule_id':rule,
        'source':'direct_synthetic_context_crossing','annotation_status':'v4_construction_labels_pending_independent_review',
        'generator':GENERATOR_VERSION,'human_reviewed':False,'independent_teacher_verified':False,
        'conversation_type':case['length'],'disclosure_present':case['disclosed'] or bool(case['credit']),
        'profile_disclosure_present':case['disclosed'],'general_request_present':case['general_request'],
        'disclaimer':disclaimer,'credit_only_recommendation':credit_recommendation,
        'context_sampled_before_target_class':True,'contrastive':profile is not None,
        'controlled_factor':'target_response_content' if profile else 'service_explanation_vs_clarification',
        'conduct_flags':['credit_conduct_not_assessed'] if credit_recommendation else (['unsupported_suitability_claim'] if d4 and not case['disclosed'] else []),
        'legal_review_required':cls=='general_advice' and (case['disclosed'] or bool(case['credit'])),
        'annotation_notes':notes,'evaluation_role':'context_grouped_development_not_independent_template_benchmark',
        'difficulty':'complex' if case['length']=='four_plus' else ('boundary' if d4 or cls=='general_advice' else 'straightforward'),
        'difficulty_basis':'content heuristic only','personalisation':'actual_and_expected' if d3 else ('reasonable_expectation_only' if d4 else 'not_applicable'),
        'mixed_content':False,'voice_style':False,'asr_imperfections':False,'context_dependent':None,
        'boundaries':(['B19'] if credit_recommendation else ['B18'] if profile and case['profile_id'] in ('savings_access','term_deposit','savings_conditions') else []),
        'annotation':{'generator':GENERATOR_VERSION,'annotator':'authored_response_spec','independent_teacher_verified':False,'human_reviewed':False,'legal_references':['Corporations Act ss763A,764A,765A,766B','ASIC RG244.24–244.49']}}
    if case['category'] in ('C03','C11','C12','C17','C18') and d2:meta['scenario_purpose']='deliberate_product_advice_edge_case_not_measured_traffic'
    row={'id':'UNASSIGNED','schema_version':VERSION,'customer_context':context,'agent_response':body,'labels':lab,'metadata':meta,'evidence':spans}
    validate(row);return row


def make_case(cat,sub,family,profiles,rng,length,profile=True,disclosed=None,credit=None,general_request_fraction=.3,disclaimer_fraction=.15):
    amount=rng.randrange(12,950)*100;months=rng.choice([3,6,9,12,18,24])
    case={'id':f'V4_SCENARIO_{family:04}','category':cat,'sub_intent':sub['id'],'amount':f'${amount:,}','interest':f'${amount*.04:,.0f}','months':months,
        'profile_id':None,'disclosed':False,'credit':credit,'length':length,
        'general_request':profile and rng.random()<general_request_fraction,'disclaimer':rng.random()<disclaimer_fraction}
    case['disclaimer_text']=rng.choice(DISCLAIMERS)
    details={
        'C04':['I am using my own phone.','I have an older phone available as well.','I would prefer to speak to support.','I can use a computer if needed.','I do not want to read a security code aloud.','I am trying from a shared computer.','I need the steps explained slowly.','I can use an official contact number.'],
        'C13':['I can use a secure banking channel.','I have supporting documents available.','I would prefer to ask about the process first.','I can contact the bank through the app.','I need to know which identity checks apply.','I can visit a branch if required.'],
        'C20':['I am looking at my statement.','I have the reporting period in front of me.','I want to understand the record being requested.','I need the explanation for my records.','I have not sent any documents yet.']}
    case['service_detail']=details[cat][((family-1)//5)%len(details[cat])] if cat in details else ''
    if profile:
        pid,p=choose_profile(cat,sub['id'],profiles,rng);case['profile_id']=pid
        case['disclosed']=rng.random()<.5 if disclosed is None else disclosed
        case['disclosure']=p['disclosure'].format(**case);case['basis']=p['basis'].format(**case);case['action']=p['personal_action'].format(**case)
        if pid in ('savings_access','term_deposit','savings_conditions','offset_deposit','foreign_currency_deposit'):
            case['disclosure']+=f' The illustrative balance for this discussion is {case["amount"]}.'
    else:p=None
    case['context']=conversation(case,length,sub,p,rng)
    return case,p


def generate(matrix,taxonomy,config,seed):
    rng=random.Random(seed)
    context_settings={name:config.get(name,default) for name,default in [('general_request_fraction',.3),('disclaimer_fraction',.15)]}
    if any(not 0<=v<=1 for v in context_settings.values()):raise ValueError('Context fractions must be between zero and one')
    profiles=read_yaml(ROOT/'config/dataset/scenario_profiles_v4.yaml')
    counts={k:sum(q.values()) for k,q in matrix.items()};demands=Counter({c:sum(q[c] for q in matrix.values()) for c in CLASSES})
    total=sum(counts.values());rows=[];family=0
    if total<1000:
        # Smoke runs preserve call/class totals; full crossed quotas need pilot scale.
        for cat,q in matrix.items():
            for cls,n in q.items():
                for i in range(n):
                    sub=taxonomy[cat]['sub_intents'][i%5];family+=1
                    length=rng.choice(['single','two_three','four_plus'])
                    case,p=make_case(cat,sub,family,profiles,rng,length,profile=cls in ('general_advice','personal_advice') or cat not in ADMIN,**context_settings)
                    rows.append(record(case,sub,p,cls,0,rng))
    else:
        active={k:n for k,n in counts.items() if k not in ADMIN}
        group_counts=apportion(active,demands['general_advice'])
        # More product-enquiry groups, fewer rare advice pivots, while preserving
        # feasibility for all exact call and class margins.
        for src,dst,pilot_n in [('C02','C09',7),('C03','C08',5),('C17','C15',2),('C11','C07',3)]:
            n=round(pilot_n*total/2000)
            group_counts[src]-=n;group_counts[dst]+=n
        remaining={k:active[k]-4*group_counts[k] for k in active}
        if min(remaining.values())<0:raise ValueError('Infeasible crossed scenario allocation')
        cases=defaultdict(list)
        all_slots=[]
        length_counts=apportion(config['exchanges'],sum(group_counts.values()))
        length_pool=[kind for kind,n in length_counts.items() for _ in range(n)];rng.shuffle(length_pool)
        eligible=[k for k in active if k not in ('C03','C06','C11','C12','C17','C18')]
        # Credit topics are selected before target classes; all four outcomes see
        # the same ordinary-loan/card alternative, not only the other records.
        credit_slots=[(k,j) for k in eligible for j in range(group_counts[k])]
        rng.shuffle(credit_slots);credit_slots=set(credit_slots[:round(150*total/2000)])
        for cat,g in group_counts.items():
            for j in range(g):
                sub=taxonomy[cat]['sub_intents'][j%5];family+=1
                credit=rng.choice(CREDIT) if (cat,j) in credit_slots else None
                case,p=make_case(cat,sub,family,profiles,rng,length_pool.pop(),credit=credit,**context_settings)
                cases[cat].append((case,sub,p))
                for cls in CLASSES:rows.append(record(case,sub,p,cls,0,rng))
        # Remaining active slots have 150 personal, 200 factual and 30 other rows.
        # Extras are at most one per class per scenario, maintaining context balance.
        admin_design={cat:((counts[cat]+3)//4 if cat=='C20' else int(counts[cat]*(1/3 if cat=='C04' else 5/16))) for cat in ADMIN}
        admin_other=sum(admin_design.values())
        admin_factual=sum(counts[cat]-g for cat,g in admin_design.items())
        core=sum(group_counts.values())
        needs={'personal_advice':demands['personal_advice']-core,
               'factual_information':demands['factual_information']-core-admin_factual,
               'other':demands['other']-core-admin_other}
        extra=allocate_extras(group_counts,remaining,needs)
        for cls,bycat in extra.items():
            for cat,n in bycat.items():
                for j in rng.sample(range(len(cases[cat])),n):
                    case,sub,p=cases[cat][j];rows.append(record(case,sub,p,cls,1,rng))
        # Non-product service scenarios still cross facts and clarification, so
        # administrative customer wording is not a perfect factual-class cue.
        for cat in ('C04','C13','C20'):
            g=admin_design[cat];extra=counts[cat]-3*g
            for j in range(g):
                sub=taxonomy[cat]['sub_intents'][j%5];family+=1
                case,p=make_case(cat,sub,family,profiles,rng,rng.choice(['single','two_three','four_plus']),profile=False,**context_settings)
                for cls,v in [('factual_information',0),('factual_information',1),('other',0)]:rows.append(record(case,sub,p,cls,v,rng))
                if j<extra:rows.append(record(case,sub,p,'factual_information',2,rng))
    rng.shuffle(rows)
    for i,r in enumerate(rows,1):r['id']=f'V4_{i:06}'
    # Reject exact duplicates rather than manufacturing superficial unique text.
    seen=set()
    for row in rows:
        key=(row['customer_context'],row['agent_response'])
        if key in seen:raise ValueError('Duplicate generated state; revise authored alternatives')
        seen.add(key)
    if Counter(r['labels']['D6'] for r in rows)!=demands:raise ValueError('D6 quota mismatch')
    if Counter(r['metadata']['call_category'] for r in rows)!=Counter({k:n for k,n in counts.items() if n}):raise ValueError('Call quota mismatch')
    return rows


def allocate_extras(groups,remaining,needs):
    """Small integral max-flow: exact class/call margins, one extra per class/case."""
    capacities=defaultdict(dict)
    def edge(a,b,n):capacities[a][b]=n;capacities[b].setdefault(a,0)
    for cls,n in needs.items():
        edge('source',cls,n)
        for cat,g in groups.items():edge(cls,cat,g)
    for cat,n in remaining.items():edge(cat,'sink',n)
    residual={a:dict(bs) for a,bs in capacities.items()};flow=0
    while True:
        parents={'source':None};q=deque(['source'])
        while q and 'sink' not in parents:
            a=q.popleft()
            for b,n in residual[a].items():
                if n>0 and b not in parents:parents[b]=a;q.append(b)
        if 'sink' not in parents:break
        amount=10**9;b='sink'
        while parents[b] is not None:a=parents[b];amount=min(amount,residual[a][b]);b=a
        b='sink'
        while parents[b] is not None:
            a=parents[b];residual[a][b]-=amount;residual[b][a]+=amount;b=a
        flow+=amount
    if flow!=sum(needs.values()):raise ValueError('Crossed class/call extra quotas infeasible')
    return {cls:{cat:capacities[cls][cat]-residual[cls][cat] for cat in groups} for cls in needs}
