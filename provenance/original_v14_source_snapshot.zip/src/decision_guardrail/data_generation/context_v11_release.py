"""V11 natural dialogue reconstruction with source retirement and executable acceptance gates."""
from collections import Counter,defaultdict
from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
import re
import tempfile
import yaml

from .context_v11_content import materialize,services as service_points,arithmetic_points
from .context_v10_audits import write_coverage_tables,low_support_cues,word_baseline
from .context_v5_release import Groups,lexical_candidates,merge_rows,trajectories_for
from .context_v5_review import digest,sha,write_json,write_rows
from .context_v6_release import VERSION,SPLITS,native_questions,normal_input,validate_rows
from .context_v8_release import read_rows,verify_files,response_cues
from .natural_context_review import duplicate_bodies,full_turn_echoes
from ..dataset import state_text
from ..training_readiness import annotation_fingerprint

GENERATOR='streaming-context-dialogue-v11'
SOURCE='data/generated/streaming_context_v10_release'
EXPOSURE='outputs/context_v11_reconstruction_20261024/review_exposure.json'
ACCEPTANCE='config/dataset/acceptance_context_v11.yaml'
SECOND=re.compile(r'\b(?:you|your|yours|yourself|yourselves)\b',re.I)
PROFILES={'fact':(False,False,False,True),'general':(True,False,False,False),
          'implicit':(True,False,True,False),'linked':(True,True,True,False),
          'basis_only':(True,True,False,False),'mention':(False,False,False,False),'other':(False,False,False,False)}


@lru_cache(maxsize=1)
def reviewed_families(root):
    ids=set(json.loads((root/EXPOSURE).read_text())['excluded_record_ids'])
    return {r['metadata']['contrast_family'] for r in read_rows(root/SOURCE/'records.jsonl') if r['id'] in ids}


def labels(profile,credit=False,scope=True):
    d2,d3,d4,d5=PROFILES[profile]
    return dict(D1=scope,D2=d2,D3=d3,D4=d4,D5=d5,D6=credit and d2,
                D7=('personal_advice' if d3 or d4 else 'general_advice') if d2 else ('factual_information' if d5 else 'other'))


def raw_rows(root):
    raw=[]
    for point in materialize(root)+service_points(root)+list(arithmetic_points()):
        ctx=point['context'];topic=point['topic'];unit='v11-case:'+point['family']
        prefix=point.get('prefix');scenario=unit+':'+(prefix.get('scenario_id','prefix') if prefix else point['point'])
        inp=dict(customer_context=ctx['text'],agent_response=point['text'])
        gold=labels(point['profile'],point['credit'],point.get('product_scope',True))
        witness=[]
        if gold['D3']:
            if not ctx['actual'] or not ctx['need']:raise ValueError('Advice has no actual context basis')
            start=ctx['text'].find(ctx['need'])
            if start<0:raise ValueError('Actual-need span missing')
            witness=[dict(tag='actual_need',start=start,end=start+len(ctx['need']),text=ctx['need'])]
        boundaries={'B02'}
        key=point['point'].split('.')[-1]
        if not gold['D1']:boundaries.add('B01')
        if key in ('selection','selection_question','mixed_selection','qualified_selection','quote_selection','own_quoted_choice'):boundaries.update(('B03','B04','B08'))
        if key=='fit':boundaries.add('B04')
        if ctx['actual'] and not gold['D2']:boundaries.add('B05')
        if key=='basis_fact':boundaries.add('B06')
        if point.get('personalized_fact'):boundaries.add('B06')
        if gold['D3']:boundaries.add('B07')
        if point['disclaimer']:boundaries.add('B09')
        if point['domain']=='service':boundaries.add('B10')
        if point['mixed']:boundaries.add('B11')
        if key=='refusal' or point['point'].startswith('scope_drift.'):boundaries.add('B12')
        if key.startswith('quote') or key.startswith('own_quoted') or ctx['id']=='quoted_adviser':boundaries.add('B13')
        if len(ctx['text'].splitlines())>=3:boundaries.add('B14')
        if key in ('opinion','mixed_opinion','criticism'):boundaries.add('B15')
        if key=='criticism' or (gold['D2'] and re.search(r'\b(avoid|not choose|not add|not rely)\b',point['text'],re.I)):boundaries.add('B16')
        if key=='conditional' or (gold['D2'] and re.search(r'\b(if|when)\b',point['text'],re.I)):boundaries.add('B17')
        if point['domain']=='deposit':boundaries.add('B18')
        if point['credit']:boundaries.add('B19')
        if point['family']=='service-target_document':boundaries.add('B20')
        raw.append(dict(id='sctxv11-'+digest(inp)[:24],schema_version=VERSION,input=inp,labels=gold,advice_present=gold['D2'],
            annotation=dict(profile=point['profile'],rationale=('Authored narrow criterion opinion using an actual need, without an individual suitability selection; D3/D4 boundary requires independent adjudication.' if point['profile']=='basis_only' else 'Explicit speech-act cell bound to this product case and this exact conversation.'),
                rule_version=GENERATOR,status='pending_independent_annotation',independent_review=False,
                author='Codex construction',visible_evidence=point['text'],
                basis_relevance=None,conversation_coherence=None,
                author_quality_proposal=dict(basis_relevance='supported' if gold['D3'] else 'not_applicable',
                    conversation_coherence='unverified',basis=point['case']['reason'],independent=False),
                evidence=dict(context_support_spans=witness,target_spans=[dict(start=0,end=len(point['text']),text=point['text'])])),
            metadata=dict(parent_topic=topic,origin='v11_dialogue_case',units=[unit],source_ids=[],
                source_refs=[dict(scenario_id=scenario,checkpoint_index=prefix['checkpoint_index'] if prefix else 0,
                    total_checkpoints=prefix['total_checkpoints'] if prefix else 1,is_final=prefix['is_final'] if prefix else True,
                    value_added='Explicit context/speech-act contrast and case-specific rationale')],
                split=topic,original_split=None,split_group=topic,contrast_family=point['family'],
                customer_situation_id='ctx-'+digest(ctx['text'])[:20],scenario_product_domains=[point['domain']],
                customer_basis_type='authored_actual_need' if ctx['actual'] else 'not_actual_disclosure',customer_disclosure=ctx['actual'],
                construction_recipe=ctx['id'],coverage_boundary=key,boundaries=sorted(boundaries),
                call_category=point['call'],sub_intent=point['family'],voice_style=ctx['voice'],asr_imperfections=ctx['asr'],
                mixed_content=point['mixed'],disclaimer=point['disclaimer'],context_support_required=gold['D3'],
                boundary_adjudication_required=point['boundary_adjudication'],
                difficulty='complex' if ctx['id'] in ('short','long','voice') else 'boundary' if key.startswith('quote') or gold['D3']!=gold['D4'] else 'straightforward',
                recommendation_style='feature_opinion' if key in ('opinion','general_fact','basis_only') else 'negative' if gold['D2'] and re.search(r'\b(not|avoid|poor|weaker)\b',point['text'],re.I) else 'selection' if gold['D2'] else 'none',
                personalized_numeric_fact=bool(point.get('personalized_fact')),
                audible_stage=point.get('partial_annotation'),
                source_case_design_reviewed=point['family'] in reviewed_families(root),
                intentional_speech_act_drift=bool(prefix and prefix.get('scenario_id')=='audible_stages:scope_drift'),
                recommendation_withdrawn_in_target=bool(prefix and prefix.get('withdrawn')),recommendation_withdrawn=bool(prefix and prefix.get('withdrawn')),
                native_export_eligible=True,synthetic=True,independent_annotation=False,
                lineage=[dict(version=GENERATOR,authored_case=point['family'],authored_point=point['point'])])))
    rows,merged=merge_rows(raw)
    return rows,merged


def assign(rows):
    groups=Groups();exact={};contexts={}
    for r in rows:
        parent=r['metadata']['parent_topic'];groups.find(parent)
        for key,owners in ((r['input']['agent_response'],exact),(r['input']['customer_context'],contexts)):
            if key in owners:groups.union(parent,owners[key])
            else:owners[key]=parent
    # One representative per parent/target avoids multiplying identical
    # counterfactual comparisons while closing every lexical neighbour.
    unique={}
    for r in rows:unique.setdefault((r['metadata']['parent_topic'],r['input']['agent_response']),r)
    neighbours=lexical_candidates(list(unique.values()))
    for a,b,_ in neighbours:groups.union(a['metadata']['parent_topic'],b['metadata']['parent_topic'])
    components=defaultdict(list)
    for r in rows:components[groups.find(r['metadata']['parent_topic'])].append(r)
    product=[(k,v) for k,v in components.items() if any(r['metadata']['scenario_product_domains']!=['service'] for r in v)]
    if len(product)<4:raise ValueError('Common wording has collapsed the product families into fewer than four split components')
    counts=Counter();ownership={};targets=dict(zip(SPLITS,(.7,.1,.1,.1)))
    forced={key for key,rs in components.items() if any(r['metadata']['source_case_design_reviewed'] for r in rs)}
    for key in forced:ownership[key]='train';counts['train']+=len(components[key])
    available=sorted(((k,v) for k,v in components.items() if k not in forced),key=lambda item:(-len(item[1]),item[0]))
    credit=[(k,v) for k,v in available if any(r['labels']['D6'] for r in v)]
    if len(credit)<3:raise ValueError('Too few unexposed credit-topic groups for held-out partitions')
    for split,(key,component) in zip(SPLITS[1:],credit[:3],strict=True):ownership[key]=split;counts[split]+=len(component)
    for key,component in available:
        if key in ownership:continue
        split=min(SPLITS,key=lambda s:(counts[s]/targets[s],SPLITS.index(s)))
        ownership[key]=split;counts[split]+=len(component)

    for r in rows:
        group=groups.find(r['metadata']['parent_topic'])
        r['metadata'].update(split=ownership[group],split_group=group)
    return dict(components=len(components),lexical_family_links=len(neighbours),split_counts=dict(counts))


def historical_paths(root):
    from .context_v10_release import historical_paths as previous_paths
    return list(dict.fromkeys(previous_paths(root)+[root/SOURCE/'records.jsonl',root/SOURCE/'quarantine.jsonl',root/SOURCE/'exposed_development/records.jsonl']))


def historical_inputs(root):
    found={}
    for path in historical_paths(root):
        for r in read_rows(path):found[normal_input(r['input'])]=r
    return list(found.values())


def acceptance(rows,cfg,base_report):
    from .context_v11_audits import naturalness_report,paired_topic_diagnostic
    report=naturalness_report(rows);report['paired_topic_response_diagnostic']=paired_topic_diagnostic(rows,read_rows(Path(__file__).resolve().parents[3]/SOURCE/'records.jsonl'));failures=[];n=len(rows)
    def require(ok,key,actual):
        if not ok:failures.append(dict(check=key,actual=actual))
    require(n>cfg['minimum_records_exclusive'],'minimum_records',n)
    require(len({r['metadata']['parent_topic'] for r in rows if r['metadata']['scenario_product_domains']!=['service']})==cfg['required_product_topics'],'product_topics',None)
    calls=Counter(r['metadata']['call_category'] for r in rows)
    require(set(calls)=={f'C{i:02}' for i in range(1,21)} and min(calls.values())>=cfg['minimum_rows_per_call_category'],'call_coverage',dict(calls))
    classes=Counter(r['labels']['D7'] for r in rows)
    require(min(classes.values())>=cfg['minimum_each_final_class'] and len(classes)==4,'class_coverage',dict(classes))
    for key,(lo,hi) in cfg['fractions'].items():require(lo<=report['fractions'][key]<=hi,key,report['fractions'][key])
    require(report['personal_i_would_fraction']<=cfg['maximum_personal_i_would_fraction'],'personal_i_would',report['personal_i_would_fraction'])
    for key in ('self_quotation_rows','invented_speaker_rows','counterweight_rows'):
        require(report[key]<=cfg['maximum_'+key],key,report[key])
    require(report['max_noninitial_turn_repetitions']<=cfg['maximum_noninitial_turn_repetitions'],'repeated_turns',report['max_noninitial_turn_repetitions'])
    candidate=report['paired_topic_response_diagnostic']['candidate']['accuracy']
    reference=report['paired_topic_response_diagnostic']['reference_v10']['accuracy']
    require(candidate<=cfg['maximum_response_only_nb_accuracy'] and candidate<=reference,'paired_topic_response_only_nb',dict(candidate=candidate,reference=reference))
    require(not any(r['metadata']['source_case_design_reviewed'] and r['metadata']['split']!='train' for r in rows),'review_derived_case_in_heldout',None)
    report.update(call_counts=dict(calls),acceptance_failures=failures,all_cpu_acceptance_gates_passed=not failures)
    return report


def inspect(rows,forbidden,qs,cfg):
    report,trajectories=validate_rows(rows,forbidden,qs)
    if duplicate_bodies(rows):raise ValueError('Same-context duplicate bodies')
    if full_turn_echoes(rows):raise ValueError('Copied full customer turns')
    if lexical_candidates(rows):raise ValueError('Cross-split lexical relatives remain')
    for r in rows:
        for span in r['annotation']['evidence']['context_support_spans']:
            if r['input']['customer_context'][span['start']:span['end']]!=span['text']:raise ValueError('Invalid context span')
    for split in SPLITS:
        rs=[r for r in rows if r['metadata']['split']==split]
        if len({r['labels']['D7'] for r in rs})!=4 or not any(r['labels']['D3'] for r in rs) or not any(r['labels']['D6'] for r in rs):
            raise ValueError('A split is missing a class, actual-basis case or credit advice')
    cues=response_cues(rows)
    report['response_cues_support100_precision95']=len(cues)
    report['response_cues_1to3gram_support100_precision95']=sum(len(c['phrase'].split())<=3 for c in cues)
    report.update(acceptance(rows,cfg,report))
    report.update(generator=GENERATOR,legacy_rows_retained=0,all_rows_fresh_authored_cases=False,shared_product_case_designs_declared=True,
        class_counts_by_split={s:dict(Counter(r['labels']['D7'] for r in rows if r['metadata']['split']==s)) for s in SPLITS},
        binary_counts={d:dict(Counter(str(r['labels'][d]).lower() for r in rows)) for d in ('D1','D2','D3','D4','D5','D6')},
        limitations=['All labels and author quality proposals require independent annotation; zero approved training rows.',
            'The 480 v10 D3-only rows are retired development material. Rewritten natural D3-only proposals still require group adjudication; no policy decision or independent approval is inferred.',
            'B19 maps to current credit-advice scope; B20 covers document/exclusion questions operationally, not statutory validation.',
            'Historic pilot call weights are a reference rather than full-corpus class/call quotas.',
            'Shared source designs are not independent challenges; rewritten reviewed designs are train-only. Low-support phrase warnings remain diagnostic.',
            'No embedding screening, native tokenizer coverage, model evaluation or GPU smoke/reload has been performed.'])
    return report,trajectories


def build(root,output,allow_failed=False):
    if output.exists():raise ValueError('Use a new output path; preserve frozen releases')
    verify_files(root/SOURCE)
    cfg=yaml.safe_load((root/ACCEPTANCE).read_text());rows,merged=raw_rows(root);splits=assign(rows)
    schema,qs=native_questions(root);forbidden=historical_inputs(root)
    report,trajectories=inspect(rows,forbidden,qs,cfg)
    report.update(shared_prefix_inputs_merged=merged,split_assignment=splits)
    if report['acceptance_failures'] and not allow_failed:raise ValueError('Acceptance gates failed: '+json.dumps(report['acceptance_failures']))
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='context-v10-',dir=output.parent) as temp:
        stage=Path(temp)/'release';stage.mkdir()
        for folder in ('splits','construction_clef','clef_index','exposed_development'):(stage/folder).mkdir()
        write_rows(stage/'records.jsonl',rows);write_json(stage/'quality_report.json',report)
        write_json(stage/'trajectories.json',trajectories);write_json(stage/'questions.json',schema);write_json(stage/'native_questions.json',qs)
        write_json(stage/'annotation_ledger.json',[])
        write_rows(stage/'D3_only_group_adjudication.jsonl',[dict(record_id=r['id'],input=r['input'],proposed_labels=r['labels'],status='pending_block_adjudication') for r in rows if r['labels']['D3'] and not r['labels']['D4']])
        write_rows(stage/'review_queue.jsonl',[dict(record_id=r['id'],input_labels_sha256=annotation_fingerprint(r),
            status='pending_independent_annotation',basis_relevance=None,conversation_coherence=None,
            adjudication_required=r['metadata']['boundary_adjudication_required']) for r in rows])
        write_json(stage/'response_cue_audit.json',response_cues(rows))
        write_json(stage/'response_cues_low_support_diagnostic.json',low_support_cues(rows))
        write_json(stage/'word_baselines.json',{field:word_baseline(rows,field) for field in ('customer_context','agent_response')})
        diversity=write_coverage_tables(rows,stage/'coverage',yaml.safe_load((root/'config/dataset/distribution_pilot.yaml').read_text()),cfg['minimum_rows_per_call_category'])
        diversity['source_status']='Shared product-case designs with newly authored dialogue details, selections, feature views and service requests; zero independent approvals.'
        write_json(stage/'diversity_report.json',diversity)
        case_points={p['family']:p for p in materialize(root)}
        write_rows(stage/'author_case_quality_proposals.jsonl',[dict(case_id=key,product_topic=p['topic'],
            actual_need=p['case']['need'],reason=p['case']['reason'],criterion=p['case']['criterion'],
            criterion_opinion=p['case']['criterion_opinion'],independent_approval=False)
            for key,p in sorted(case_points.items())])
        source=read_rows(root/SOURCE/'records.jsonl');exposure=json.loads((root/EXPOSURE).read_text());exposed_ids=set(exposure['excluded_record_ids'])
        write_rows(stage/'source_dispositions.jsonl',[dict(source_id=r['id'],source_sha256=digest(r),
            disposition='review_exposure_retired' if r['id'] in exposed_ids else 'retired_v10_framing_or_context',
            candidate_id=None,reason='Rewritten product-specific turns and staged speech, not meta-frame balance. Source designs remain development lineage.') for r in source])
        write_rows(stage/'development_D3_only_adjudication.jsonl',[{**r,'metadata':{**r['metadata'],'split':None,'native_export_eligible':False}} for r in source if r['labels']['D3'] and not r['labels']['D4']])
        write_json(stage/'exposure_ledger.json',dict(prior_forbidden_inputs=len(forbidden),new_review_exposure=exposure,
            historical_sources_retained_in_candidates=0))
        write_rows(stage/'quarantine.jsonl',[dict(**{k:v for k,v in r.items() if k!='metadata'},metadata={**r['metadata'],'split':None,'native_export_eligible':False,
            'retirement_reason':'Superseded construction recipe; not a finding that every row is wrong.'}) for r in source])
        write_rows(stage/'exposed_development/records.jsonl',[dict(**{k:v for k,v in r.items() if k!='metadata'},
            metadata={**r['metadata'],'source_split':r['metadata']['split'],'split':None,
                      'native_export_eligible':False,'exposed_development_only':True}) for r in source if r['id'] in exposed_ids])
        index={r['id']:i for i,r in enumerate(rows,1)};write_json(stage/'line_index.json',index)
        for split in SPLITS:
            selected=[r for r in rows if r['metadata']['split']==split]
            write_rows(stage/'splits'/f'{split}.jsonl',selected)
            write_rows(stage/'construction_clef'/f'{split}.jsonl',[dict(state=state_text(**r['input']),questions=qs,gold=r['labels']) for r in selected])
            write_rows(stage/'clef_index'/f'{split}.jsonl',[dict(export_line=i,record_id=r['id'],records_jsonl_line=index[r['id']],recommendation_withdrawn_in_target=r['metadata']['recommendation_withdrawn_in_target']) for i,r in enumerate(selected,1)])
        (stage/'annotation_standard.md').write_text((root/'docs/annotation_standard_streaming_v6.md').read_text()+'\n\n'+(root/'docs/annotation_standard_streaming_v11.md').read_text())
        (stage/'acceptance.yaml').write_bytes((root/ACCEPTANCE).read_bytes())
        (stage/'README.md').write_text('# V11 dialogue candidates\n\n'+str(len(rows))+' fresh snapshots; zero approved training rows. No v10 inputs retained. Shared case designs are declared; reviewed designs are excluded from held-out partitions.\n'
            'Read quality_report.json for measured acceptance and limitations. Construction exports are CPU/review data, not approved training data.\n')
        contexts=list(dict.fromkeys(r['input']['customer_context'] for r in rows));lookup={c:i for i,c in enumerate(contexts)}
        view=[dict(id=r['id'],input=dict(customer_context=lookup[r['input']['customer_context']],agent_response=r['input']['agent_response']),labels=r['labels'],advice_present=r['advice_present'],
            annotation=dict(rationale=r['annotation']['rationale'],visible_evidence=r['input']['agent_response']),metadata={k:r['metadata'][k] for k in ('contrast_family','split','recommendation_withdrawn','coverage_boundary','source_refs')}) for r in rows]
        payload=dict(rows=view,contexts=contexts,questions=schema,report={**report,'authored_contrast_families':len({r['metadata']['contrast_family'] for r in rows}),'credit_advice_rows':sum(r['labels']['D6'] for r in rows)},dataset_id=digest(rows))
        page=(root/'data/generated/streaming_context_v10_release/review.html').read_text();marker='<script id="dataset" type="application/json">'
        before,sep,tail=page.partition(marker);_,end,after=tail.partition('</script>')
        if not sep or not end:raise ValueError('Missing compact review template boundary')
        page=(before+marker+json.dumps(payload,ensure_ascii=False).replace('<','\\u003c')+'</script>'+after).replace('Context v10 ·','Context v11 ·').replace('No pending or unknown labels','Proposed labels · independent review needed')
        page=page.replace('</select></div>','</select><select id="kindFilter" aria-label="Filter response or conversation type"><option value="">All response types</option><option value="full">Complete responses</option><option value="partial">Voice: unfinished prefixes only</option><option value="voice">Voice: speech trajectories</option><option value="single">Single-turn calls</option><option value="multi">Multi-turn calls</option></select></div>',1)
        page=page.replace("function pool(){",'''function kindMatch(r){const k=$('kindFilter').value,refs=r.metadata.source_refs;return !k||(k==='full'&&refs.some(x=>x.is_final))||(k==='partial'&&refs.every(x=>!x.is_final))||(k==='voice'&&refs.some(x=>x.scenario_id.includes('audible_stages:')))||(k==='single'&&!r.input.customer_context.includes('\\n'))||(k==='multi'&&r.input.customer_context.includes('\\n'))}function pool(){''')
        page=page.replace("return rows.filter(r=>(!$('classFilter')", "return rows.filter(r=>kindMatch(r)&&(!$('classFilter')")
        page=page.replace("row.metadata.source_refs[0];path=", "row.metadata.source_refs.find(x=>($('kindFilter').value==='full'?x.is_final:x.scenario_id.includes('audible_stages:')))||row.metadata.source_refs[0];path=")
        page=page.replace("$('classFilter').onchange=random;", "$('kindFilter').onchange=random;$('classFilter').onchange=random;")
        page=page.replace("[data.report.scenarios,'constructed trajectories']", "[data.report.authored_speech_trajectories,'staged speech trajectories']")
        page=page.replace('<label for="comment">Comment</label>','<label for="coherence">Does this fit the conversation?</label><select id="coherence"><option value="">Not assessed</option><option value="pass">Pass</option><option value="fail">Fail</option><option value="uncertain">Uncertain</option></select><label for="relevance">Does the reason fit the product and need?</label><select id="relevance"><option value="">Not assessed</option><option value="supported">Supported</option><option value="unsupported">Unsupported</option><option value="uncertain">Uncertain</option><option value="not_applicable">Not applicable</option></select><label for="comment">Comment</label>')
        page=page.replace("const meaningful=$('comment').value.trim()", "const meaningful=$('coherence').value||$('relevance').value||$('comment').value.trim()")
        page=page.replace("suggested_labels:suggested,updated_at:", "suggested_labels:suggested,conversation_coherence:$('coherence').value||null,basis_relevance:$('relevance').value||null,updated_at:")
        page=page.replace("$('comment').value=note.comment||'';", "$('comment').value=note.comment||'';$('coherence').value=note.conversation_coherence||'';$('relevance').value=note.basis_relevance||'';")
        page=page.replace("['reviewer','status','comment']", "['reviewer','status','comment','coherence','relevance']")
        (stage/'review.html').write_text(page)

        sources=[SOURCE+'/review.html',SOURCE+'/manifest.json',EXPOSURE,ACCEPTANCE,'src/decision_guardrail/data_generation/context_v11_content.py',
            'src/decision_guardrail/data_generation/context_v11_release.py',
            'src/decision_guardrail/data_generation/context_v11_audits.py',
            'config/dataset/distribution_pilot.yaml',
            'config/dataset/question_schema_streaming_v6.yaml','config/dataset/question_schema_runtime_v6.yaml',
            'src/decision_guardrail/data_generation/streaming_15k_catalog.py',
            'src/decision_guardrail/data_generation/context_v5_release.py',
            'src/decision_guardrail/data_generation/context_v5_review.py',
            'src/decision_guardrail/data_generation/context_v6_release.py',
            'src/decision_guardrail/data_generation/context_v8_release.py',
            'src/decision_guardrail/data_generation/natural_context_review.py',
            'src/decision_guardrail/dataset.py','src/decision_guardrail/schema.py',
            'src/decision_guardrail/training_readiness.py','scripts/build_context_v11_release.py',
            'docs/annotation_standard_streaming_v6.md','docs/annotation_standard_streaming_v11.md','data/reviews/claude_streaming_context_v10_review/record_review.jsonl','data/reviews/claude_streaming_context_v10_review/review_report.md']
        sources += [str(p.relative_to(root)) for p in sorted((root/'data/authored/streaming_context_v11').glob('*.py'))]
        sources += [str(p.relative_to(root)) for p in sorted((root/'data/authored/streaming_context_v10').glob('*.py'))]
        sources += ['src/decision_guardrail/data_generation/context_v10_content.py','src/decision_guardrail/data_generation/context_v10_release.py','src/decision_guardrail/data_generation/context_v10_audits.py','src/decision_guardrail/streaming_data.py']
        sources += [str(p.relative_to(root)) for p in historical_paths(root)]
        write_json(stage/'manifest.json',dict(schema_version=VERSION,generator=GENERATOR,records=len(rows),scenarios=len(trajectories),
            status='pre_annotation_not_trainable',training_ready=False,approved_training_records=0,
            construction_acceptance_passed=not report['acceptance_failures'],native_export_directory='construction_clef',annotation_ledger_path='annotation_ledger.json',
            source_hashes={s:sha(root/s) for s in sources},files={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}))
        stage.rename(output)
    return report


def verify(root,output):
    m=verify_files(output)
    if m['generator']!=GENERATOR or m['training_ready'] is not False or m['approved_training_records']!=0:raise ValueError('Wrong v10 construction manifest')
    for path,h in m['source_hashes'].items():
        if sha(root/path)!=h:raise ValueError('Source hash mismatch: '+path)
    rows,merged=raw_rows(root);splits=assign(rows)
    if read_rows(output/'records.jsonl')!=rows:raise ValueError('Reconstruction differs from authored cases')
    cfg=yaml.safe_load((root/ACCEPTANCE).read_text());_,qs=native_questions(root)
    report,trajectories=inspect(rows,historical_inputs(root),qs,cfg);report.update(shared_prefix_inputs_merged=merged,split_assignment=splits)
    if report!=json.loads((output/'quality_report.json').read_text()) or report['acceptance_failures']:raise ValueError('Acceptance report failed or differs')
    if trajectories!=json.loads((output/'trajectories.json').read_text()):raise ValueError('Trajectory export differs')
    if (output/'clef').exists() or json.loads((output/'annotation_ledger.json').read_text())!=[]:raise ValueError('Unapproved native training data')
    for split in SPLITS:
        selected=[r for r in rows if r['metadata']['split']==split]
        if read_rows(output/'splits'/f'{split}.jsonl')!=selected or read_rows(output/'construction_clef'/f'{split}.jsonl')!=[dict(state=state_text(**r['input']),questions=qs,gold=r['labels']) for r in selected]:raise ValueError('Split export differs')
    return report
