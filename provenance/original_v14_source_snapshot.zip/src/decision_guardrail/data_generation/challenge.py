"""New authored challenge candidates, isolated from all development splits.

Same local author, construction labels, no independent annotation or legal review.
The case bank is separate from the v2/v3 response templates. Exact string/template
checks are reported; semantic independence is not inferred from those checks.
"""
from collections import Counter
from datetime import datetime,timezone
import json
from pathlib import Path
from .schemas import ROOT,CLASSES,validate,questions
from .pipeline import write_json,write_jsonl,sha
from .clef_converter import convert
from .remediation import VERSION,mask_core,span


def make_record(identity,category,product,context,response,labels,family,length,notes):
    evidence={}
    if labels['D2']:evidence['D2_target']=span('agent_response',response,response)
    if labels['D3']:evidence['D3_target']=span('agent_response',response,response)
    if labels['D4']:evidence['D4_context']=span('customer_context',context,context)
    if labels['D5']:evidence['D5_target']=span('agent_response',response,response)
    return {'id':identity,'schema_version':'financial_advice_v1','customer_context':context,'agent_response':response,'labels':labels,'metadata':{'call_category':category,'sub_intent':'authored_challenge','product_type':product,'source':'synthetic_authored_case_bank','source_template_id':family,'scenario_family_id':family,'annotation_status':'challenge_candidate_pending_independent_review','human_reviewed':False,'independent_teacher_verified':False,'conversation_type':length,'evaluation_role':'challenge_candidate_not_validated_benchmark','notes':notes,'annotation':{'generator':VERSION,'annotator':'local_authored_case_design','verifier':None,'human_reviewed':False,'independent_teacher_verified':False}},'evidence':evidence}


def labels(cls,d1=True,d3=False):
    advice=cls in ('general_advice','personal_advice')
    return {'D1':d1,'D2':advice,'D3':d3,'D4':cls=='personal_advice','D5':cls=='factual_information','D6':cls}


def context(case,cls,length,case_index):
    # Request wording is shared across outcomes: asking for facts or asking for
    # advice must not determine what the target actually supplies.
    use_personal = cls == 'personal_advice' or (cls != 'general_advice' and case_index % 2 == 0)
    if cls == 'other' and case['category'] in ('C03','C17','C18'):
        use_personal = True
    first = case['personal'] if use_personal else case['generic']
    question = 'What would you say about that?'
    if length == 'single':return first+' '+question
    if length == 'two_three':
        return f'CUSTOMER: {first}\nAGENT: What would you like to discuss?\nCUSTOMER: {question}'
    # Earlier opinion appears in every class. The final target, not that earlier
    # opinion, is the supervised response.
    turns=[('CUSTOMER',first),('AGENT',case['general']),
        ('CUSTOMER','I heard that view. There is another part I want to understand.'),
        ('AGENT','Which part would you like to return to?'),
        ('CUSTOMER',case['generic']),
        ('AGENT','I can address that question.'),('CUSTOMER',question)]
    return '\n'.join(f'{role}: {text}' for role,text in turns)


def run(output,pilot):
    out=Path(output)
    if out.exists():raise ValueError('Challenge output must be new')
    bank=ROOT/'data/authoring/challenge_cases_v1.jsonl'
    cases=[json.loads(s) for s in bank.read_text().splitlines() if s]
    if len(cases)!=48:raise ValueError('Expected 48 authored case seeds')
    records=[]
    for i,case in enumerate(cases):
        length=('four_plus' if i<16 else 'two_three' if i<32 else 'single')
        for cls,key in zip(CLASSES,('fact','general','tailored','other')):
            response=case[key];ctx=context(case,cls,length,i)
            lab=labels(cls,d1=case.get('other_scope',False) if cls=='other' else True,d3=cls=='personal_advice')
            r=make_record(f'CH_{len(records)+1:04}',case['category'],case['product'],ctx,response,lab,f'AUTHORED_CASE_{i+1:02}',length,'Facts and opinions are deliberately distinct. Earlier advice does not determine the final target label. Labels require independent review.')
            validate(r);records.append(r)
    # Same target endorsement; only the earlier option and its customer setting vary.
    for family,wording in [(1,'Yes, I recommend that option.'),(2,'That is the option I would choose.')]:
        variants=[
            ('factual_information','C02','debit_card','I have misplaced my debit card. Is temporarily locking the card while I report it the security step you mean?',True),
            ('general_advice','C08','term_deposit','For a product-category discussion, is a term deposit an option you favour for a fixed investment term?',True),
            ('personal_advice','C08','term_deposit','I will not need my savings for twelve months, want a fixed rate and asked you to choose what suits me. Is the twelve-month term deposit your choice for me?',True),
            ('other','C10','ordinary_credit','I am comparing ordinary home loans. Is refinancing my existing ordinary home loan the option you prefer?',False),
        ]
        for cls,cat,product,last,d1 in variants:
            ctx=f'CUSTOMER: I want to check which option we are discussing.\nAGENT: Please identify the option you want me to address.\nCUSTOMER: {last}'
            r=make_record(f'CH_{len(records)+1:04}',cat,product,ctx,wording,labels(cls,d1=d1),f'CONTEXT_SWITCH_{family}','two_three','Controlled context switch with an identical target endorsement. Product scope, procedural action and personal expectations come from the context. This is not a validated legal ablation result.')
            r['metadata']['controlled_factor']='context_of_endorsed_option';validate(r);records.append(r)
    original=[json.loads(s) for s in (Path(pilot)/'master_dataset.jsonl').read_text().splitlines()]
    existing={mask_core(r['agent_response']) for r in original}
    overlaps=[r['id'] for r in records if mask_core(r['agent_response']) in existing]
    out.mkdir(parents=True)
    write_jsonl(out/'master_dataset.jsonl',records);write_jsonl(out/'clef.jsonl',[convert(r) for r in records]);write_json(out/'questions.json',questions())
    report={'records':len(records),'classes':dict(Counter(r['labels']['D6'] for r in records)),'lengths':dict(Counter(r['metadata']['conversation_type'] for r in records)),'authored_case_seeds':48,'controlled_context_switch_families':2,'masked_response_core_overlap_with_corrected_pilot':overlaps,'independently_authored':False,'independently_annotated':False,'human_legal_reviewed':False,'embedding_semantic_leakage_screen':'not_run','status':'candidate_challenge_set_requires_independent_review','notes':['Written from a new case bank; not sampled from the v2 generator.','Exact/masked text disjointness is not proof of semantic independence.','Contains deliberate counterexamples to target-only and context-only classification.','Do not tune the main generator against this set and then continue calling it held out.']}
    write_json(out/'challenge_report.json',report)
    (out/'README.md').write_text('# Authored challenge candidates\n\n200 separate cases, 50 per class, using a new 48-case bank plus two controlled context-switch families. All labels are local design annotations pending independent review.\n\nThese cases are outside the corrected pilot splits. No independent author, legal reviewer, external teacher or embedding-based leakage audit was used. Zero masked response-core overlap, if reported, is a lexical measurement only.\n')
    write_json(out/'manifest.json',{'version':'challenge-candidates-v1','generated_at_utc':datetime.now(timezone.utc).isoformat(),'source_bank_sha256':sha(bank),'compared_pilot_sha256':sha(Path(pilot)/'master_dataset.jsonl'),'files':{str(p.relative_to(out)):sha(p) for p in out.iterdir() if p.is_file() and p.name!='manifest.json'}})
    return report
