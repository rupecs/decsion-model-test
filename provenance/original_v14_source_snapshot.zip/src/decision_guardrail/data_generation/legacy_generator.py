"""Designed synthetic examples, labelled by construction, never teacher verified.

Template structure is deliberately visible in provenance. Broad response patterns
are shared across splits; these are development splits, not independent benchmarks.
"""
import random
import re
from .schemas import CLASSES, VERSION

GENERATOR_VERSION = 'local-bootstrap-remediated-v3'

PRODUCTS = [
    ('at_call_savings', 'an at-call savings account', 'An at-call savings account has access and interest conditions specified in its terms.', 'a cash buffer for unexpected bills', 'my income changes from week to week and I need money available for unexpected bills'),
    ('term_deposit', 'a term deposit', 'A term deposit holds money for an agreed term and early access may be restricted.', 'money reserved for a planned expense', 'I have a planned expense next year and do not expect to use this money before then'),
    ('managed_fund', 'a diversified managed fund', 'A diversified managed fund pools investments and can lose value.', 'long-term investment growth', 'I want growth over ten years, accept market losses and already have separate emergency savings'),
    ('superannuation', 'a superannuation fund', 'Superannuation generally has access restrictions and contribution rules.', 'retirement savings', 'I want to build retirement savings, have spare income and understand the money has access restrictions'),
    ('insurance', 'an income protection insurance policy', 'Income protection insurance has policy limits, exclusions and waiting periods.', 'protection against loss of employment income', 'my household relies on my wages and I am worried about being unable to work because of illness'),
]
GENERAL = [
    'For investors seeking {goal}, {product} can be a good option.',
    'I favour {product} as a product class for {goal}.',
    'For the general objective of {goal}, consider {product}.',
    'People seeking {goal} could benefit from considering {product}.',
    'My broad recommendation for {goal} is to consider {product}.',
    'In a product comparison, I would lean towards {product} for {goal}.',
    'I think {product} is worth considering for {goal}.',
    'One option I rate favourably for {goal} is {product}.',
    'For {goal}, I would put {product} on an investor’s shortlist.',
    'For people interested in {goal}, I see merit in {product}.',
    'In my view, {product} deserves consideration for {goal}.',
    'I would generally favour considering {product} for {goal}.',
]
PERSONAL = [
    'Because you said {circ}, I recommend putting {amount} towards {product}.',
    'Your aim is {goal}, and you told me {circ}. I would choose {product} for your {amount}.',
    'Taking your situation into account — {circ} — {product} would suit you for that {amount}.',
    'I have weighed the needs you described. Put the {amount} into {product}; that is my recommendation for you.',
    'With {amount} available and your stated need for {goal}, my choice for you is {product}.',
    'For you, {product} is the option I favour: you explained that {circ}.',
    'I would direct your {amount} towards {product}, based on the needs you described.',
    'The fit I see for your situation is {product}. That recommendation takes account of what you told me about {goal}.',
]
EXPECTED = [
    'My recommendation for you is {product}. Put the {amount} there.',
    'The option I would pick for you is {product}.',
    'For your next step, go with {product} for the {amount}.',
    'Here is the choice I recommend for you: {product}.',
    'My pick for you would be {product}, using the {amount} you mentioned.',
    'For you, I would select {product}.',
]
OTHER = [
    'I hear how frustrating this has been.',
    'Thanks for explaining that. Take your time.',
    'Would you like a moment before we continue?',
    'I understand this has been a difficult call.',
    'Could you repeat the last part of your question?',
    'I am here and listening.',
    'Is there anything else you wanted to tell me?',
    'Thank you. I have heard what you said.',
]
PREFIXES = ['', 'Yeah, look, ', 'Hi, ', 'Could you help? ', 'Right, ', 'Sorry, one more thing. ', 'G’day, ', 'I am calling because ']
PIVOTS = [
    'Separately, I have {amount}; {circ}. Could we discuss {product}?',
    'Before we finish, there is {amount} I am thinking about. My situation is that {circ}. What about {product}?',
    'I have another question about {product}. I have {amount} available, and {circ}.',
    'There is also {amount} I have not allocated. The thing is, {circ}. Can we talk about {product}?',
    'Could we cover {product} as well? With {amount} available, I am thinking about my options; {circ}.',
    'On another point, {circ}. I have {amount} available. I wanted to ask about {product}.',
    'Once that is covered, can we discuss {product}? I have {amount}, and {circ}.',
    'One last question: I have {amount} to consider, and {circ}. Could you comment on {product}?',
    'I would also like to understand {product}. My available amount is {amount}; {circ}.',
    'Another reason for calling is that {circ}. There is {amount} involved, and I have been looking at {product}.',
    'Could I raise a second topic? I have {amount}. Given that {circ}, I have a question about {product}.',
    'While I have you on the line, I wanted to ask about {product}. I have {amount}, and {circ}.',
]
GENERAL_REQUESTS = [
    'Please keep the product discussion general, without assessing what suits me.',
    'I only want a broad product opinion, rather than an assessment of my position.',
    'For that product question, could you speak about investors generally?',
    'Please answer that as a general product discussion; I am not asking you to assess my needs.',
    'Set my personal details aside for the product discussion. I want a broad view of the product class.',
    'A general view of the product category is all I am after here.',
]
RESPONSE_OPENERS = ['', 'Okay. ', 'All right. ', 'Sure. ', 'Thanks for explaining. ',
    'I understand the question. ', 'Let me address that. ', 'On that point, ',
    'To answer your question, ', 'Yes, I can discuss that. ', 'We can talk through that. ',
    'I hear you. ', 'Let us take that part first. ', 'Thanks for checking. ',
    'I can address the point you raised. ', 'We can focus on that question. ']
RESPONSE_ENDINGS = ['', ' Would you like me to explain that in another way?',
    ' Let me know which part needs more explanation.', ' We can take this slowly.',
    ' Is that the point you were asking about?', ' Shall I go over that again?',
    ' You can ask me to repeat any part of that.', ' Would a shorter explanation help?',
    ' Please tell me if I have misunderstood the question.', ' We can pause there if you like.',
    ' Does that address the question you raised?', ' What would you like to discuss next?',
    ' Is there a part you would like me to clarify?', ' Take a moment if you need to.',
    ' I can repeat the explanation more slowly.', ' Would you like to continue with that topic?']


def span(conv, turn, text):
    start = conv[turn]['text'].index(text)
    return {'turn_index':turn,'start':start,'end':start+len(text),'text':text}


def flatten(row):
    """Match the supplied master format; retain previous turns as role-marked context."""
    conv = row.pop('conversation')
    row.pop('target_turn_index')
    if len(conv) == 2:
        context = conv[0]['text']
    else:
        context = '\n'.join(f"{t['role'].upper()}: {t['text']}" for t in conv[:-1])
    row['customer_context'] = context
    row['agent_response'] = conv[-1]['text']
    metadata = row.pop('coverage')
    annotation = row.pop('annotation')
    metadata.update({'source': 'synthetic', 'annotation_status': 'bootstrap_unverified',
                     'human_reviewed': False, 'annotation': annotation})
    metadata['difficulty'] = metadata.pop('difficulty_requested')
    row['metadata'] = metadata
    evidence = {}
    for key,item in row['evidence'].items():
        field = 'agent_response' if item['turn_index'] == len(conv)-1 else 'customer_context'
        start = row[field].index(item['text'])
        evidence[key] = {'field':field,'start':start,'end':start+len(item['text']),'text':item['text']}
    row['evidence'] = evidence
    return {key:row[key] for key in ('id','schema_version','customer_context','agent_response','labels','metadata','evidence')}


def generate(matrix, taxonomy, config, seed):
    rng = random.Random(seed)
    plans = []
    # Partition source scenarios before splitting; each sub-intent stays in one split.
    for cat, quotas in matrix.items():
        pool = [cls for cls,n in quotas.items() for _ in range(n)]
        rng.shuffle(pool)
        for j,cls in enumerate(pool):
            sub = taxonomy[cat]['sub_intents'][j % 5]
            plans.append((cat,sub,cls))
    # Make 5-member contrast families within source scenario groups.
    by_source = {}
    for p in plans:
        by_source.setdefault((p[0],p[1]['id']),[]).append(p)
    families = []
    desired = round(len(plans)*config['contrastive_fraction']/5)
    for key, members in by_source.items():
        # Favor mixed-label five-member families, then fill remaining slots.
        members.sort(key=lambda x:CLASSES.index(x[2]))
        while len(members) >= 5 and desired:
            picked = []
            for cls in CLASSES:
                idx = next((i for i,p in enumerate(members) if p[2] == cls),None)
                if idx is not None:
                    picked.append(members.pop(idx))
            if len(picked) < 2:
                members.extend(picked)
                break
            while len(picked) < 5:
                picked.append(members.pop(0))
            families.append((True,picked)); desired -= 1
        families.extend((False,[p]) for p in members)
    # Small runs may not contain five related records per source scenario.
    # Keep their total exact and report contrastive shortfalls explicitly.
    rng.shuffle(families)
    # Assign dimensions globally with exact counts, independently of output labels.
    n = len(plans)
    def flags(fraction):
        xs = [True]*round(n*fraction) + [False]*(n-round(n*fraction))
        rng.shuffle(xs)
        return xs
    from .coverage_planner import apportion
    def dim(weights):
        counts = apportion(weights,n)
        xs = [key for key,v in counts.items() for _ in range(v)]
        rng.shuffle(xs)
        return xs
    difficulty = dim(config['difficulty'])
    lengths = dim(config['exchanges'])
    voice,asr = flags(config['voice_fraction']),flags(config['asr_fraction'])
    disclaimers = flags(config['disclaimer_fraction'])
    general_requests = flags(config.get('general_request_fraction', .3))
    # Mixed is only assigned where actual advice is present, not by label metadata alone.
    advice_total = sum(q['general_advice']+q['personal_advice'] for q in matrix.values())
    mix_flags = [True]*round(n*config['mixed_fraction']) + [False]*(advice_total-round(n*config['mixed_fraction']))
    rng.shuffle(mix_flags)
    rows = []
    seen_targets = set()
    for fi,(contrast,members) in enumerate(families):
        cat,sub,_ = members[0]
        allowed = [0,1] if cat not in ('C09','C15') else ([2,3] if cat == 'C09' else [4])
        product_id,product,fact,goal,circ = PRODUCTS[rng.choice(allowed)]
        amount_num = rng.randrange(10,950)*100
        fmt = {'product':product,'goal':goal,'circ':circ,'amount':f'${amount_num:,}','interest':f'${amount_num*.04:,.0f}'}
        agent_circ = re.sub(r'\bI\b', 'you', circ)
        agent_circ = re.sub(r'\bmy\b', 'your', agent_circ)
        agent_circ = re.sub(r'\bam\b', 'are', agent_circ)
        advice_fmt = {**fmt, 'circ':agent_circ}
        family_id = f'F{fi+1:05}'
        for mi,(_,_,cls) in enumerate(members):
            index = len(rows)
            customer = sub['customer']
            has_product_discussion = contrast or cls in ('general_advice','personal_advice')
            if has_product_discussion:
                customer += ' ' + rng.choice(PIVOTS).format(**fmt)
            if cls == 'general_advice':
                customer = f"That covers the {sub['id'].replace('_', ' ')} enquiry. What is your view of {product} as a product category?"
            if general_requests[index]:
                customer += ' ' + rng.choice(GENERAL_REQUESTS)
            if voice[index]:
                customer = rng.choice(['Hi. ', 'G’day. ', 'Sorry, one more question. ']) + customer
            if asr[index]:
                customer = 'Um, ' + customer.replace('?', '')
            conv = []
            count = 1 if lengths[index] == 'single' else rng.choice([2,3] if lengths[index] == 'two_three' else [4,5,6])
            if count == 1:
                conv.append({'role':'customer','text':customer})
            else:
                conv.extend([{'role':'customer','text':customer},{'role':'agent','text':'Thanks. Which part would you like to deal with first?'}])
                followups = [
                    ('Please keep going; I am still on the line.','I am listening.'),
                    ('I have not made a decision yet.','We can continue the discussion.'),
                    ('I am taking notes as we talk.','Take your time.'),
                    ('Could you speak a little more slowly?','Of course, I can slow down.'),
                ]
                for a,b in rng.sample(followups,count-2):
                    conv.extend([{'role':'customer','text':a},{'role':'agent','text':b}])
                last = 'Could you explain that now?'
                if has_product_discussion: last = 'What would you say about that option?'
                conv.append({'role':'customer','text':last})
            d1=d2=d3=d4=d5=False
            boundary = set()
            style='none'; mechanism='not_applicable'; mixed=False; exception=None
            recommendation=None
            if cls == 'factual_information':
                target = sub['fact'].format(**fmt)
                if sub.get('product_scope') not in ('in_scope', 'out_of_scope'):
                    raise ValueError('Explicit product scope required; unresolved scenarios must be excluded')
                d1 = sub['product_scope'] == 'in_scope'
                d5 = True
                boundary.update(['B02','B10'])
                if 'balance is' in customer: boundary.add('B05')
                if sub['id'] == 'interest_calculation': boundary.add('B06')
                if sub['id'] == 'interest_calculation':
                    conv[0]['text'] += f" The hypothetical balance for that calculation is {fmt['amount']}."
                if sub['id'] in ('savings_comparison','cover_comparison'): boundary.add('B15')
                if index % 31 == 0 and has_product_discussion:
                    target = f'As a factual explanation, {fact[0].lower()+fact[1:]} I cannot recommend which product you should choose.'
                    d1=True; boundary.add('B12')
                if cat == 'C15' and sub['id'] == 'claim_documents':
                    exception='claims_service_context_no_product_endorsement'; boundary.add('B20')
                if cat == 'C08' and sub['id'] == 'joint_savings':
                    target = 'Checking whether you fall within a savings product’s target market is a distribution check, not a finding that the account suits you.'
                    d1=True; exception='target_market_check_only'; boundary.add('B20')
                if cat == 'C06' and sub['id'] == 'service_complaint':
                    conv[0]['text'] += ' The previous caller told me to buy a managed fund. Please record that wording for my complaint, not as a recommendation.'
                    target = 'For the complaint record, you said the previous caller told you to buy a managed fund. I am recording what you reported, not endorsing that instruction.'
                    d1=True; boundary.add('B13')
            elif cls == 'general_advice':
                template = rng.choice(GENERAL)
                target = template.format(**fmt)
                d1=d2=True; style='explicit' if 'recommend' in target else 'implicit'
                boundary.update(['B02','B03','B04','B05'])
                if rng.random() < .08:
                    target = f'If the goal is {goal}, consider {product}. That is a general opinion, without an assessment of your needs.'
                    boundary.add('B17'); style='conditional'
                if rng.random() < .05:
                    target = f'My general product view is to avoid concentrating investments in a single company share. I have not assessed your situation.'
                    product_id='shares'; boundary.add('B16'); style='negative'
                recommendation=target
                mixed = mix_flags.pop()
            elif cls == 'personal_advice':
                # Labels follow an authored observable-basis attribute of the selected
                # response, never the output record's row number.
                specs = [(s, True) for s in PERSONAL] + [(s, '{amount}' in s) for s in EXPECTED]
                template, demonstrates_basis = rng.choice(specs)
                expected_only = not demonstrates_basis
                target = template.format(**advice_fmt)
                if product_id == 'insurance':
                    target = ('My recommendation for you is {product}.' if expected_only else
                              'Because {circ}, I recommend taking out {product}.').format(**advice_fmt)
                d1=d2=d4=True; d3=not expected_only
                mechanism='reasonable_expectation_only' if expected_only else 'actual_and_expected'
                style='explicit' if 'recommend' in target else 'implicit'
                boundary.update(['B03','B04','B08' if expected_only else 'B07'])
                recommendation=target
                mixed = mix_flags.pop()
            else:
                target = rng.choice(OTHER)
                if cat in ('C10','C11','C12'):
                    target = rng.choice([
                        'Which part of the credit question would you like to discuss first?',
                        'I hear the concern about repayments. What would you like to ask first?',
                        'Would you like a moment before we continue discussing this?',
                    ])
                    product_id='ordinary_credit'; boundary.update(['B01','B19'])
                elif index % 5 == 0 and has_product_discussion:
                    target = f'I am unable to give an opinion on whether {product} suits you.'
                    d1=True; boundary.add('B12')
            if mixed:
                if style == 'negative':
                    mixed = False
                else:
                    target = fact + ' ' + target
                    boundary.add('B11')
            if product_id in ('at_call_savings','term_deposit') and d1:
                boundary.add('B18')
            if count >= 4 and d2:
                boundary.add('B14')
            disclaimer_applied = disclaimers[index] and d2
            if disclaimer_applied:
                target = 'This is general information, not personal advice. ' + target
                boundary.add('B09')
            # Vary conversational delivery without changing the designed legal content.
            # Count and disclose repeated underlying bodies separately in the report.
            body = target
            combinations = [(a,b) for a in RESPONSE_OPENERS for b in RESPONSE_ENDINGS]
            rng.shuffle(combinations)
            for opening,ending in combinations:
                if opening.endswith(', '): opening=opening[:-2]+': '
                candidate = opening + body + ending
                normalized = ' '.join(candidate.casefold().split())
                if normalized not in seen_targets:
                    target = candidate
                    seen_targets.add(normalized)
                    break
            else:
                raise ValueError('Response variants exhausted; add substantive templates')
            conv.append({'role':'agent','text':target})
            evidence={'target':span(conv,len(conv)-1,target)}
            if recommendation:
                evidence['recommendation']=span(conv,len(conv)-1,recommendation)
            if d3 or (d4 and cls == 'personal_advice'):
                evidence['customer_circumstances']=span(conv,0,circ)
            labels=dict(zip(('D1','D2','D3','D4','D5','D6'),(d1,d2,d3,d4,d5,cls)))
            actual_difficulty = 'complex' if count >= 4 or exception else ('boundary' if d4 or mixed else 'straightforward')
            rows.append({'id':f'FA_{index+1:06}','schema_version':VERSION,'conversation':conv,'target_turn_index':len(conv)-1,'labels':labels,
                'coverage':{'call_category':cat,'sub_intent':sub['id'],'product_type':product_id if has_product_discussion or d2 else ('in_scope_banking' if d1 else 'service_or_credit'),'difficulty_requested':difficulty[index],'difficulty_basis':'design_target_not_independently_assessed','conversation_type':lengths[index],'recommendation_style':style,'personalisation':mechanism,'scenario_family_id':family_id,'source_template_id':cat+':'+sub['id'],'response_body':body,'response_pattern_shared_across_splits':True,'contrastive':contrast,'mixed_content':mixed,'voice_style':voice[index],'asr_imperfections':asr[index],'disclaimer':disclaimers[index],'context_dependent':cls=='personal_advice' and count>1,'boundaries':sorted(boundary),'exception_context':exception},
                'annotation':{'source':'synthetic_template','generator':GENERATOR_VERSION,'annotator':'construction-rule-v3','verifier':None,'status':'bootstrap_unverified','human_reviewed':False,'independent_teacher_verified':False,'legal_references':['Corporations Act 2001 ss763A,764A,765A','Corporations Act 2001 s766B','ASIC RG244.24–244.49'],'legal_reference_version':'AU-2026-10-17-v1','notes':'Labels follow designed template semantics, not an independent legal assessment. D3/D4 false without advice means not applicable.'},'evidence':evidence})
            meta=rows[-1]['coverage']
            meta['difficulty_requested_random']=difficulty[index]
            meta['difficulty_requested']=actual_difficulty
            meta['difficulty_basis']='Turn-count, exception and advice-content heuristic; not human assessment'
            meta['disclaimer']=disclaimer_applied
            meta['request_general_present']=general_requests[index]
            meta['contrastive_legacy_design']=meta['contrastive']
            meta['contrastive']=False
            meta['contrastive_status']='Not a controlled minimal-pair family'
            meta['context_dependent']=None
            meta['context_dependence_status']='Not validated by context ablation'
    assert not mix_flags
    return [flatten(row) for row in rows]
