"""Authored service content and credit families for the frozen v6 pilot."""
# Each service sub-intent is owned by a single split, including all its facts.
EXTRA_SERVICE_FACTS={
'investment_scam':['The fraud report can record the destination and timing of the deposit-account transfer.','A deposit-account scam report and an investment return enquiry follow different processes.'],
'romance_scam':['Keep the payment references for the deposit-account transfers when discussing the incident with the fraud team.','A fraud case reference can be used when following up the reported deposit-account transfers.'],
'bank_impersonation':['A claimed caller identity does not verify an instruction to move savings-account money.','Use a contact channel you independently know when checking an unexpected savings-transfer request.'],
'account_takeover':['The support team can review access to the affected transaction account after verification.','The timing of unfamiliar transaction-account access helps the fraud team record the incident.'],
'scam_recovery':['A scam-payment investigation update may distinguish the reported transfer from any amount recovered.','The bank can explain the next update process for the reported deposit-account scam payment without guaranteeing recovery.'],
'fee_complaint':['The deposit-account fee entry and the outcome sought can be included in the complaint record.','A deposit-account fee complaint reference identifies the complaint rather than reversing the fee by itself.'],
'service_complaint':['Your description of the transaction-account service issue can be added to the complaint record.','The bank can explain how to provide further information about the transaction-account service complaint.'],
'dispute_delay':['You can ask which stage the debit-card dispute has reached.','A debit-card dispute status request can include the date of the original dispute and its reference.'],
'hardship_complaint':['Keep the hardship application and complaint references distinct when following up the missed response.','The bank can explain how to ask for an update on the unanswered loan-hardship complaint.'],
'escalation':['The savings-account complaint record can show when escalation was requested.','You can ask which team will next contact you about the escalated savings-account complaint.'],
'job_loss':['An assistance request can explain how job loss has changed your ability to meet the existing loan payments.','The hardship team can explain how to supply information for an existing-loan assistance request.'],
'reduced_hours':['The assistance request can describe the change in work hours affecting your mortgage payments.','You can ask what updates are needed if your income changes while a mortgage-hardship request is assessed.'],
'illness':['You can tell the hardship team how illness affects your ability to make the personal-loan payment.','The bank can explain the information requested for an illness-related personal-loan assistance application.'],
'natural_disaster':['A mortgage-assistance request can identify the disaster and the payment difficulty it caused.','The hardship team can explain available ways to submit the disaster-related loan assistance request.'],
'hardship_application':['A loan-hardship application reference can help when asking for an update on that application.','You can ask the hardship team to explain what remains outstanding in a loan-assistance request.'],
}

OTHER_POOLS={
 'train':['Could you repeat the final part of your question?','Which part of the request should we clarify first?','Would you like to add anything before I respond?'],
 'validation':['What further point would you like to raise about this request?','Would it help to pause while you decide what to ask next?','Which part of your last question needs clarification?'],
 'calibration':['Is there a particular point you want me to address before we continue?','Could you restate the question you want answered next?','Are you ready to continue with that enquiry?'],
 'test':['What would you like to clarify before the next step?','Could you explain the point you want to discuss first?','Shall we pause while you gather your thoughts?'],
}

# These are separate credit-content families, not cosmetic scope adjectives.
HELDOUT_CREDIT={
 'validation':[{'id':'flexible_home_credit','context':'I am comparing home loans, can meet the repayments and want to make large extra principal repayments without a fixed-rate break charge.',
  'responses':['For that borrowing preference, I recommend comparing variable-rate home loans that permit the extra repayments you plan.',
   'I would avoid a fixed-rate home loan with a substantial break charge for the extra repayments you described.',
   'My preference for the mortgage question is a loan that permits your intended principal repayments without a break charge.']}],
 'calibration':[{'id':'equipment_term_credit','context':'Our business needs a defined amount for equipment and wants a loan repaid on a schedule, rather than an open-ended revolving debt.',
  'responses':['For the equipment borrowing you described, I would favour a term loan with a defined repayment schedule.',
   'I recommend a scheduled equipment loan rather than an indefinitely revolving credit line for that stated borrowing preference.',
   'My choice for this equipment borrowing would be a loan that amortises over an agreed term.']}],
 'test':[{'id':'overseas_card_credit','context':'I pay my credit card in full, buy from overseas shops regularly and want to avoid foreign-transaction charges.',
  'responses':['For those overseas purchases, I would favour a credit card without a foreign-transaction charge.',
   'My credit-card recommendation for the use you described is a card that does not add a foreign-transaction fee.',
   'I would avoid a credit card with a substantial foreign-transaction fee for that pattern of purchases.']}],
}

SAFE_DETAIL={
 'power_of_attorney':'The account holder is alive. I am asking about registering an attorney, not acting as executor of an estate.',
 'death_notification':'I am asking about the account holder who has died, and can provide the information requested by the estates team.',
 'executor_documents':'I am the named executor dealing with the deceased account holder estate.',
 'estate_account':'This enquiry concerns administration of a deceased account holder estate.',
 'funeral_payment':'This is a funeral invoice relating to the deceased account holder.',
 'interpreter':'I would like a Mandarin interpreter so I can understand the call.',
 'hearing_support':'Text or written information is easier for me to follow than spoken prompts.',
 'financial_abuse':'Please ask about safe contact before sending anything to a shared phone or address.',
 'trusted_person':'I want support during the call, without giving that person authority to transact.',
 'accessible_statements':'I want an accessible format for the existing deposit-account statements.',
}
SERVICE_CONTACT_DETAILS=[
 'I can use a verified app message for a follow-up.',
 'I can contact the bank using its published support number.',
 'I can visit a branch if that is needed for the request.',
 'I would prefer a written explanation through a secure channel.',
 'I can make time for a support call later this week.',
 'I can use a computer if an online request is needed.',
]
SERVICE_PREPARATION=[
 'I want to understand what information to have ready.',
 'Please explain which details are needed before I send them.',
 'I want to know how to identify this request when I follow up.',
]
