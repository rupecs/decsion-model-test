"""V11: product-bound dialogue turns and explicitly annotated speech segments.

No frame-balancing rows or artificial speaker quotations. Prefix annotations are
assigned to authored stages; future advice is never copied onto an earlier stage.
"""
from pathlib import Path
import runpy
import re
from .context_v10_content import materialize as v10_materialize, asr_text, voice_text, lower_start, arithmetic_points as old_arithmetic_points
from .context_v5_review import digest
from .streaming_15k_catalog import TOPICS


def collapse_surface_histories(points):
    """Do not count punctuation-only transcript variants as new inputs.

    Pick one history for every normalization-equivalent group, preferring the
    declared ASR surface, and apply it consistently across each trajectory.
    """
    chosen={}
    for p in points:
        ctx=p['context'];key=tuple(re.findall(r"[a-z0-9']+",ctx['text'].casefold()))
        old=chosen.get(key)
        if old is None or (ctx['asr'] and not old['asr']):chosen[key]=ctx
    for p in points:
        ctx=p['context'];key=tuple(re.findall(r"[a-z0-9']+",ctx['text'].casefold()))
        canonical=chosen[key]
        if canonical['actual']!=ctx['actual']:raise ValueError('Equivalent histories have inconsistent actuality')
        p['context']={**canonical,'id':ctx['id'],'index':ctx['index']}
    return points


def cases(root: Path):
    found={p['family']:p for p in v10_materialize(root)}
    details=runpy.run_path(str(root/'data/authored/streaming_context_v11/dialogue_details.py'))['DETAILS']
    requests=runpy.run_path(str(root/'data/authored/streaming_context_v11/customer_requests.py'))
    explanations=runpy.run_path(str(root/'data/authored/streaming_context_v11/product_explanations.py'))['EXPLANATIONS']
    replies=runpy.run_path(str(root/'data/authored/streaming_context_v11/conversational_replies.py'))
    general=runpy.run_path(str(root/'data/authored/streaming_context_v11/general_questions.py'))['GENERAL']
    choices=runpy.run_path(str(root/'data/authored/streaming_context_v11/selection_segments.py'))
    if set(details)!=set(found) or set(replies['REPLIES'])!=set(found) or set(requests['REQUESTS'])!=set(found):raise ValueError('Missing case-specific conversation details')
    for family,p in sorted(found.items()):
        c=p['case'];key=c['topic']
        spec=(choices['OVERRIDES'].get(key,choices['CHOICES'][key]) if c['variant'] else choices['CHOICES'][key])
        noun,predicate=spec.split('|')
        yield family,p,{**c,'need':requests['REQUESTS'][family],'correction':requests['CORRECTIONS'].get(key) if c['variant']==0 else None,'explanation':explanations[key][0],'general_ack':explanations[key][1],'criterion_opinion':replies['REPLIES'][family][0],'reason':replies['REPLIES'][family][1],'basis_only_proposal':family in replies['BASIS_ONLY_CASES'],'basis_in_choice':family in choices['BASIS_IN_CHOICE'],'general_dialogue':general[key],'generic_segments':choices['CHOICES'][key].split('|'),'actual_selection':noun+' '+predicate},details[family],noun,predicate


def noun_choice(c):
    return c['actual_selection']


def contexts(c,t,details):
    answer,followup,last=details
    need=c['need'] if c['need'].endswith(('.', '!', '?')) else c['need']+'.'
    question=c['question']
    explanations=re.split(r'(?<=[.!?])\s+',c['explanation'])
    first_fact=explanations[0]
    further_fact=' '.join(explanations[1:]) or c['explanation']
    # Different lengths arise from the amount of dialogue available, rather
    # than requests to output a particular class or canned acknowledgement turns.
    generic='What should I know about '+t.product+'?'
    history=[('CUSTOMER',need),('AGENT',question),('CUSTOMER',answer),('AGENT',first_fact),('CUSTOMER',followup),('AGENT',further_fact),('CUSTOMER',last)]
    pick,generic_followup,generic_last=c['general_dialogue']
    general_history=[('CUSTOMER',generic),('AGENT',question),('CUSTOMER',pick),('AGENT',first_fact),('CUSTOMER',generic_followup),('AGENT',further_fact),('CUSTOMER',c['general_ack'])]
    if c['correction']:
        initial=c['correction'] if c['correction'].endswith(('.', '!', '?')) else c['correction']+'.'
        corrected=[('CUSTOMER',initial),('AGENT',question),('CUSTOMER','Actually, '+lower_start(need)),('AGENT',first_fact),('CUSTOMER',last)]
    elif c['variant']==0:
        corrected=[('CUSTOMER',need),('AGENT',question),('CUSTOMER',answer)]
    else:
        corrected=[('CUSTOMER',need),('AGENT',noun_choice(c)),('CUSTOMER',last)]
    specs=[
      ('generic',[('CUSTOMER',generic)],False,False),
      ('single',[('CUSTOMER',need)],True,False),
      ('short',corrected,True,False),
      ('middle',history[:4]+[('CUSTOMER',last)],True,False),
      ('long',history,True,False),
      ('generic_followup',[('CUSTOMER',generic),('AGENT',c['explanation']),('CUSTOMER',c['general_ack'])],False,False),
      ('generic_middle',general_history[:3]+[('AGENT',c['explanation']),('CUSTOMER',c['general_ack'])],False,False),
      ('voice',history if int(digest(c['case_id'])[:8],16)%3==0 else general_history,bool(int(digest(c['case_id'])[:8],16)%3==0),int(digest('asr:'+c['case_id'])[:8],16)%4!=0),
    ]
    for i,(name,turns,actual,asr) in enumerate(specs):
        spoken=name in ('single','short','middle','long','voice')
        rendered=[]
        for role,text in turns:
            if asr:text=asr_text(text)
            rendered.append(role+': '+text)
        text='\n'.join(rendered)
        witness=c['need']
        if asr:witness=asr_text(witness)
        if actual:
            start=text.casefold().find(witness.casefold())
            if start<0:raise ValueError('Actual need missing from rewritten dialogue')
            witness=text[start:start+len(witness)]
        else:witness=None
        yield dict(id=name,text=text,actual=actual,need=witness,voice=spoken,asr=asr,index=i)


def materialize(root: Path):
    topics={t.key:t for t in TOPICS};points=[]
    direct=runpy.run_path(str(root/'data/authored/streaming_context_v11/direct_recommendations.py'))['DIRECT']
    for family,p,c,details,noun,predicate in cases(root):
        t=topics[c['topic']]
        for ctx in contexts(c,t,details):
            actual=ctx['actual']
            audible_noun,audible_predicate=(noun,predicate) if actual else c['generic_segments']
            choice=audible_noun+' '+audible_predicate
            selection_profile=('linked' if c['basis_in_choice'] else 'implicit') if actual else 'general'
            # These are ordinary standalone responses. No exact per-context
            # class quota is imposed; optional answers are selected by case.
            candidates=[('facts',t.fact,'fact',False),
                ('fact_conditions',t.fact+' '+t.condition,'fact',False),
                ('opinion',c['criterion_opinion'],'general',False),
                ('selection',choice,selection_profile,False),
                ('mixed_selection',t.fact+' '+choice,selection_profile,True)]
            # Criticism is tied to the authored need, not a topic-wide caution
            # about persistent debt copied into renovation/drawdown calls.
            if int(digest('mixed:'+family+ctx['id'])[:8],16)%12==0:
                candidates.append(('qualified_selection',choice+' '+t.condition,selection_profile,True))
            if actual:candidates += [('linked',choice+' '+c['reason'],'linked',False),('reason_first',c['reason']+' '+choice,'linked',False)]
            if int(digest(family)[:8],16)%4!=0:
                candidates.append(('general_fact',t.fact+' '+c['criterion_opinion'],'general',True))
            question_words=' '.join(re.findall(r"[a-z0-9']+",c['question'].casefold()))
            history_words=' '.join(re.findall(r"[a-z0-9']+",ctx['text'].casefold()))
            if question_words not in history_words:
                candidates += [('clarification',c['question'],'mention',False),
                    ('followup_fact',t.fact+' '+c['question'],'fact',False),
                    ('selection_question',choice+' '+c['question'],selection_profile,False)]
            if actual and c['basis_only_proposal']:
                candidates.append(('basis_only',c['reason']+' '+c['criterion_opinion'],'basis_only',False))
            if actual and family in direct:
                text,profile=direct[family]
                candidates.append(('direct',text,profile,False))
            for key,text,profile,mixed in candidates:
                points.append(dict(family=family,topic=t.key,context=ctx,text=text,profile=profile,
                    credit=t.credit,domain=t.domain,call=p['call'],point=ctx['id']+'.'+key,
                    mixed=mixed,disclaimer=False,case=c,boundary_adjudication=profile in ('implicit','basis_only') or (actual and key in ('opinion','general_fact'))))
            # An audible noun phrase is not yet advice. Stages 0 and 1 contain
            # facts; the endorsement appears only in stage 2. Negative advice
            # is never cut before its negation and labelled as positive advice.
            segments=[t.fact,audible_noun,choice,c['reason']]
            texts=[segments[0],segments[0]+' '+audible_noun,segments[0]+' '+choice]
            profiles=['fact','fact',selection_profile]
            if actual:texts.append(texts[-1]+' '+c['reason']);profiles.append('linked')
            for j,(text,profile) in enumerate(zip(texts,profiles,strict=True)):
                points.append(dict(family=family,topic=t.key,context=ctx,text=text,profile=profile,
                    credit=t.credit,domain=t.domain,call=p['call'],point='voice_prefix.'+str(j),
                    mixed=j>=2,disclaimer=False,case=c,boundary_adjudication=profile=='implicit',
                    prefix=dict(scenario_id='audible_stages:'+ctx['id'],checkpoint_index=j,total_checkpoints=len(texts),is_final=j==len(texts)-1),
                    partial_annotation='fact_then_unfinished_subject_then_endorsement_then_reason'))
            # Non-advice streaming controls follow the same factual lead-in.
            # Because every later segment is factual/procedural, no advice can
            # be inferred from its future continuation.
            words=t.condition.split()
            factual_texts=list(dict.fromkeys([t.fact,t.fact+' '+' '.join(words[:3]),t.fact+' '+' '.join(words[:7]),t.fact+' '+t.condition]))
            for j,text in enumerate(factual_texts):
                points.append(dict(family=family,topic=t.key,context=ctx,text=text,profile='fact',
                    credit=t.credit,domain=t.domain,call=p['call'],point='factual_prefix.'+str(j),
                    mixed=False,disclaimer=False,case=c,boundary_adjudication=False,
                    prefix=dict(scenario_id='audible_stages:explanation:'+ctx['id'],checkpoint_index=j,total_checkpoints=len(factual_texts),is_final=j==len(factual_texts)-1),
                    partial_annotation='factual_continuation_without_future_advice'))
    openings=runpy.run_path(str(root/'data/authored/streaming_context_v11/limited_scope.py'))['OPENINGS']
    for i,(family,p,c,details,noun,predicate) in enumerate(cases(root)):
        if c['variant'] or i%10:continue
        t=topics[c['topic']]
        ctx=next(x for x in contexts(c,t,details) if x['id']=='short')
        opening=openings[(i//10)%len(openings)]
        choice=noun+' '+predicate
        chunks=[opening,t.fact,c['criterion_opinion'],choice,c['reason']]
        profiles=['mention','fact','general','linked' if c['basis_in_choice'] else 'implicit','linked']
        acc=[]
        for j,(chunk,profile) in enumerate(zip(chunks,profiles,strict=True)):
            acc.append(chunk)
            points.append(dict(family=family,topic=t.key,context=ctx,text=' '.join(acc),profile=profile,
                credit=t.credit,domain=t.domain,call=p['call'],point='scope_drift.'+str(j),mixed=j>=2,
                disclaimer=True,case=c,boundary_adjudication=j in (2,3),
                prefix=dict(scenario_id='audible_stages:scope_drift',checkpoint_index=j,total_checkpoints=5,is_final=j==4),
                partial_annotation='declared_scope_to_advice_drift'))
        if (i//10)%2==0:
            withdrawal_texts=[t.fact,t.fact+' '+choice,t.fact+' '+choice+' I withdraw that recommendation; the full terms still need checking.']
            for j,text in enumerate(withdrawal_texts):
                profile='fact' if j==0 else 'linked' if c['basis_in_choice'] else 'implicit'
                points.append(dict(family=family,topic=t.key,context=ctx,text=text,profile=profile,
                    credit=t.credit,domain=t.domain,call=p['call'],point='withdrawal.'+str(j),mixed=j>0,
                    disclaimer=False,case=c,boundary_adjudication=j>0,
                    prefix=dict(scenario_id='audible_stages:withdrawal',checkpoint_index=j,total_checkpoints=3,is_final=j==2,withdrawn=j==2),
                    partial_annotation='withdrawal_does_not_erase_audible_advice'))
        # Quoted material exists in the caller turn, never invented in the reply.
        quoted_ctx=dict(id='quoted_adviser',text='CUSTOMER: An adviser wrote, "'+choice+'". Could you explain '+t.product+'?\nAGENT: '+c['question']+'\nCUSTOMER: '+c['general_dialogue'][0],
            actual=False,need=None,voice=False,asr=False,index=8)
        for j,(text,profile) in enumerate([(t.fact,'fact'),(c['criterion_opinion'],'general')]):
            points.append(dict(family=family,topic=t.key,context=quoted_ctx,text=text,profile=profile,
                credit=t.credit,domain=t.domain,call=p['call'],point='quote_control.'+str(j),mixed=False,
                disclaimer=False,case=c,boundary_adjudication=True))
    return collapse_surface_histories(points)


def services(root: Path):
    original=runpy.run_path(str(root/'data/authored/streaming_context_v10/service_cases.py'))['SERVICES']
    procedures=runpy.run_path(str(root/'data/authored/streaming_context_v11/service_procedures.py'))['PROCEDURES']
    requests=runpy.run_path(str(root/'data/authored/streaming_context_v11/service_requests.py'))['REQUESTS']
    points=[]
    if set(requests)!={s['id'] for s in original}:raise ValueError('Missing rewritten service call')
    for s in original:
        s={**s,'procedure':procedures.get(s['id'],s['procedure'])}
        for i in range(4):
            text=requests[s['id']]
            if i==1:text='Hi, '+lower_start(text)
            if i==2:text='uh '+asr_text(text)
            if i==3:text='Hello. '+text
            ctx=dict(id='service'+str(i),text='CUSTOMER: '+text,actual=False,need=None,voice=i in (1,3),asr=i==2,index=i)
            for j,(reply,profile) in enumerate([(s['fact'],'fact'),(s['procedure'],'fact'),(s['fact']+' '+s['procedure'],'fact'),
                (s['question'],'mention'),(s['alternative'],'mention'),(s['fact']+' '+s['question'],'fact')]):
                points.append(dict(family='service-'+s['id'],topic='service-'+s['id'],context=ctx,text=reply,profile=profile,
                    credit=False,domain='service',call=s['call'],point=ctx['id']+'.'+str(j),mixed=False,disclaimer=False,
                    case=dict(need='',action='',reason='Existing service request; no product selection.'),
                    boundary_adjudication=False,product_scope=s['product_scope']))
    return points


def arithmetic_points():
    starts={
      'calculation-simple_interest':'Could you work through a simple-interest example for this savings account? ',
      'calculation-fee_comparison':'Can you calculate the monthly transaction-account charges in this example? ',
      'calculation-reserved_balance':'Could you check the subtraction for this savings-account illustration? ',
    }
    for p in old_arithmetic_points():
        p={**p,'context':{**p['context'],'text':'CUSTOMER: '+starts[p['family']]+p['context']['text'].split(': ',1)[1]}}
        yield p
