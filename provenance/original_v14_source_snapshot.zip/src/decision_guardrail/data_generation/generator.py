"""V4 direct dataset generation; historical constants are compatibility-only."""
# Historical audit tools import these constants. They do not drive v4 generation.
from .legacy_generator import PRODUCTS, GENERAL, PERSONAL, EXPECTED, OTHER, PREFIXES, RESPONSE_OPENERS, RESPONSE_ENDINGS, GENERAL_REQUESTS
from .schemas import CLASSES
from .v4_generator import generate, GENERATOR_VERSION
