"""Assemble the fresh v13 full-corpus proposals from explicitly authored cases."""
from pathlib import Path
import hashlib,json,runpy
from .context_v12_authoring import labels,render,ctx_id
from .context_v5_release import merge_rows
from .context_v5_review import digest,write_json,write_rows
from .context_v6_release import VERSION
from .context_v10_content import asr_text
from .dialogue_exposure import design_fingerprint

SOURCES=('final_product_specs.py','final_product_faq.py','final_service_specs.py','final_eval_products.py','final_eval_services.py')

def assemble(root: Path):
    base=root/'data/authored/streaming_context_v13'
    loaded={name:runpy.run_path(str(base/name)) for name in SOURCES}
    generic_source=runpy.run_path(str(base/'final_generic_questions.py'));generic_questions=generic_source['QUESTIONS'];linked_questions=generic_source['LINKED_QUESTIONS'];generic_answers=generic_source['ANSWERS']
    products=loaded[SOURCES[0]]['PRODUCTS']+loaded[SOURCES[3]]['PRODUCTS']
    services=loaded[SOURCES[2]]['SERVICES']+loaded[SOURCES[4]]['SERVICES']
    faq=loaded[SOURCES[1]]['FAQ'];raw=[];designs=[];bindings={}
    revised=runpy.run_path(str(base/'final_wording.py'));wording=revised['WORDING']
    for spec in products:
        opinion,implicit,basis_only=wording[spec['key']];spec['opinion']=opinion
        if spec['key'] in revised['FACTS']:spec['fact']=revised['FACTS'][spec['key']]
        updated=[]
        for ci,case in enumerate(spec['cases']):
            c=list(case);profile=c[-1]
            if profile in ('implicit','basis_only'):
                subject,_=c[5].split('|');predicate=implicit if profile=='implicit' else basis_only
                if not predicate:raise ValueError('Missing explicit predicate revision')
                c[5]=subject+'|'+predicate
            if profile=='basis_only' and spec['key'] in revised['BASIS_SUBJECTS']:
                subject,predicate=revised['BASIS_SUBJECTS'][spec['key']];c[5]=subject+'|'+predicate
            if profile=='implicit' and spec['key'] in revised['CHOICE_SUBJECTS']:
                subject,predicate=revised['CHOICE_SUBJECTS'][spec['key']];c[5]=subject+'|'+predicate
            if (spec['key'],ci) in revised['DEFERRALS']:c[8]=revised['DEFERRALS'][(spec['key'],ci)]
            if (spec['key'],ci) in revised['REASONS']:c[6]=revised['REASONS'][(spec['key'],ci)]
            updated.append(tuple(c))
        spec['cases']=updated
    for spec in services:
        if spec['key'] in revised['SERVICE_FACTS']:spec['fact']=revised['SERVICE_FACTS'][spec['key']]
        if spec['key'] in revised['PROCEDURES']:spec['procedure']=revised['PROCEDURES'][spec['key']]
        revised_cases=[]
        for ci,case in enumerate(spec['cases']):
            c=list(case)
            if (spec['key'],ci) in revised['DEFERRALS']:c[4]=revised['DEFERRALS'][(spec['key'],ci)]
            revised_cases.append(tuple(c))
        spec['cases']=revised_cases
    def add(d,history,path,text,profile,basis,mixed=False,stage=None,scope=True):
        context,asr,paired=render(history);key=hashlib.sha256(context.encode()).hexdigest()
        if key in bindings and bindings[key]!=paired:raise ValueError('Conflicting exact Q/A binding')
        bindings[key]=paired;gold=labels(profile,d['domain']=='credit',scope);spans=[]
        if gold['D3']:
            value=asr_text(basis) if asr else basis;start=context.find(value)
            if start<0:raise ValueError('Basis missing from available history')
            spans=[dict(tag='actual_need',start=start,end=start+len(value),text=value)]
        inp=dict(customer_context=context,agent_response=text);ref=dict(scenario_id=d['design_id']+':'+ctx_id(history)+':'+path,
            checkpoint_index=stage[0] if stage else 0,total_checkpoints=stage[1] if stage else 1,
            is_final=stage[0]==stage[1]-1 if stage else True,value_added='Explicit response alternative or audible speech stage')
        raw.append(dict(id='sctxv13-'+digest(inp)[:24],schema_version=VERSION,input=inp,labels=gold,advice_present=gold['D2'],
            annotation=dict(profile=profile,status='pending_independent_annotation',independent_review=False,
                author='Codex authored proposals',rule_version='streaming-context-dialogue-v13',
                rationale='Judge only the available target in this history. D3/D4, relevance and coherence require independent adjudication.',
                visible_evidence=text,basis_relevance=None,conversation_coherence=None,
                evidence=dict(context_support_spans=spans,target_spans=[dict(start=0,end=len(text),text=text)])),
            metadata=dict(parent_topic=d['product_topic'],contrast_family=d['design_id'],design_sha256=design_fingerprint(d),
                origin='v13_fresh_design',split=d['split'],split_group=d['product_topic'],units=['v13-case:'+d['design_id']],
                source_ids=[],source_refs=[ref],scenario_product_domains=[d['domain']],call_category=d['call_category'],
                customer_situation_id='ctx-'+digest(context)[:20],customer_disclosure=bool(basis),
                customer_basis_type='actual_disclosure' if basis else 'generic_or_operational',construction_recipe='dialogue_'+str(len(history)),
                coverage_boundary=path,voice_style=True,asr_imperfections=asr,mixed_content=mixed,disclaimer=False,
                intentional_speech_act_drift=False,recommendation_withdrawn_in_target=False,recommendation_withdrawn=False,
                boundary_adjudication_required=profile in ('linked','implicit','basis_only') or not basis,
                context_kind='actual_or_operational' if basis else 'personal_choice_request' if d.get('proposed_profile')=='implicit' else 'category_question',
                lineage=[dict(source_design_id=d['design_id'],authored_case=d['design_id'],authored_point=path)])))
    def trajectory(d,history,name,texts,profiles,basis,mixed=False,scope=True):
        for i,(t,p) in enumerate(zip(texts,profiles,strict=True)):
            if i and not t.startswith(texts[i-1]):raise ValueError('Non-extending audible path')
            add(d,history,'audible_stages:'+name,t,p,basis,mixed and p not in ('fact','other'),(i,len(texts)),scope)
    for ti,p in enumerate(products):
        fs,ft=p['fact'].split('|');fact=fs+' '+ft;fq,fa=p.get('faq',faq.get(p['key'],(None,None)))
        if fq is None:raise ValueError('Missing explicit product FAQ')
        for ci,c in enumerate(p['cases']):
            goal,probe,answer,explain,closing,seg,reason,q,defer,profile=c;sub,pred=seg.split('|');choice=sub+' '+pred
            d=dict(design_id=f"v13-{p['key']}-{ci}",product_topic='v13-'+p['key'],domain=p['domain'],call_category=p['call'],
                customer_goal=goal,decision_basis=reason,split=p['split'],source_design_ids=[],proposed_profile=profile)
            designs.append(d);initial=[('CUSTOMER',goal)];short=initial+[('AGENT',probe),('CUSTOMER',answer)]
            middle=short+[('AGENT',explain),('CUSTOMER',closing)]
            long=short+[('AGENT',explain),('CUSTOMER',fq),('AGENT',fa),('CUSTOMER',closing)]
            histories=(initial,short,middle,long) if p['split']=='train' else (initial,short,long)
            basis=goal if profile in ('linked','basis_only') else ''
            generic_answer=generic_answers.get((p['key'],ci),answer)
            contexts=[(h,profile,basis) for h in histories]
            if ci==0:
                # Category-level question paired with the actual-use case.
                # No target wrappers and no extra independent design count.
                contexts.append(([('CUSTOMER',generic_questions[p['key']]),('AGENT',probe),('CUSTOMER',generic_answer)],'general',''))
            elif profile=='linked':
                contexts.append(([('CUSTOMER',linked_questions[p['key']]),('AGENT',probe),('CUSTOMER',generic_answer)],'general',''))
            for h,profile,basis in contexts:
                trajectory(d,h,'fact',[fs+' '+ft.split()[0] if ft.split()[0] in ('can','may','could') else fs,fact],['other','fact'],basis)
                add(d,h,'fact_conditions',fact+' '+p['condition'],'fact',basis)
                copula=pred.split()[0] if pred.split()[0] in ('is','would','can','should') else None
                prefix=sub+' '+('would be' if pred.startswith('would be ') else 'can be' if pred.startswith('can be ') else copula) if copula else sub
                trajectory(d,h,'direct',[prefix,choice+' '+' '.join(reason.split()[:3]),choice+' '+reason+' '+q],['other',profile,profile],basis)
                texts=[fact+' '+choice,fact+' '+choice+' '+reason,fact+' '+choice+' '+reason+' '+q];profiles=[profile]*3
                if copula:texts.insert(0,fact+' '+prefix);profiles.insert(0,'fact')
                trajectory(d,h,'mixed',texts,profiles,basis,True)
                if ti%2==0:add(d,h,'mixed_general',fact+' '+p['opinion'],'general',basis,True)
                else:add(d,h,'extended_fact',fact+' '+p['condition']+' '+q,'fact',basis)
                add(d,h,'generic_opinion',p['opinion'],'general',basis)
                trajectory(d,h,'general',[p['opinion']+' '+' '.join(q.split()[:2]),p['opinion']+' '+q],['general']*2,basis)
                add(d,h,'complete_other',defer,'other',basis)
                add(d,h,'factual_question',fact+' '+q,'fact',basis)
    for s in services:
        fs,ft=s['fact'].split('|');fact=fs+' '+ft
        for ci,c in enumerate(s['cases']):
            goal,answer,explain,closing,defer=c
            d=dict(design_id=f"v13-service-{s['key']}-{ci}",product_topic='v13-service-'+s['key'],domain='service',call_category=s['call'],
                customer_goal=goal,decision_basis=explain,split=s['split'],source_design_ids=[])
            designs.append(d);initial=[('CUSTOMER',goal)];short=initial+[('AGENT',s['probe']),('CUSTOMER',answer)]
            long=short+[('AGENT',explain),('CUSTOMER',s['follow']),('AGENT',s['follow_answer']),('CUSTOMER',closing)]
            for h in (initial,short,long):
                for name,text,profile in [('fact',fact,'fact'),('conditions',fact+' '+s['condition'],'fact'),
                    ('procedure',s['procedure'],'fact'),('condition_question',s['condition']+' '+s['question'],'fact'),
                    ('procedure_question',s['procedure']+' '+s['question'],'fact'),('clarification',s['question'],'other'),
                    ('complete_other',defer,'other'),('factual_question',fact+' '+s['question'],'fact')]:
                    add(d,h,name,text,profile,goal,scope=s['scope'])
                trajectory(d,h,'service_fact',[fs+' '+ft.split()[0] if ft.split()[0] in ('can','may','could') else fs,fact,fact+' '+s['condition']],['other','fact','fact'],goal,scope=s['scope'])
    rows,merged=merge_rows(raw)
    return rows,designs,bindings,dict(raw_records=len(raw),records=len(rows),merged=merged,designs=len(designs),
        status='unpublished_full_corpus_proposals',retained_earlier_release_records=0)

def write_pack(root: Path,output: Path):
    if output.exists():raise ValueError('Use a new authoring output')
    rows,designs,bindings,report=assemble(root);output.mkdir(parents=True)
    write_rows(output/'records.jsonl',rows);write_rows(output/'designs.jsonl',designs);write_json(output/'dialogue_bindings.json',bindings)
    write_json(output/'assembly_report.json',report);return report
