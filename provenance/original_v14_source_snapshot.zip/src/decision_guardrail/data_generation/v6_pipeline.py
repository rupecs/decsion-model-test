"""Frozen v6 pilot export with content-disjoint splits and explicit review scope."""
from collections import Counter,defaultdict
import csv
import json
from pathlib import Path
import re
import tempfile
from .schemas import ROOT,CLASSES,questions,read_yaml,validate
from .coverage_planner import plan,apportion
from .v6_generator import generate,GENERATOR_VERSION,PROFILES_PATH,HELDOUT_PROFILES_PATH,FRAMINGS,DISCLAIMERS,FOLLOWUPS,FACT_CLOSERS,SERVICE,SENSITIVE_PRODUCT_CATEGORIES
from .v4_pipeline import digest,dump,jsonl,key,split_balanced,report
from .clef_converter import convert

SELF_LABEL=r'\b(general|broad|category|untailored|not assessed|not an assessment)\b'
SENSITIVE_SUBINTENTS={'investment_scam','romance_scam','bank_impersonation','scam_recovery','account_takeover','financial_abuse','job_loss','illness',
    'natural_disaster','reduced_hours','hardship_application','hardship_complaint','death_notification','funeral_payment','arrears_notice',
    'missed_repayment','disputed_debt','collection_call'}


def precision(rows,predicate):
    c=Counter(r['labels']['D6'] for r in rows if predicate(r));n=sum(c.values())
    return {'n':n,'by_class':dict(c),'max_precision':round(max(c.values())/n,4) if n else None}


def normalize_sentence(text):
    for short,long in [('I’m','I am'),('don’t','do not'),('can’t','cannot'),('couldn’t','could not'),('I’d','I would'),('it’s','it is'),('that’s','that is'),('doesn’t','does not'),('I haven’t','I have not')]:text=text.replace(short,long)
    return ' '.join(re.findall(r"[a-z0-9']+",text.casefold()))


def response_metrics(rows):
    advice=[r for r in rows if r['labels']['D2']];personal=[r for r in rows if r['labels']['D6']=='personal_advice']
    framed=lambda r:any(r['agent_response'].startswith(f) or r['agent_response'].startswith(f.replace("I have not","I haven’t")) for f in FRAMINGS)
    mirrored=[r['id'] for r in rows if r['labels']['D6']=='general_advice' and r['metadata']['profile_disclosure_present'] and r['metadata']['general_opinion_source']!='neutral_opinions']
    interest_on_non_interest=[r['id'] for r in rows if 'simple interest at a hypothetical' in r['agent_response'] and r['metadata']['product_type'] in ('offset_deposit','foreign_currency_deposit')]
    credit_bare=[r['id'] for r in rows if any(c in r['customer_context'] for c in ('fixed-rate home loan ending','comparing personal loans','credit card balance in full')) and re.search(r'(That option|that product)',r['agent_response'])]
    return {
        'untailored_framing':precision(rows,framed),
        'self_label_terms':precision(rows,lambda r:re.search(SELF_LABEL,r['agent_response'],re.I)),
        'question_ending':precision(rows,lambda r:r['agent_response'].rstrip().endswith('?')),
        'for_you':precision(rows,lambda r:re.search(r'\bfor you\b',r['agent_response'])),
        'recommend_by_class':precision(rows,lambda r:re.search(r'\brecommend',r['agent_response'],re.I))['by_class'],
        'i_recommend_by_class':precision(rows,lambda r:re.search(r'\bI recommend\b',r['agent_response']))['by_class'],
        'ordinary_in_targets':sum(bool(re.search(r'\bordinary\b',r['agent_response'],re.I)) for r in rows),
        'general_after_profile_disclosure':sum(r['labels']['D6']=='general_advice' and r['metadata']['profile_disclosure_present'] for r in rows),
        'general_after_disclosure_mirroring_profile_opinion':len(mirrored),
        'unsupported_suitability_claims':sum('unsupported_suitability_claim' in r['metadata']['conduct_flags'] for r in rows),
        'unsupported_suitability_share_of_personal':round(sum('unsupported_suitability_claim' in r['metadata']['conduct_flags'] for r in personal)/len(personal),4),
        'interest_arithmetic_on_offset_or_currency':len(interest_on_non_interest),
        'credit_context_bare_referents':len(credit_bare),
        'advice_in_sensitive_subintents':sum(r['labels']['D2'] and r['metadata']['sub_intent'] in SENSITIVE_SUBINTENTS for r in rows),
        'advice_in_sensitive_share_of_advice':round(sum(r['labels']['D2'] and r['metadata']['sub_intent'] in SENSITIVE_SUBINTENTS for r in rows)/len(advice),4),
        'advice_by_service_only_category':sum(r['labels']['D2'] and r['metadata']['call_category'] in SERVICE for r in rows),
        'mixed_content_share_of_advice':round(sum(r['metadata']['mixed_content'] for r in advice)/len(advice),4),
        'voice_style_share':round(sum(r['metadata']['voice_style'] for r in rows)/len(rows),4),
        'asr_share':round(sum(r['metadata']['asr_imperfections'] for r in rows)/len(rows),4),
        'target_contraction_share':round(sum(r['metadata']['target_contractions'] for r in rows)/len(rows),4),
        'target_repeats_previous_agent_turn':sum(any(normalize_sentence(past) in normalize_sentence(r['agent_response']) for past in re.findall(r'(?m)^AGENT: (.+)$',r['customer_context'])) for r in rows),
        'midsentence_capital_after_intro':sum(bool(re.search(r'(For context, |I should also say that |One thing to mention: |My situation is that )(My|The|Our|Most)\b',r['customer_context'])) for r in rows),
        'legal_review_required':sum(r['metadata']['legal_review_required'] for r in rows),
    }


GATES=[('untailored framing class precision <=0.6',lambda m:m['untailored_framing']['max_precision']<=.6),
    ('self-label term class precision <=0.6',lambda m:m['self_label_terms']['max_precision']<=.6),
    ('question-ending class precision <=0.7',lambda m:m['question_ending']['max_precision']<=.7),
    ('"for you" class precision <=0.8',lambda m:m['for_you']['max_precision']<=.8),
    ('"recommend" appears in >=3 classes',lambda m:len(m['recommend_by_class'])>=3),
    ('no "ordinary" scope marker in targets',lambda m:m['ordinary_in_targets']==0),
    ('no general opinion after disclosure drawn from the mirroring set',lambda m:m['general_after_disclosure_mirroring_profile_opinion']==0),
    ('unsupported suitability <=15% of personal',lambda m:m['unsupported_suitability_share_of_personal']<=.15),
    ('no interest arithmetic on offset/currency balances',lambda m:m['interest_arithmetic_on_offset_or_currency']==0),
    ('no bare referent in two-option credit contexts',lambda m:m['credit_context_bare_referents']==0),
    ('no advice in service-only categories',lambda m:m['advice_by_service_only_category']==0),
    ('mixed content 15-20% of advice',lambda m:.15<=m['mixed_content_share_of_advice']<=.20),
    ('voice >=25% and ASR 10-15% of records',lambda m:m['voice_style_share']>=.25 and .10<=m['asr_share']<=.15),
    ('no target repeats the previous agent turn',lambda m:m['target_repeats_previous_agent_turn']==0),
    ('no mid-sentence capital after disclosure intro',lambda m:m['midsentence_capital_after_intro']==0)]



def canonical_body(text):
    for short,long in [('I’m','I am'),('don’t','do not'),('can’t','cannot'),('couldn’t','could not'),('I’d','I would'),('it’s','it is'),('that’s','that is'),('doesn’t','does not'),('I haven’t','I have not')]:text=text.replace(short,long)
    for prefix in FRAMINGS+DISCLAIMERS:
        if text.startswith(prefix):text=text[len(prefix):];break
    for suffix in FOLLOWUPS+FACT_CLOSERS:
        if text.endswith(suffix):text=text[:-len(suffix)];break
    return ' '.join(re.sub(r'\$[\d,.]+|\b\d[\d,.]*\b','<amount>',text).casefold().split())


def content_metrics(splits):
    bodies={s:{canonical_body(r['agent_response']) for r in rs} for s,rs in splits.items()}
    families=defaultdict(set)
    for s,rs in splits.items():
        for r in rs:families[r['metadata']['response_content_family_id']].add(s)
    names=list(splits)
    return {'distinct_canonical_target_bodies':len(set.union(*bodies.values())),
        'canonical_body_overlap_between_splits':{a+'__'+b:len(bodies[a]&bodies[b]) for i,a in enumerate(names) for b in names[i+1:]},
        'response_content_families':len(families),'response_content_families_shared_across_splits':sum(len(v)>1 for v in families.values()),
        'distinct_complete_targets':len({r['agent_response'] for rs in splits.values() for r in rs})}


def review_reasons(row):
    m=row['metadata'];l=row['labels'];reasons=[]
    if l['D6']=='general_advice' and m['disclosure_present']:reasons.append('general_after_disclosure_reasonable_expectations')
    if l['D4'] and not l['D3']:reasons.append('observable_D3_versus_expected_D4')
    if l['D3'] and (m['untailored_framing'] or m['disclaimer']):reasons.append('tailoring_despite_general_framing')
    if 'unsupported_suitability_claim' in m['conduct_flags']:reasons.append('unsupported_suitability')
    if m['credit_only_recommendation']:reasons.append('credit_scope_and_separate_credit_conduct')
    if m['call_category'] in {'C03','C06','C11','C12','C17','C18'}:reasons.append('sensitive_service_context_and_conduct')
    if m['sub_intent']=='power_of_attorney':reasons.append('living_principal_authority_wording')
    if l['D5'] and re.search(r'\b(recommend|should)\b',row['agent_response'],re.I):reasons.append('procedural_recommendation_convention')
    if l['D6']=='other' and l['D1']:reasons.append('product_mention_or_refusal_D1_convention')
    return reasons


def run_v6(config,distribution,output,total,seed,resume=False,dry_run=False):
    config=Path(config).resolve();distribution=Path(distribution).resolve();out=Path(output)
    if total!=2000:raise ValueError('V6 final pilot requires exactly 2000 records')
    cfg=read_yaml(config);dist=read_yaml(distribution);tax=read_yaml(ROOT/'config/dataset/call_taxonomy.yaml')
    matrix=plan(dist,tax,total,seed);sizes=apportion(dist['splits'],total)
    sources=[config,distribution,ROOT/'docs/annotation_standard_v6.md',ROOT/'docs/dataset_v6_package_readme.md',ROOT/'config/dataset/legal_sources_v6.yaml',ROOT/'config/dataset/challenge_reference_v6.yaml',ROOT/'scripts/generate_dataset_v6.py',ROOT/'scripts/validate_dataset_v6.py',ROOT/'config/dataset/call_taxonomy.yaml',PROFILES_PATH,HELDOUT_PROFILES_PATH,ROOT/'config/dataset/question_schema_v1.yaml']+[ROOT/'src/decision_guardrail/data_generation'/n for n in
        ('v6_generator.py','v6_pipeline.py','v6_content.py','v4_pipeline.py','v4_generator.py','clef_converter.py','schemas.py','coverage_planner.py','splitter.py')]
    settings={'generator':GENERATOR_VERSION,'target':total,'seed':seed,'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources}}
    if dry_run:return {'settings':settings,'external_teacher_calls':0,'api_cost_usd':0,'split_targets':sizes}
    if out.exists() and any(out.iterdir()):
        if not resume:raise ValueError('Destination must be new; no artifact is overwritten')
        manifest=out/'manifest.json'
        if not manifest.exists():raise ValueError('Incomplete output; preserve it and use a new output directory')
        saved=json.loads(manifest.read_text())
        if saved['settings']!=settings:raise ValueError('Resume settings or source differ')
        for name,sha in saved['files'].items():
            if digest(out/name)!=sha:raise ValueError(f'Resume artifact hash differs: {name}')
        return {'resumed':True,'records':saved['record_count'],'output':str(out)}
    rows=generate(matrix,tax,cfg,seed,sizes)
    dedup={};rejected=[]
    for r in rows:
        validate(r);k=key(r)
        if k in dedup:rejected.append({'id':r['id'],'duplicate_of':dedup[k]['id'],'reason':'duplicate_export_state'})
        else:dedup[k]=r
    accepted=list(dedup.values())
    if len(accepted)!=total:raise ValueError('Deduplication left a quota shortfall; no duplicate rows will be exported')
    splits={name:[r for r in accepted if r['metadata']['planned_split']==name] for name in sizes}
    if {k:len(v) for k,v in splits.items()}!=sizes:raise ValueError('Final split counts differ')
    for s,rs in splits.items():
        for r in rs:
            r['metadata']['split']=s
            r['metadata']['priority_review_reasons']=review_reasons(r)
            r['metadata']['legal_review_required']=bool(r['metadata']['priority_review_reasons'])
    metrics=report(accepted,splits)
    metrics['generator']=GENERATOR_VERSION
    metrics['response_side']=response_metrics(accepted)
    metrics['notes']=['All protected service categories are free of financial product advice, without changing category/class totals.',
        'Every product scenario pairs general and personal responses under identical preceding context; extra outcomes satisfy margins.',
        'Service response banks and product-content profiles are owned by one split. Generic linguistic frames are shared.',
        'Normalized target bodies remove known framing, closers, contractions and numeric substitutions before the overlap gate.',
        'The entire release has construction labels pending independent and qualified legal annotation; no legal signoff is implied.']
    metrics.update(content_metrics(splits))
    metrics['response_template_independent_holdout']=False
    metrics['shared_syntactic_frames']=True
    metrics['holdout_scope']='disjoint authored response-content families and exact canonical bodies; not independent human/legal annotation or proof against semantic paraphrases'
    failures=[]
    if metrics['context_ngram_violations']:failures.append('customer-context ngram cue')
    if total==2000:
        for s in ('validation','calibration','test'):
            if min(metrics['split_classes'][s].get(c,0) for c in CLASSES)<30:failures.append(f'{s} class minimum')
        if metrics['credit_only_recommendations_by_split']['train']<80:failures.append('credit coverage')
        if any(not v['within_majority_plus_10pp'] for s,v in metrics['advice_only_context_baseline'].items() if s!='train'):failures.append('advice-only context baseline')
        metrics['acceptance_gates']={name:bool(check(metrics['response_side'])) for name,check in GATES}
        failures+=[n for n,ok in metrics['acceptance_gates'].items() if not ok]
    if any(metrics['canonical_body_overlap_between_splits'].values()):failures.append('canonical target body crosses splits')
    if metrics['response_content_families_shared_across_splits']:failures.append('substantive response family crosses splits')
    if metrics['response_rules_shared_across_splits']:failures.append('authored response rule crosses splits')
    if any(r['labels']['D2'] and r['metadata']['call_category'] in SERVICE for r in accepted):failures.append('protected-call advice')
    if any(r['metadata']['sub_intent']=='power_of_attorney' and 'account holder is alive' not in r['customer_context'].casefold() for r in accepted):failures.append('authority context lacks living principal')
    if failures:raise ValueError('Acceptance gates failed: '+'; '.join(failures))
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='v6-dataset-',dir=out.parent) as temporary:
        staged=Path(temporary)/'result';staged.mkdir()
        jsonl(staged/'master_dataset.jsonl',accepted);jsonl(staged/'rejected_candidates.jsonl',rejected)
        dump(staged/'questions.json',questions());dump(staged/'quality_report.json',metrics)
        index=[];master_lines={r['id']:n for n,r in enumerate(accepted,1)}
        for s,rs in splits.items():
            jsonl(staged/'splits'/f'{s}.jsonl',rs);jsonl(staged/'clef'/f'{s}.jsonl',[convert(r) for r in rs])
            for n,r in enumerate(rs,1):index.append({'record_id':r['id'],'master_line':master_lines[r['id']],'split':s,'split_line':n,'clef_line':n,'scenario_family_id':r['metadata']['scenario_family_id']})
        with (staged/'record_index.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=['record_id','master_line','split','split_line','clef_line','scenario_family_id']);writer.writeheader();writer.writerows(index)
        review_register=[]
        for r in accepted:
            entry={'record_id':r['id'],'master_line':master_lines[r['id']],'split':r['metadata']['split'],
                'split_line':next(x['split_line'] for x in index if x['record_id']==r['id']),
                'labels':r['labels'],'review_reasons':review_reasons(r),'status':'pending_independent_qualified_review',
                'independent_label_verification':False,'human_legal_reviewed':False}
            review_register.append(entry)
        legal=[r for r in review_register if r['review_reasons']]
        jsonl(staged/'annotation_register.jsonl',review_register)
        jsonl(staged/'legal_review_queue.jsonl',legal)
        dump(staged/'review_scope.json',{'total_records':len(accepted),'annotation_register_records':len(review_register),
             'priority_queue_records':len(legal),'priority_reasons':dict(Counter(reason for r in legal for reason in r['review_reasons'])),
             'all_labels_pending_independent_review':True,'priority_queue_exhaustive_for_declared_rules':True,
             'limit':'Priority rules cover known boundaries and sensitive service contexts. They do not prove absence of other legal issues.'})
        (staged/'quality_report.md').write_text('# Final local bootstrap pilot v6\n\n2,000 records generated directly. Exact category/class and split totals are preserved. Protected calls contain service explanations and clarifications only. See quality_report.json for the measured gates and content overlap checks.\n\nAll records remain construction labels pending independent and qualified legal review. annotation_register.jsonl covers every record; legal_review_queue.jsonl is a reason-coded priority subset. The blind v4 challenge is preserved separately.\n')
        for source_name,target_name in [('docs/annotation_standard_v6.md','annotation_standard.md'),('docs/dataset_v6_package_readme.md','README.md'),('config/dataset/legal_sources_v6.yaml','legal_sources.yaml'),('config/dataset/challenge_reference_v6.yaml','challenge_reference.yaml')]:
            (staged/target_name).write_bytes((ROOT/source_name).read_bytes())
        dump(staged/'release_status.json',{'package_finalised':True,'version':GENERATOR_VERSION,'kind':'local_template_bootstrap_pilot','independent_labels_verified':False,'qualified_legal_review':False,'all_records_accounted_for':True,'challenge_modified':False})
        dump(staged/'manifest.json',{'dataset_version':GENERATOR_VERSION,'schema_version':'financial_advice_v1','record_count':len(accepted),'settings':settings,'provenance':{'generator':GENERATOR_VERSION,'annotator':'authored_response_spec','independent_verifier':None,'human_legal_reviewed':False},'generation_timestamp_policy':'omitted_to_keep_content_replays_byte_identical','files':{str(p.relative_to(staged)):digest(p) for p in sorted(staged.rglob('*')) if p.is_file() and p.name!='manifest.json'}})
        if out.exists():out.rmdir()
        staged.rename(out)
    return {'records':len(accepted),'output':str(out),'splits':sizes,'api_cost_usd':0,'annotation_status':'final_bootstrap_v6_pending_independent_and_legal_review','acceptance_gates':metrics['acceptance_gates'] if total==2000 else None}
