"""Small authored D3/D4 adjudication batch; deliberately not a full v13 release."""
from collections import Counter
import hashlib
import html
import json
from pathlib import Path
import runpy

from .context_v12_authoring import labels
from .context_v5_review import digest
from .context_v6_release import native_questions, validate_rows, normal_input
from .dialogue_exposure import design_fingerprint, exposure_hits, review_paths, sha, source_paths, read_jsonl
from .dialogue_release_audit import copy_diagnostics, repeated_agent_turns

SOURCE='data/authored/streaming_context_v13/boundary_cases.py'
POLICY='config/dataset/dialogue_exposure_policy_v13.json'
GROUPS=('D3_only','D4_only','both','neither')


def cumulative(root: Path) -> dict:
    policy=json.loads((root/POLICY).read_text());path=(root/policy['ledger']).resolve()
    if not path.is_relative_to(root.resolve()) or sha(path)!=policy['sha256']:
        raise ValueError('V13 cumulative exposure ledger/policy mismatch')
    ledger=json.loads(path.read_text())
    if set(ledger['review_files'])!={str(p.relative_to(root)) for p in review_paths(root)}:
        raise ValueError('V13 policy must account for every recorded review')
    for name,h in {**ledger['review_files'],**ledger['source_files']}.items():
        if sha(root/name)!=h:raise ValueError('Exposure source changed: '+name)
    if ledger['unresolved_review_ids']:raise ValueError('Unresolved reviewed IDs')
    return {**ledger,'ledger_sha256':sha(path)}


def assemble(root: Path) -> tuple[list, list]:
    cases=runpy.run_path(str(root/SOURCE))['CASES'];rows=[];designs=[]
    if len({c['key'] for c in cases})!=len(cases):raise ValueError('Duplicate authored design')
    calls={'credit':'C10','deposit':'C08','insurance':'C15','investment':'C09','payment':'C05','super':'C09'}
    for c in cases:
        context='\n'.join(role+': '+text for role,text in c['turns'])
        if c['turns'][0][0]!='CUSTOMER' or c['turns'][-1][0]!='CUSTOMER':raise ValueError('Role boundary')
        if any(role!=('CUSTOMER' if i%2==0 else 'AGENT') for i,(role,_) in enumerate(c['turns'])):raise ValueError('Role order')
        design=dict(design_id='v13-boundary-'+c['key'],product_topic='v13-boundary-'+c['key'].rsplit('_',1)[0],
            domain=c['domain'],call_category=calls[c['domain']],customer_goal=c['turns'][0][1],
            decision_basis=c['basis'] or 'No substantive individual financial basis disclosed; distinguish assertion from evidence.',
            split='development',source_design_ids=[],boundary_group=c['group'])
        designs.append(design)
        def add(text,profile,index,total,path):
            inp=dict(customer_context=context,agent_response=text);gold=labels(profile,c['domain']=='credit',True)
            evidence=[]
            if gold['D3']:
                if not c['basis'] or c['basis'] not in context:raise ValueError('Missing actual context basis')
                start=context.index(c['basis']);evidence=[dict(start=start,end=start+len(c['basis']),text=c['basis'])]
            rows.append(dict(id='sctxv13dev-'+digest(inp)[:24],schema_version='banking_streaming_d1_d7_v6_context_draft',input=inp,
                labels=gold,advice_present=gold['D2'],annotation=dict(status='pending_independent_annotation',
                    independent_review=False,profile=profile,rule_version='v13_boundary_proposals',
                    rationale='Proposed evidence boundary; judge context and audible target separately. No label is approved.',
                    evidence=dict(context_support_spans=evidence),basis_relevance=None,conversation_coherence=None),
                metadata=dict(contrast_family=design['design_id'],parent_topic=design['product_topic'],
                    design_sha256=design_fingerprint(design),split='development',split_group=design['product_topic'],
                    scenario_product_domains=[c['domain']],call_category=calls[c['domain']],units=['v13-boundary:'+c['key']],
                    source_design_ids=[],source_refs=[dict(scenario_id=design['design_id']+':'+path,checkpoint_index=index,
                        total_checkpoints=total,is_final=index==total-1)],boundary_group=c['group'],
                    coverage_boundary=path,boundary_adjudication_required=True,recommendation_withdrawn=False,
                    eligible_for_release=False)))
        for i,(text,profile) in enumerate(c['stages']):
            if i and not text.startswith(c['stages'][i-1][0]):raise ValueError('Non-extending authored voice path')
            add(text,profile,i,len(c['stages']),'voice')
        add(c['factual_control'],'fact',0,1,'factual_control')
        add(c['complete_other_control'],'other',0,1,'complete_other')
    if len({normal_input(x['input']) for x in rows})!=len(rows):raise ValueError('Duplicate input')
    return rows,designs


def build(root: Path, output: Path) -> dict:
    if output.exists():raise ValueError('Use a new output directory')
    if not output.resolve().is_relative_to(root.resolve()):raise ValueError('Keep artifacts inside project')
    rows,designs=assemble(root);ledger=cumulative(root)
    hits=exposure_hits(rows,ledger,designs)
    if hits:raise ValueError('Known cumulative exposure matches: '+str(hits[:3]))
    candidate_inputs={normal_input(r['input']) for r in rows};historical_files={}
    for path in source_paths(root):
        source=read_jsonl(path);mp=path.parent/'manifest.json'
        if mp.exists() and json.loads(mp.read_text()).get('generator')=='context_v13_boundary_development' and source==rows:
            continue  # Exact whole-development replay only, including proposed annotations.
        compared=0
        for old in source:
            inp=old.get('input',old)
            if 'customer_context' not in inp or 'agent_response' not in inp:continue
            compared+=1
            if normal_input(inp) in candidate_inputs:raise ValueError('Historical structured input reused')
        if compared:historical_files[str(path.relative_to(root))]=dict(sha256=sha(path),structured_rows=compared)
    schema,qs=native_questions(root);integrity,paths=validate_rows(rows,[],qs)
    copies=copy_diagnostics(rows)
    if repeated_agent_turns(rows) or copies['near_duplicate_agent_turns'] or copies['customer_turn_echoes']:
        raise ValueError('Earlier-turn copies require review: '+str(copies))
    bygroup=Counter(d['boundary_group'] for d in designs)
    report=dict(scope='development_boundary_batch_not_full_v13',records=len(rows),designs=len(designs),
        status='pending_independent_boundary_adjudication',training_ready=False,approved_training_records=0,
        full_replacement_corpus_generated=False,eligible_for_release=False,design_groups=dict(bygroup),
        domains=dict(Counter(d['domain'] for d in designs)),
        distinct_histories=len({r['input']['customer_context'] for r in rows}),
        history_turns=dict(Counter(str(len(c['turns'])) for c in runpy.run_path(str(root/SOURCE))['CASES'])),
        class_counts=dict(Counter(r['labels']['D7'] for r in rows)),
        personal_question_endings=sum(r['labels']['D7']=='personal_advice' and r['input']['agent_response'].endswith('?') for r in rows),
        complete_other_controls=sum(r['metadata']['coverage_boundary']=='complete_other' for r in rows),
        cumulative_review_logs=len(ledger['review_files']),cumulative_exposure_matches=hits,
        historical_structured_input_collisions=0,historical_source_files=historical_files,
        semantic_novelty='not_established_by_lexical_fingerprints',semantic_coherence='pending_independent_review',
        copy_diagnostics=copies,native_token_coverage='not_run',GPU_smoke='not_run',
        limitations=['This batch tests boundary interpretation; it is not representative class prevalence.',
            'No split assignment and no training or calibration exports. All rows are development material.',
            'Do not insert these reviewed examples into a future held-out set.',
            'The full replacement still needs >10000 rows, 60-70% train and per-partition category/domain checks.'])
    output.mkdir(parents=True)
    def j(name,value): (output/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
    def jl(name,values):
        with (output/name).open('w') as f:
            for v in values:f.write(json.dumps(v,ensure_ascii=False)+'\n')
    jl('records.jsonl',rows);jl('designs.jsonl',designs);j('quality_report.json',report);j('questions.json',schema);j('trajectories.json',paths)
    blind=sorted(rows,key=lambda r:digest('v13-boundary-blind:'+r['id']))
    jl('blank_annotation_packet.jsonl',[dict(record_id=r['id'],input=r['input'],
        assessed_labels={d:None for d in r['labels']},conversation_coherence=None,basis_relevance=None,
        D3_context_evidence=[],D4_target_evidence=[],reviewer=None,status='unreviewed') for r in blind])
    j('annotation_ledger.json',[])
    (output/'README.md').write_text(f'''# V13 boundary development batch\n\n{len(rows)} snapshots; {len(designs)} authored design proposals. NOT a full release. Zero training approvals.\n\nRead the inputs in blank_annotation_packet.jsonl first. Explain D3 and D4 separately; a customer asking for an individual pick supplies no financial basis by itself, but implied use of disclosed needs can count. Review coherence, product relevance and semantic similarity to older designs. Proposed labels are in records.jsonl and on the review desk.\n\nBuild from project root into a new in-project path:\n\n```sh\n.venv/bin/python scripts/build_context_v13_boundary.py --output outputs/a_new_v13_boundary_replay\n```\n\nAll rows stay development-only after exposure. This is not the >10,000-row replacement and cannot satisfy full-corpus coverage, token, annotation or GPU requirements.\n''')
    write_page(output,rows,report)
    sources=[SOURCE,POLICY,'data/reviews/dialogue_exposure_ledger_v2.json',
        'src/decision_guardrail/data_generation/context_v13_boundary.py','scripts/build_context_v13_boundary.py',
        'src/decision_guardrail/data_generation/context_v12_authoring.py',
        'src/decision_guardrail/data_generation/context_v5_review.py',
        'src/decision_guardrail/data_generation/context_v6_release.py',
        'src/decision_guardrail/data_generation/dialogue_exposure.py',
        'src/decision_guardrail/data_generation/dialogue_release_audit.py',
        'config/dataset/question_schema_streaming_v6.yaml']
    j('manifest.json',dict(generator='context_v13_boundary_development',records=len(rows),training_ready=False,
        approved_training_records=0,eligible_for_release=False,
        source_hashes={name:sha(root/name) for name in sources},
        files={str(p.relative_to(output)):sha(p) for p in sorted(output.rglob('*')) if p.is_file()}))
    return report


def write_page(output: Path, rows: list, report: dict):
    payload=json.dumps(dict(rows=rows,report=report),ensure_ascii=False).replace('<','\\u003c')
    page='''<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>V13 · boundary review</title>
<style>body{margin:0;background:#f3f6f5;color:#173038;font:17px system-ui}main{max-width:1150px;margin:40px auto;padding:0 24px}h1{font-size:38px;margin:10px 0}p{line-height:1.6}.tag{color:#087c70;font-weight:700}section{background:white;border:1px solid #d9e3e0;border-radius:16px;padding:24px;margin:18px 0}nav{display:flex;gap:12px;flex-wrap:wrap}button,select{font:inherit;padding:10px;border:1px solid #b7cbc5;border-radius:8px;background:white;color:#173038}button{cursor:pointer}pre{white-space:pre-wrap;font:inherit;line-height:1.65}#target{font-size:23px;line-height:1.5}.muted{color:#526d74}#gold{background:#e4f2ee;padding:18px;border-radius:10px}table{width:100%;border-collapse:collapse}td{padding:8px;border-bottom:1px solid #c8ded6}.steps button{margin:5px}strong{color:#087c70}</style>
<main><div class="tag">V13 · DEVELOPMENT ONLY · TRAINING BLOCKED</div><h1>Separate the evidence from the assertion.</h1><p id="summary"></p><p class="muted">This is a boundary-adjudication batch, not the full replacement corpus. No model is connected. Read the history and the available response; proposed labels stay hidden until requested.</p>
<nav><button id="prev">Previous</button><button id="next">Next</button><select id="kind" aria-label="Response type"><option value="all">All response types</option><option value="voice">Voice paths</option><option value="complete_other">Complete other controls</option><option value="factual_control">Factual controls</option></select><select id="domain" aria-label="Domain"><option value="all">All domains</option></select></nav>
<section><div class="muted" id="identifier"></div><h2>Conversation</h2><pre id="history"></pre><h2>Available response</h2><p id="target"></p><div class="steps" id="steps"></div><p id="stage" class="muted"></p></section>
<section><button id="reveal">Show proposed labels</button><div id="gold" hidden></div><p class="muted">Review D3 and D4 separately. Record the context evidence for D3 and the suitability evidence for D4. Missing or bad product reasoning is a separate quality finding.</p></section>
<section><h2>Independent review</h2><p>The blank packet contains empty decisions and no author labels or split assignments. No annotation is submitted by this page.</p><a href="blank_annotation_packet.jsonl" download>Download blank annotation packet</a> · <a href="quality_report.json">Batch scope and limits</a> · <a href="README.md">Rebuild instructions</a></section></main>
<script id="dataset" type="application/json">PAYLOAD</script><script>
const data=JSON.parse(document.querySelector('#dataset').textContent),rows=data.rows;let position=0,stage=0,groups=[];
const el=id=>document.getElementById(id);
el('summary').textContent=`${data.report.records} snapshots · ${data.report.designs} design proposals · six product domains · single-turn and multi-turn histories`;
for(const d of data.report.domains?Object.keys(data.report.domains):[]){const o=document.createElement('option');o.value=d;o.textContent=d;el('domain').append(o)}
function filter(){const paths=new Map();for(const r of rows){if(el('domain').value!=='all'&&r.metadata.scenario_product_domains[0]!==el('domain').value)continue;if(el('kind').value!=='all'&&r.metadata.coverage_boundary!==el('kind').value)continue;const s=r.metadata.source_refs[0],k=s.scenario_id;if(!paths.has(k))paths.set(k,[]);paths.get(k).push(r)}groups=[...paths.values()].map(g=>g.sort((a,b)=>a.metadata.source_refs[0].checkpoint_index-b.metadata.source_refs[0].checkpoint_index));position=0;stage=0;show()}
function show(){if(!groups.length)return;const g=groups[position],r=g[stage];el('identifier').textContent=`${r.id} · ${position+1} / ${groups.length} paths`;el('history').textContent=r.input.customer_context;el('target').textContent=r.input.agent_response;el('stage').textContent=`Stage ${stage+1} of ${g.length} · ${r.metadata.source_refs[0].is_final?'End of authored response':'Response still growing'}`;el('gold').hidden=true;el('reveal').textContent='Show proposed labels';el('gold').textContent='';const t=document.createElement('table');for(const [k,v] of Object.entries(r.labels)){const tr=document.createElement('tr'),a=document.createElement('td'),b=document.createElement('td');a.textContent=k;b.textContent=typeof v==='boolean'?(v?'Yes':'No'):v;tr.append(a,b);t.append(tr)}el('gold').append(t);el('steps').textContent='';g.forEach((_,i)=>{const b=document.createElement('button');b.textContent=String(i+1);b.setAttribute('aria-label',`Show stage ${i+1}`);b.onclick=()=>{stage=i;show()};el('steps').append(b)});el('prev').disabled=position===0;el('next').disabled=position===groups.length-1}
el('prev').onclick=()=>{position--;stage=0;show()};el('next').onclick=()=>{position++;stage=0;show()};el('kind').onchange=filter;el('domain').onchange=filter;el('reveal').onclick=()=>{el('gold').hidden=!el('gold').hidden;el('reveal').textContent=el('gold').hidden?'Show proposed labels':'Hide proposed labels'};filter();
</script>'''.replace('PAYLOAD',payload)
    (output/'review.html').write_text(page)
