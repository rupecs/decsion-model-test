"""Targeted, review-only legacy wording revision. No annotation approval."""
from copy import deepcopy
from collections import Counter
import json
from pathlib import Path
import re
import shutil
import tempfile

from .context_v8_release import read_rows, verify_files, quality, response_cues
from .context_v5_review import digest, sha, write_json, write_rows
from .context_v6_release import SPLITS
from .streaming_15k_catalog import TOPICS
from ..dataset import state_text
from ..training_readiness import annotation_fingerprint

GENERATOR = 'streaming-context-wording-v9'
SOURCE = 'data/generated/streaming_context_v8_release'
PARAPHRASES = 'data/authored/streaming_context_v9/need_paraphrases.json'
PROBES = 'data/authored/streaming_context_v9/pronoun_probe_pairs.json'
SECOND = re.compile(r'\b(?:you|your|yours|yourself|yourselves)\b', re.I)
POSITIVE = (
    'For {need}, I would choose {product}.',
    'In view of {need}, my recommendation is {product}.',
    'I would select {product}, taking account of {need}.',
    'My choice would be {product}; the stated consideration is {need}.',
    'The reason I favour {product} here is {need}.',
    'The stated consideration is {need}; I recommend {product}.',
    'I recommend {product} in light of {need}.',
    'On the basis of {need}, I would opt for {product}.',
)
NEGATIVE = (
    'For {need}, I would avoid {product}.',
    'In view of {need}, I recommend against {product}.',
    'I would rule out {product} in view of {need}.',
    'My choice would exclude {product}; the stated consideration is {need}.',
    'The reason I would reject {product} here is {need}.',
    'The stated consideration is {need}; I advise against {product}.',
    'I would not select {product} in light of {need}.',
    'On the basis of {need}, I would pass on {product}.',
)


def pronoun_audit(rows):
    result = {}
    for origin in ('all', 'retained_v4', 'v8_natural_context_design'):
        result[origin] = {}
        for label in ('factual_information', 'general_advice', 'personal_advice', 'other'):
            selected = [r for r in rows if r['labels']['D7'] == label and
                        (origin == 'all' or r['metadata']['origin'] == origin)]
            result[origin][label] = dict(records=len(selected),
                exact_you=sum(bool(re.search(r'\byou\b', r['input']['agent_response'], re.I)) for r in selected),
                any_second_person=sum(bool(SECOND.search(r['input']['agent_response'])) for r in selected))
    return result


def pronoun_probes(root):
    """Exposed development controls, excluded from all candidate partitions."""
    result=[]
    for family in json.loads((root/PROBES).read_text()):
        for pair in family['pairs']:
            label=pair['class']
            advice=label in ('general_advice','personal_advice')
            personal=label=='personal_advice'
            labels=dict(D1=True,D2=advice,D3=personal,D4=personal,
                        D5=label=='factual_information',D6=advice and family['credit'],D7=label)
            for variant in ('without','with'):
                text=pair[variant]
                if bool(SECOND.search(text)) != (variant=='with'):
                    raise ValueError('Pronoun probe does not match its declared condition')
                inp=dict(customer_context=family['context'],agent_response=text)
                result.append(dict(id='v9-probe-'+digest(inp)[:24],input=inp,labels=labels,
                    pair_id=family['family']+':'+label,variant=variant,split=None,
                    exposed_development_only=True,independent_annotation=False,
                    expected_relation='same_D1_D7_labels_under_meaning_preserving_paraphrase'))
    return result


def revise(root, source):
    """Rewrite complete initial advice+basis chunks, never strip pronouns globally.

    Only D3-positive, first-checkpoint basis recipes qualify. The same replacement
    is applied to every extension of that prefix, including merged source units.
    Unsupported suitability, negative polarity and withdrawal states are retained.
    """
    phrases = json.loads((root/PARAPHRASES).read_text())
    topics = {t.key: t for t in TOPICS}
    heads = {}
    for row in source:
        meta = row['metadata']
        if (meta['origin'] != 'retained_v4' or not meta['construction_recipe'].startswith('basis_')
                or not row['labels']['D3'] or not row['labels']['D4']
                or not any(ref['checkpoint_index'] == 0 for ref in meta['source_refs'])):
            continue
        before = row['input']['agent_response']
        quoted = re.findall(r'"([^"]+)"', before)
        if len(quoted) != 1 or quoted[0] not in phrases:
            raise ValueError('Unreviewed initial basis chunk: '+row['id'])
        need = quoted[0].replace("I'm ", 'I am ')
        if need.casefold() not in row['input']['customer_context'].casefold():
            raise ValueError('Basis is absent from the actual customer context')
        negative = meta['construction_recipe'] == 'basis_negative'
        bank = NEGATIVE if negative else POSITIVE
        variant = int(digest(dict(context=row['input']['customer_context'],head=before))[:8],16)%len(bank)
        after = bank[variant].format(need=phrases[quoted[0]], product=topics[meta['parent_topic']].product)
        key = (row['input']['customer_context'], before)
        # Distinct source starts must remain distinct without artificial ID text.
        used = {spec['after'] for (context,_),spec in heads.items() if context==key[0]}
        for _ in range(len(bank)):
            if after not in used or key in heads:
                break
            variant = (variant+1)%len(bank)
            after = bank[variant].format(need=phrases[quoted[0]], product=topics[meta['parent_topic']].product)
        else:
            raise ValueError('More independent source starts than authored paraphrases')
        if key in heads and heads[key]['after'] != after:
            raise ValueError('Conflicting prefix replacements')
        heads[key] = dict(after=after,source_head_id=row['id'],disclosed_need=need,
                          paraphrased_need=phrases[quoted[0]],negative=negative,variant=variant)
    if len(heads) != 163:
        raise ValueError('Unexpected initial-basis rewrite scope')
    rows, changes = [], []
    for original in source:
        row = deepcopy(original)
        ctx, text = row['input']['customer_context'], row['input']['agent_response']
        matches = [(head, spec) for (context,head),spec in heads.items()
                   if ctx == context and (text == head or text.startswith(head+' '))]
        if len(matches) > 1:
            raise ValueError('Ambiguous prefix rewrite')
        if matches:
            head, spec = matches[0]
            if not row['labels']['D3'] or row['labels']['D7'] != 'personal_advice':
                raise ValueError('A rewrite would alter a different decision state')
            row['input']['agent_response'] = spec['after']+text[len(head):]
            row['id'] = 'sctxv9-'+digest(row['input'])[:24]
            ann = row['annotation']
            ann.update(visible_evidence=row['input']['agent_response'],rule_version=GENERATOR,
                       rationale='Recommendation polarity and disclosed basis preserved through an authored need paraphrase; proposed labels require independent annotation.')
            ann['evidence']['target_spans'] = [dict(start=0,end=len(row['input']['agent_response']),text=row['input']['agent_response'])]
            start = ctx.casefold().index(spec['disclosed_need'].casefold())
            ann['evidence']['context_support_spans'] = [dict(tag='actual_need',start=start,
                end=start+len(spec['disclosed_need']),text=ctx[start:start+len(spec['disclosed_need'])])]
            row['metadata'].update(v8_source_id=original['id'],wording_revision=GENERATOR)
            row['metadata']['lineage'].append(dict(version=GENERATOR,source_id=original['id'],
                source_record_sha256=digest(original)))
            changes.append(dict(source_id=original['id'],candidate_id=row['id'],
                source_fingerprint=annotation_fingerprint(original),candidate_fingerprint=annotation_fingerprint(row),
                before=head,after=spec['after'],source_head_id=spec['source_head_id'],
                disclosed_need=spec['disclosed_need'],paraphrased_need=spec['paraphrased_need'],
                negative=spec['negative'],variant=spec['variant'],labels_unchanged=True,
                split=row['metadata']['split'],independent_annotation=False))
        rows.append(row)
    return rows, changes


def build(root, output):
    if output.exists():
        raise ValueError('Choose a new output path; frozen releases must be preserved')
    base = root/SOURCE
    old_manifest = verify_files(base)
    original = read_rows(base/'records.jsonl')
    rows, changes = revise(root,original)
    exposed = read_rows(base/'exposed_development/records.jsonl')
    qs = json.loads((base/'native_questions.json').read_text())
    report, trajectories = quality(rows,exposed,qs)
    probes=pronoun_probes(root)
    audit = dict(before=pronoun_audit(original),after=pronoun_audit(rows),
        measurement='Assistant response only; exact word you and all second-person pronouns.',
        interpretation='Construction diagnostics only; not measured model invariance or independent annotation.')
    report.update(generator=GENERATOR,status='pre_annotation_not_trainable',
        records_reworded=len(changes),initial_basis_chunks_reworded=len({c['source_head_id'] for c in changes}),
        labels_changed=0,records_added=0,approved_training_records=0,training_ready=False,
        development_pronoun_probe_rows=len(probes),development_pronoun_probe_pairs=len(probes)//2,
        pronoun_audit=audit,
        limitations=[
            'Targeted wording revision, not a complete natural-language rewrite of the legacy corpus.',
            'Legacy advice may be financially inappropriate; labels describe advice behavior, not correctness or approval.',
            'Unsupported suitability examples still often contain second-person language.',
            'Repeated templates, response cues and source/style correlations remain possible.',
            'All labels, including reworded rows, need independent annotation; zero approvals.',
            'No trained-model robustness result; native token coverage and exact-contract GPU smoke/reload remain pending.',
            'D3-positive/D4-negative boundary coverage remains pending adjudication.',
            'Shared-recipe held-out splits are not independent challenge validation or legal approval.'])
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='context-v9-',dir=output.parent) as temp:
        stage = Path(temp)/'release'
        shutil.copytree(base,stage)
        write_rows(stage/'records.jsonl',rows)
        write_rows(stage/'wording_changes.jsonl',changes)
        write_rows(stage/'exposed_development/pronoun_probes.jsonl',probes)
        write_json(stage/'pronoun_audit.json',audit)
        write_json(stage/'quality_report.json',report)
        write_json(stage/'trajectories.json',trajectories)
        cues = response_cues(rows)
        write_json(stage/'response_cue_audit.json',cues)
        mapping = {c['source_id']:c['candidate_id'] for c in changes}
        dispositions = read_rows(stage/'source_dispositions.jsonl')
        for item in dispositions:
            if item.get('candidate_id') in mapping:
                item['v8_candidate_id'] = item['candidate_id']
                item['candidate_id'] = mapping[item['candidate_id']]
                item['wording_revised'] = True
        write_rows(stage/'source_dispositions.jsonl',dispositions)
        boundaries = json.loads((stage/'D3_boundary_adjudication.json').read_text())
        for item in boundaries:
            item['candidate_ids'] = [mapping.get(i,i) for i in item['candidate_ids']]
        write_json(stage/'D3_boundary_adjudication.json',boundaries)
        write_rows(stage/'review_queue.jsonl',[dict(record_id=r['id'],input_labels_sha256=annotation_fingerprint(r),
            status='pending_independent_annotation') for r in rows])
        index = {r['id']:i for i,r in enumerate(rows,1)}
        write_json(stage/'line_index.json',index)
        for split in SPLITS:
            selected = [r for r in rows if r['metadata']['split']==split]
            write_rows(stage/'splits'/f'{split}.jsonl',selected)
            write_rows(stage/'construction_clef'/f'{split}.jsonl',[dict(state=state_text(**r['input']),questions=qs,gold=r['labels']) for r in selected])
            write_rows(stage/'clef_index'/f'{split}.jsonl',[dict(export_line=i,record_id=r['id'],records_jsonl_line=index[r['id']],
                recommendation_withdrawn_in_target=r['metadata']['recommendation_withdrawn_in_target']) for i,r in enumerate(selected,1)])
        # Preserve the compact context-interning UI; only replace its embedded data.
        page = (base/'review.html').read_text()
        marker = '<script id="dataset" type="application/json">'
        before, sep, tail = page.partition(marker)
        _, end, after = tail.partition('</script>')
        if not sep or not end:
            raise ValueError('Missing compact review payload boundary')
        contexts = list(dict.fromkeys(r['input']['customer_context'] for r in rows))
        context_index = {c:i for i,c in enumerate(contexts)}
        view = [dict(id=r['id'],input=dict(customer_context=context_index[r['input']['customer_context']],agent_response=r['input']['agent_response']),
            labels=r['labels'],advice_present=r['advice_present'],annotation=dict(rationale=r['annotation']['rationale']),
            metadata={k:r['metadata'][k] for k in ('contrast_family','split','recommendation_withdrawn','coverage_boundary','source_refs')}) for r in rows]
        payload = dict(rows=view,contexts=contexts,questions=json.loads((base/'questions.json').read_text()),
            report={**report,'authored_contrast_families':60,'credit_advice_rows':sum(r['labels']['D6'] for r in rows)},dataset_id=digest(rows))
        (stage/'review.html').write_text((before+marker+json.dumps(payload,ensure_ascii=False).replace('<','\\u003c')+'</script>'+after).replace('Context v8 ·','Context v9 ·'))
        (stage/'README.md').write_text('# Context v9: targeted legacy wording revision\n\n'
            '15,259 candidates; zero approved training rows. No rows added and no labels or partitions changed.\n'
            'See wording_changes.jsonl and pronoun_audit.json. The frozen v8 release is preserved.\n'
            'construction_clef/ is for CPU preparation and annotation review only. Training remains blocked.\n'
            'The inherited repaired-v7 development page is unchanged and is not a v9 wording review.\n')
        manifest = {k:v for k,v in old_manifest.items() if k not in ('files','source_hashes')}
        manifest.update(generator=GENERATOR,approved_training_records=0,source_hashes={
            SOURCE+'/manifest.json':sha(base/'manifest.json'),PARAPHRASES:sha(root/PARAPHRASES),PROBES:sha(root/PROBES),
            'src/decision_guardrail/data_generation/context_v9_release.py':sha(Path(__file__))},
            files={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file() and p.name!='manifest.json'})
        write_json(stage/'manifest.json',manifest)
        stage.rename(output)
    return report


def verify(root, output):
    manifest = verify_files(output)
    if manifest['generator'] != GENERATOR or manifest['training_ready'] is not False or manifest['approved_training_records'] != 0:
        raise ValueError('Wrong v9 construction contract')
    for path,expected in manifest['source_hashes'].items():
        if sha(root/path)!=expected:
            raise ValueError('Source hash mismatch: '+path)
    verify_files(root/SOURCE)
    source = read_rows(root/SOURCE/'records.jsonl')
    expected, changes = revise(root,source)
    rows = read_rows(output/'records.jsonl')
    if rows != expected or read_rows(output/'wording_changes.jsonl') != changes:
        raise ValueError('Wording revision differs from the declared source and author map')
    if read_rows(output/'exposed_development/pronoun_probes.jsonl')!=pronoun_probes(root):
        raise ValueError('Pronoun probes differ from the authored development controls')
    report, trajectories = quality(rows,read_rows(output/'exposed_development/records.jsonl'),
                                   json.loads((output/'native_questions.json').read_text()))
    saved = json.loads((output/'quality_report.json').read_text())
    if any(saved[k]!=v for k,v in report.items()) or json.loads((output/'trajectories.json').read_text())!=trajectories:
        raise ValueError('Quality or trajectory report mismatch')
    if json.loads((output/'pronoun_audit.json').read_text()) != dict(before=pronoun_audit(source),after=pronoun_audit(rows),
        measurement='Assistant response only; exact word you and all second-person pronouns.',
        interpretation='Construction diagnostics only; not measured model invariance or independent annotation.'):
        raise ValueError('Pronoun audit mismatch')
    if (output/'clef').exists() or json.loads((output/'annotation_ledger.json').read_text()) != []:
        raise ValueError('Unapproved training export')
    qs=json.loads((output/'native_questions.json').read_text())
    for split in SPLITS:
        selected=[r for r in rows if r['metadata']['split']==split]
        if read_rows(output/'splits'/f'{split}.jsonl')!=selected or read_rows(output/'construction_clef'/f'{split}.jsonl') != [dict(state=state_text(**r['input']),questions=qs,gold=r['labels']) for r in selected]:
            raise ValueError('Construction export mismatch')
    return saved
