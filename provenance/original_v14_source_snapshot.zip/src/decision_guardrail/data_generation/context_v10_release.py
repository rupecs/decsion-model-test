"""Full v10 reconstruction with source retirement and executable acceptance gates."""
from collections import Counter,defaultdict
from copy import deepcopy
import json
from pathlib import Path
import re
import tempfile
import yaml

from .context_v10_content import materialize,service_points,arithmetic_points
from .context_v10_audits import write_coverage_tables,low_support_cues,word_baseline
from .context_v5_release import Groups,lexical_candidates,merge_rows,trajectories_for
from .context_v5_review import digest,sha,write_json,write_rows
from .context_v6_release import VERSION,SPLITS,native_questions,normal_input,validate_rows
from .context_v8_release import read_rows,verify_files,response_cues
from .natural_context_review import duplicate_bodies,full_turn_echoes
from ..dataset import state_text
from ..training_readiness import annotation_fingerprint

GENERATOR='streaming-context-reconstruction-v10'
SOURCE='data/generated/streaming_context_v9_release'
EXPOSURE='outputs/context_v10_repair_preparation_20261023_r2/new_review_exposure.json'
ACCEPTANCE='config/dataset/acceptance_context_v10.yaml'
SECOND=re.compile(r'\b(?:you|your|yours|yourself|yourselves)\b',re.I)
PROFILES={'fact':(False,False,False,True),'general':(True,False,False,False),
          'implicit':(True,False,True,False),'linked':(True,True,True,False),
          'basis_only':(True,True,False,False),'mention':(False,False,False,False),'other':(False,False,False,False)}


def labels(profile,credit=False,scope=True):
    d2,d3,d4,d5=PROFILES[profile]
    return dict(D1=scope,D2=d2,D3=d3,D4=d4,D5=d5,D6=credit and d2,
                D7=('personal_advice' if d3 or d4 else 'general_advice') if d2 else ('factual_information' if d5 else 'other'))


def raw_rows(root):
    raw=[]
    for point in materialize(root)+service_points(root)+list(arithmetic_points()):
        ctx=point['context'];topic=point['topic'];unit='v10-case:'+point['family']
        prefix=point.get('prefix');scenario=unit+':'+(prefix.get('scenario_id','prefix') if prefix else point['point'])
        inp=dict(customer_context=ctx['text'],agent_response=point['text'])
        gold=labels(point['profile'],point['credit'],point.get('product_scope',True))
        witness=[]
        if gold['D3']:
            if not ctx['actual'] or not ctx['need']:raise ValueError('Advice has no actual context basis')
            start=ctx['text'].find(ctx['need'])
            if start<0:raise ValueError('Actual-need span missing')
            witness=[dict(tag='actual_need',start=start,end=start+len(ctx['need']),text=ctx['need'])]
        boundaries={'B02'}
        key=point['point'].split('.')[-1]
        if not gold['D1']:boundaries.add('B01')
        if key in ('selection','selection_question','mixed_selection','qualified_selection','quote_selection','own_quoted_choice'):boundaries.update(('B03','B04','B08'))
        if key=='fit':boundaries.add('B04')
        if ctx['actual'] and not gold['D2']:boundaries.add('B05')
        if key=='basis_fact':boundaries.add('B06')
        if point.get('personalized_fact'):boundaries.add('B06')
        if gold['D3']:boundaries.add('B07')
        if point['disclaimer']:boundaries.add('B09')
        if point['domain']=='service':boundaries.add('B10')
        if point['mixed']:boundaries.add('B11')
        if key=='refusal':boundaries.add('B12')
        if key.startswith('quote') or key.startswith('own_quoted'):boundaries.add('B13')
        if len(ctx['text'].splitlines())>=3:boundaries.add('B14')
        if key in ('opinion','mixed_opinion','criticism'):boundaries.add('B15')
        if key=='criticism' or (gold['D2'] and re.search(r'\b(avoid|not choose|not add|not rely)\b',point['text'],re.I)):boundaries.add('B16')
        if key=='conditional':boundaries.add('B17')
        if point['domain']=='deposit':boundaries.add('B18')
        if point['credit']:boundaries.add('B19')
        if point['family']=='service-target_document':boundaries.add('B20')
        raw.append(dict(id='sctxv10-'+digest(inp)[:24],schema_version=VERSION,input=inp,labels=gold,advice_present=gold['D2'],
            annotation=dict(profile=point['profile'],rationale=('Authored narrow criterion opinion using an actual need, without an individual suitability selection; D3/D4 boundary requires independent adjudication.' if point['profile']=='basis_only' else 'Explicit speech-act cell bound to this product case and this exact conversation.'),
                rule_version=GENERATOR,status='pending_independent_annotation',independent_review=False,
                author='Codex construction',visible_evidence=point['text'],
                basis_relevance=None,conversation_coherence=None,
                author_quality_proposal=dict(basis_relevance='supported' if gold['D3'] else 'not_applicable',
                    conversation_coherence='pass',basis=point['case']['reason'],independent=False),
                evidence=dict(context_support_spans=witness,target_spans=[dict(start=0,end=len(point['text']),text=point['text'])])),
            metadata=dict(parent_topic=topic,origin='v10_explicit_case',units=[unit],source_ids=[],
                source_refs=[dict(scenario_id=scenario,checkpoint_index=prefix['checkpoint_index'] if prefix else 0,
                    total_checkpoints=prefix['total_checkpoints'] if prefix else 1,is_final=prefix['is_final'] if prefix else True,
                    value_added='Explicit context/speech-act contrast and case-specific rationale')],
                split=topic,original_split=None,split_group=topic,contrast_family=point['family'],
                customer_situation_id='ctx-'+digest(ctx['text'])[:20],scenario_product_domains=[point['domain']],
                customer_basis_type='authored_actual_need' if ctx['actual'] else 'not_actual_disclosure',customer_disclosure=ctx['actual'],
                construction_recipe=ctx['id'],coverage_boundary=key,boundaries=sorted(boundaries),
                call_category=point['call'],sub_intent=point['family'],voice_style=ctx['voice'],asr_imperfections=ctx['asr'],
                mixed_content=point['mixed'],disclaimer=point['disclaimer'],context_support_required=gold['D3'],
                boundary_adjudication_required=point['boundary_adjudication'],
                difficulty='complex' if ctx['id'] in ('correction','reference') else 'boundary' if key.startswith('quote') or gold['D3']!=gold['D4'] else 'straightforward',
                recommendation_style='conditional' if key=='conditional' else 'implicit' if key=='own_quoted_choice' else 'negative' if key=='criticism' else 'explicit' if gold['D2'] else 'none',
                personalized_numeric_fact=bool(point.get('personalized_fact')),
                intentional_speech_act_drift=bool(prefix and prefix.get('scenario_id')=='drift'),
                recommendation_withdrawn_in_target=bool(prefix and prefix['is_final']),recommendation_withdrawn=bool(prefix and prefix['is_final']),
                native_export_eligible=True,synthetic=True,independent_annotation=False,
                lineage=[dict(version=GENERATOR,authored_case=point['family'],authored_point=point['point'])])))
    rows,merged=merge_rows(raw)
    return rows,merged


def assign(rows):
    groups=Groups();exact={};contexts={}
    for r in rows:
        parent=r['metadata']['parent_topic'];groups.find(parent)
        for key,owners in ((r['input']['agent_response'],exact),(r['input']['customer_context'],contexts)):
            if key in owners:groups.union(parent,owners[key])
            else:owners[key]=parent
    # One representative per parent/target avoids multiplying identical
    # counterfactual comparisons while closing every lexical neighbour.
    unique={}
    for r in rows:unique.setdefault((r['metadata']['parent_topic'],r['input']['agent_response']),r)
    neighbours=lexical_candidates(list(unique.values()))
    for a,b,_ in neighbours:groups.union(a['metadata']['parent_topic'],b['metadata']['parent_topic'])
    components=defaultdict(list)
    for r in rows:components[groups.find(r['metadata']['parent_topic'])].append(r)
    product=[(k,v) for k,v in components.items() if any(r['metadata']['scenario_product_domains']!=['service'] for r in v)]
    if len(product)<4:raise ValueError('Common wording has collapsed the product families into fewer than four split components')
    counts=Counter();ownership={};targets=dict(zip(SPLITS,(.7,.1,.1,.1)))
    # Seed each split with a product component so D3 and credit are audited later.
    seeds=sorted(product,key=lambda item:(-len(item[1]),item[0]))[:4]
    for split,(key,component) in zip(SPLITS,seeds,strict=True):ownership[key]=split;counts[split]+=len(component)
    for key,component in sorted(components.items(),key=lambda item:(-len(item[1]),item[0])):
        if key in ownership:continue
        split=min(SPLITS,key=lambda s:(counts[s]/targets[s],SPLITS.index(s)))
        ownership[key]=split;counts[split]+=len(component)
    for r in rows:
        group=groups.find(r['metadata']['parent_topic'])
        r['metadata'].update(split=ownership[group],split_group=group)
    return dict(components=len(components),lexical_family_links=len(neighbours),split_counts=dict(counts))


def historical_paths(root):
    return [root/SOURCE/'records.jsonl',root/SOURCE/'quarantine.jsonl',
           root/SOURCE/'exposed_development/records.jsonl',root/SOURCE/'exposed_development/pronoun_probes.jsonl',
           root/'data/generated/streaming_15000_v4/records.jsonl',
           root/'data/generated/streaming_context_v5_release/records.jsonl',
           root/'data/generated/streaming_context_v6_release_r3/records.jsonl',
           root/'data/generated/streaming_context_v7_development/records.jsonl',
           root/'data/generated/streaming_context_v7_coherent_development/records.jsonl',
           root/'data/generated/streaming_context_v8_release/records.jsonl']


def historical_inputs(root):
    found={}
    for path in historical_paths(root):
        for r in read_rows(path):found[normal_input(r['input'])]=r
    return list(found.values())


def acceptance(rows,cfg,base_report):
    n=len(rows);failures=[];counts=Counter(r['labels']['D7'] for r in rows)
    bytarget=defaultdict(set)
    for r in rows:bytarget[r['input']['agent_response']].add(r['labels']['D7'])
    observed={text for text,classes in bytarget.items() if len(classes)>1}
    def fraction(test):return sum(test(r) for r in rows)/n
    personal=[r for r in rows if r['labels']['D7']=='personal_advice']
    fractions=dict(mixed_content=fraction(lambda r:r['metadata']['mixed_content']),
        voice_style=fraction(lambda r:r['metadata']['voice_style']),
        controlled_asr=fraction(lambda r:r['metadata']['asr_imperfections']),
        disclaimer=fraction(lambda r:r['metadata']['disclaimer']),
        context_dependent=fraction(lambda r:r['input']['agent_response'] in observed),
        single_exchange=fraction(lambda r:len(r['input']['customer_context'].splitlines())==1),
        two_three_exchanges=fraction(lambda r:2<=len(r['input']['customer_context'].splitlines())<=5),
        four_plus_exchanges=fraction(lambda r:len(r['input']['customer_context'].splitlines())>=7),
        personal_with_second_person=sum(bool(SECOND.search(r['input']['agent_response'])) for r in personal)/len(personal))
    for key,(lo,hi) in cfg['fractions'].items():
        if not lo<=fractions[key]<=hi:failures.append(dict(check=key,actual=fractions[key],required=[lo,hi]))
    calls=Counter(r['metadata']['call_category'] for r in rows)
    joint=Counter(f"{int(r['labels']['D2'])}{int(r['labels']['D3'])}{int(r['labels']['D4'])}" for r in rows)
    def require(ok,name,actual=None):
        if not ok:failures.append(dict(check=name,actual=actual))
    require(n>cfg['minimum_records_exclusive'],'minimum_records',n)
    cases=defaultdict(set)
    for r in rows:
        if r['metadata']['scenario_product_domains']!=['service'] and not r['metadata']['personalized_numeric_fact']:
            cases[r['metadata']['parent_topic']].add(r['metadata']['contrast_family'])
    require(len(cases)==cfg['required_product_topics'] and min(map(len,cases.values()))>=cfg['minimum_authored_needs_per_product'],'authored_need_diversity',{k:len(v) for k,v in sorted(cases.items())})
    require(all(r['metadata']['origin']=='v10_explicit_case' for r in rows),'fresh_authored_origin')
    require(base_report['response_cues_support100_precision95']<=cfg['maximum_response_cues_support100_precision95'],
            'all_response_ngrams_support100_precision95',base_report['response_cues_support100_precision95'])
    require(len({r['metadata']['parent_topic'] for r in rows if r['metadata']['scenario_product_domains']!=['service']})==cfg['required_product_topics'],'product_topics')
    require(set(calls)=={f'C{i:02}' for i in range(1,21)} and min(calls.values())>=cfg['minimum_rows_per_call_category'],'call_coverage',dict(calls))
    require(all(counts[c]>=cfg['minimum_each_final_class'] for c in ('factual_information','general_advice','personal_advice','other')),'class_coverage',dict(counts))
    for key,target in [('110','minimum_proposed_D3_only'),('101','minimum_proposed_D4_only'),('111','minimum_proposed_D3_D4')]:
        require(joint[key]>=cfg[target],target,joint[key])
    hard=sum(not r['labels']['D2'] and bool(re.search(r'\b(?:recommend|should|best)\b',r['input']['agent_response'],re.I)) for r in rows)
    require(hard>=cfg['minimum_hard_negatives'],'hard_negatives',hard)
    markers={}
    for marker in cfg['known_markers']:
        c=Counter(r['labels']['D7'] for r in rows if marker in r['input']['agent_response'].casefold())
        support=sum(c.values());precision=max(c.values(),default=0)/max(1,support)
        markers[marker]=dict(counts=dict(c),support=support,max_class_precision=precision)
        require(len(c)>=cfg['minimum_known_marker_classes'] and precision<=cfg['maximum_known_marker_class_precision'],'marker:'+marker,markers[marker])
    for marker in cfg['forbidden_scaffolds']:
        require(not any(marker in r['input']['agent_response'].casefold() for r in rows),'forbidden:'+marker)
    complete=Counter(r['input']['agent_response'] for r in rows if any(ref['is_final'] for ref in r['metadata']['source_refs']))
    require(max(complete.values())<=cfg['maximum_identical_completed_target_uses'],'completed_target_reuse',complete.most_common(3))
    openings={}
    for label,total in counts.items():
        c=Counter(' '.join(re.findall(r"[a-z0-9']+",r['input']['agent_response'].casefold())[:4]) for r in rows if r['labels']['D7']==label)
        top=c.most_common(1)[0];openings[label]=dict(opening=top[0],count=top[1],fraction=top[1]/total)
        require(top[1]/total<=cfg['maximum_four_word_opening_class_fraction'],'opening:'+label,openings[label])
    bounds=Counter(b for r in rows for b in r['metadata']['boundaries'])
    require(set(bounds)=={f'B{i:02}' for i in range(1,21)},'boundary_presence',dict(bounds))
    report=dict(fractions=fractions,call_counts=dict(calls),joint_D2_D3_D4=dict(joint),hard_negative_rows=hard,
        marker_audit=markers,opening_audit=openings,boundary_counts=dict(bounds),
        observed_D7_context_swap_rows=sum(r['input']['agent_response'] in observed for r in rows),
        grounded_D3_context_rows=sum(r['labels']['D3'] for r in rows),
        context_dependence_method='Observed identical-target D7 label changes across coherent generic/fictional/actual contexts. D3 actual-need grounding is reported separately.',
        completed_target_max_uses=max(complete.values()),distinct_target_texts=len(complete),
        acceptance_failures=failures,all_cpu_acceptance_gates_passed=not failures)
    return report


def inspect(rows,forbidden,qs,cfg):
    report,trajectories=validate_rows(rows,forbidden,qs)
    if duplicate_bodies(rows):raise ValueError('Same-context duplicate bodies')
    if full_turn_echoes(rows):raise ValueError('Copied full customer turns')
    if lexical_candidates(rows):raise ValueError('Cross-split lexical relatives remain')
    for r in rows:
        for span in r['annotation']['evidence']['context_support_spans']:
            if r['input']['customer_context'][span['start']:span['end']]!=span['text']:raise ValueError('Invalid context span')
    for split in SPLITS:
        rs=[r for r in rows if r['metadata']['split']==split]
        if len({r['labels']['D7'] for r in rs})!=4 or not any(r['labels']['D3'] for r in rs) or not any(r['labels']['D6'] for r in rs):
            raise ValueError('A split is missing a class, actual-basis case or credit advice')
    cues=response_cues(rows)
    report['response_cues_support100_precision95']=len(cues)
    report['response_cues_1to3gram_support100_precision95']=sum(len(c['phrase'].split())<=3 for c in cues)
    report.update(acceptance(rows,cfg,report))
    report.update(generator=GENERATOR,legacy_rows_retained=0,all_rows_fresh_authored_cases=True,
        class_counts_by_split={s:dict(Counter(r['labels']['D7'] for r in rows if r['metadata']['split']==s)) for s in SPLITS},
        binary_counts={d:dict(Counter(str(r['labels'][d]).lower() for r in rows)) for d in ('D1','D2','D3','D4','D5','D6')},
        limitations=['All labels and author quality proposals require independent annotation; zero approved training rows.',
            'D3-only narrow criterion opinions are proposed boundary cases requiring adjudication, not validated suitability determinations.',
            'B19 maps to current credit-advice scope; B20 covers document/exclusion questions operationally, not statutory validation.',
            'Historic pilot call weights are a reference rather than full-corpus class/call quotas.',
            'Within-family repeated targets include intentional counterfactual context swaps; word-level signatures are diagnostic, not proof of semantic robustness.',
            'No embedding screening, native tokenizer coverage, model evaluation or GPU smoke/reload has been performed.'])
    return report,trajectories


def build(root,output,allow_failed=False):
    if output.exists():raise ValueError('Use a new output path; preserve frozen releases')
    verify_files(root/SOURCE)
    cfg=yaml.safe_load((root/ACCEPTANCE).read_text());rows,merged=raw_rows(root);splits=assign(rows)
    schema,qs=native_questions(root);forbidden=historical_inputs(root)
    report,trajectories=inspect(rows,forbidden,qs,cfg)
    report.update(shared_prefix_inputs_merged=merged,split_assignment=splits)
    if report['acceptance_failures'] and not allow_failed:raise ValueError('Acceptance gates failed: '+json.dumps(report['acceptance_failures']))
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='context-v10-',dir=output.parent) as temp:
        stage=Path(temp)/'release';stage.mkdir()
        for folder in ('splits','construction_clef','clef_index','exposed_development'):(stage/folder).mkdir()
        write_rows(stage/'records.jsonl',rows);write_json(stage/'quality_report.json',report)
        write_json(stage/'trajectories.json',trajectories);write_json(stage/'questions.json',schema);write_json(stage/'native_questions.json',qs)
        write_json(stage/'annotation_ledger.json',[])
        write_rows(stage/'review_queue.jsonl',[dict(record_id=r['id'],input_labels_sha256=annotation_fingerprint(r),
            status='pending_independent_annotation',basis_relevance=None,conversation_coherence=None,
            adjudication_required=r['metadata']['boundary_adjudication_required']) for r in rows])
        write_json(stage/'response_cue_audit.json',response_cues(rows))
        write_json(stage/'response_cues_low_support_diagnostic.json',low_support_cues(rows))
        write_json(stage/'word_baselines.json',{field:word_baseline(rows,field) for field in ('customer_context','agent_response')})
        diversity=write_coverage_tables(rows,stage/'coverage',yaml.safe_load((root/'config/dataset/distribution_pilot.yaml').read_text()),cfg['minimum_rows_per_call_category'])
        write_json(stage/'diversity_report.json',diversity)
        case_points={p['family']:p for p in materialize(root)}
        write_rows(stage/'author_case_quality_proposals.jsonl',[dict(case_id=key,product_topic=p['topic'],
            actual_need=p['case']['need'],reason=p['case']['reason'],criterion=p['case']['criterion'],
            criterion_opinion=p['case']['criterion_opinion'],independent_approval=False)
            for key,p in sorted(case_points.items())])
        source=read_rows(root/SOURCE/'records.jsonl');exposure=json.loads((root/EXPOSURE).read_text());exposed_ids=set(exposure['excluded_record_ids'])
        write_rows(stage/'source_dispositions.jsonl',[dict(source_id=r['id'],source_sha256=digest(r),
            disposition='review_exposure_retired' if r['id'] in exposed_ids else 'retired_recipe_full_reconstruction',
            candidate_id=None,reason='Full reconstruction rather than automatic semantic relabelling or connective substitution.') for r in source])
        write_json(stage/'exposure_ledger.json',dict(prior_forbidden_inputs=len(forbidden),new_review_exposure=exposure,
            historical_sources_retained_in_candidates=0))
        write_rows(stage/'quarantine.jsonl',[dict(**{k:v for k,v in r.items() if k!='metadata'},metadata={**r['metadata'],'split':None,'native_export_eligible':False,
            'retirement_reason':'Superseded construction recipe; not a finding that every row is wrong.'}) for r in source])
        write_rows(stage/'exposed_development/records.jsonl',[dict(**{k:v for k,v in r.items() if k!='metadata'},
            metadata={**r['metadata'],'source_split':r['metadata']['split'],'split':None,
                      'native_export_eligible':False,'exposed_development_only':True}) for r in source if r['id'] in exposed_ids])
        index={r['id']:i for i,r in enumerate(rows,1)};write_json(stage/'line_index.json',index)
        for split in SPLITS:
            selected=[r for r in rows if r['metadata']['split']==split]
            write_rows(stage/'splits'/f'{split}.jsonl',selected)
            write_rows(stage/'construction_clef'/f'{split}.jsonl',[dict(state=state_text(**r['input']),questions=qs,gold=r['labels']) for r in selected])
            write_rows(stage/'clef_index'/f'{split}.jsonl',[dict(export_line=i,record_id=r['id'],records_jsonl_line=index[r['id']],recommendation_withdrawn_in_target=r['metadata']['recommendation_withdrawn_in_target']) for i,r in enumerate(selected,1)])
        (stage/'annotation_standard.md').write_text((root/'docs/annotation_standard_streaming_v6.md').read_text()+'\n\n'+(root/'docs/annotation_standard_streaming_v10.md').read_text())
        (stage/'acceptance.yaml').write_bytes((root/ACCEPTANCE).read_bytes())
        (stage/'README.md').write_text('# V10 reconstruction candidates\n\n'+str(len(rows))+' fresh snapshots; zero approved training rows. No v9 records retained.\n'
            'Read quality_report.json for measured acceptance and limitations. Construction exports are CPU/review data, not approved training data.\n')
        contexts=list(dict.fromkeys(r['input']['customer_context'] for r in rows));lookup={c:i for i,c in enumerate(contexts)}
        view=[dict(id=r['id'],input=dict(customer_context=lookup[r['input']['customer_context']],agent_response=r['input']['agent_response']),labels=r['labels'],advice_present=r['advice_present'],
            annotation=dict(rationale=r['annotation']['rationale']),metadata={k:r['metadata'][k] for k in ('contrast_family','split','recommendation_withdrawn','coverage_boundary','source_refs')}) for r in rows]
        payload=dict(rows=view,contexts=contexts,questions=schema,report={**report,'authored_contrast_families':len({r['metadata']['contrast_family'] for r in rows}),'credit_advice_rows':sum(r['labels']['D6'] for r in rows)},dataset_id=digest(rows))
        page=(root/'data/generated/streaming_context_v9_release/review.html').read_text();marker='<script id="dataset" type="application/json">'
        before,sep,tail=page.partition(marker);_,end,after=tail.partition('</script>')
        if not sep or not end:raise ValueError('Missing compact review template boundary')
        (stage/'review.html').write_text((before+marker+json.dumps(payload,ensure_ascii=False).replace('<','\\u003c')+'</script>'+after).replace('Context v9 ·','Context v10 ·'))
        sources=[SOURCE+'/manifest.json',EXPOSURE,ACCEPTANCE,'src/decision_guardrail/data_generation/context_v10_content.py',
            'src/decision_guardrail/data_generation/context_v10_release.py',
            'src/decision_guardrail/data_generation/context_v10_audits.py',
            'config/dataset/distribution_pilot.yaml',
            'config/dataset/question_schema_streaming_v6.yaml','config/dataset/question_schema_runtime_v6.yaml',
            'src/decision_guardrail/data_generation/streaming_15k_catalog.py',
            'src/decision_guardrail/data_generation/context_v5_release.py',
            'src/decision_guardrail/data_generation/context_v5_review.py',
            'src/decision_guardrail/data_generation/context_v6_release.py',
            'src/decision_guardrail/data_generation/context_v8_release.py',
            'src/decision_guardrail/data_generation/natural_context_review.py',
            'src/decision_guardrail/dataset.py','src/decision_guardrail/schema.py',
            'src/decision_guardrail/training_readiness.py','scripts/build_context_v10_release.py',
            'docs/annotation_standard_streaming_v6.md','docs/annotation_standard_streaming_v10.md']
        sources += [str(p.relative_to(root)) for p in sorted((root/'data/authored/streaming_context_v10').glob('*.py'))]
        sources += [str(p.relative_to(root)) for p in historical_paths(root)]
        write_json(stage/'manifest.json',dict(schema_version=VERSION,generator=GENERATOR,records=len(rows),scenarios=len(trajectories),
            status='pre_annotation_not_trainable',training_ready=False,approved_training_records=0,
            construction_acceptance_passed=not report['acceptance_failures'],native_export_directory='construction_clef',annotation_ledger_path='annotation_ledger.json',
            source_hashes={s:sha(root/s) for s in sources},files={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file()}))
        stage.rename(output)
    return report


def verify(root,output):
    m=verify_files(output)
    if m['generator']!=GENERATOR or m['training_ready'] is not False or m['approved_training_records']!=0:raise ValueError('Wrong v10 construction manifest')
    for path,h in m['source_hashes'].items():
        if sha(root/path)!=h:raise ValueError('Source hash mismatch: '+path)
    rows,merged=raw_rows(root);splits=assign(rows)
    if read_rows(output/'records.jsonl')!=rows:raise ValueError('Reconstruction differs from authored cases')
    cfg=yaml.safe_load((root/ACCEPTANCE).read_text());_,qs=native_questions(root)
    report,trajectories=inspect(rows,historical_inputs(root),qs,cfg);report.update(shared_prefix_inputs_merged=merged,split_assignment=splits)
    if report!=json.loads((output/'quality_report.json').read_text()) or report['acceptance_failures']:raise ValueError('Acceptance report failed or differs')
    if trajectories!=json.loads((output/'trajectories.json').read_text()):raise ValueError('Trajectory export differs')
    if (output/'clef').exists() or json.loads((output/'annotation_ledger.json').read_text())!=[]:raise ValueError('Unapproved native training data')
    for split in SPLITS:
        selected=[r for r in rows if r['metadata']['split']==split]
        if read_rows(output/'splits'/f'{split}.jsonl')!=selected or read_rows(output/'construction_clef'/f'{split}.jsonl')!=[dict(state=state_text(**r['input']),questions=qs,gold=r['labels']) for r in selected]:raise ValueError('Split export differs')
    return report
