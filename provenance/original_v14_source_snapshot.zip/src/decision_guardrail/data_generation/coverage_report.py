"""Transparent structural, coverage and template-repetition measurements."""
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import re
from .schemas import CLASSES, validate


def normalize(text):
    return ' '.join(re.findall(r"[\w']+", text.casefold()))


def input_key(row):
    return normalize(row['customer_context'] + '\n' + row['agent_response'])


def body_key(row):
    return re.sub(r'\d[\d,.]*', '<number>', normalize(row['metadata']['response_body']))


def csv_write(path, fields, rows):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        writer = csv.DictWriter(f,fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)


def near_duplicates(rows, threshold):
    """Lexical candidate screen, NOT embedding/semantic verification.

    Screen within category using 4-gram Jaccard on input after number masking.
    Cross-category shared bodies are counted separately. Never delete contrasts.
    """
    buckets=defaultdict(list); findings=[]; checks=0
    for r in rows:
        text=re.sub(r'\d[\d,.]*','NUMBER',input_key(r))
        words=text.split(); grams={tuple(words[i:i+4]) for i in range(max(1,len(words)-3))}
        for other,og in buckets[r['metadata']['call_category']]:
            checks+=1
            if min(len(grams),len(og))/max(len(grams),len(og),1) < threshold:
                continue
            overlap=len(grams & og)/max(len(grams | og),1)
            if overlap >= threshold:
                findings.append({'id1':other['id'],'id2':r['id'],'similarity':round(overlap,4),
                    'same_contrast_family':r['metadata']['contrastive'] and r['metadata']['scenario_family_id']==other['metadata']['scenario_family_id'],
                    'cross_split':r['metadata'].get('split') != other['metadata'].get('split')})
        buckets[r['metadata']['call_category']].append((r,grams))
    return findings,checks


def report(rows, directory, distribution, config, split_counts):
    out=Path(directory); out.mkdir(parents=True,exist_ok=True)
    validity=[]
    for row in rows:
        try: validate(row);validity.append(True)
        except ValueError:validity.append(False)
    if not all(validity):raise ValueError('Report input contains invalid or contradictory records')
    classes=Counter(r['labels']['D6'] for r in rows)
    categories=Counter(r['metadata']['call_category'] for r in rows)
    body_counts=Counter(body_key(r) for r in rows)
    bodies_to_splits=defaultdict(set)
    for r in rows: bodies_to_splits[body_key(r)].add(r['metadata'].get('split'))
    identifier_splits=defaultdict(set)
    for r in rows:
        for field in ('source_template_id','scenario_family_id'):
            identifier_splits[(field,r['metadata'][field])].add(r['metadata'].get('split'))
    from .generator import PRODUCTS
    masked_to_splits=defaultdict(set)
    for r in rows:
        text=r['metadata']['response_body'].casefold()
        for _,product,fact,goal,circ in PRODUCTS:
            text=text.replace(fact.casefold(),'')
            for value in (product,goal,circ):text=text.replace(value.casefold(),'<slot>')
        text=normalize(re.sub(r'\$[\d,.]+','<amount>',text))
        masked_to_splits[text].add(r['metadata'].get('split'))
    findings,checks=near_duplicates(rows,config['near_duplicate_threshold'])
    atomic={f'D{i}':{'true':sum(r['labels'][f'D{i}'] for r in rows),'false':sum(not r['labels'][f'D{i}'] for r in rows)} for i in range(1,6)}
    boundary=Counter(b for r in rows for b in r['metadata']['boundaries'])
    lengths=[len(r['agent_response'].split()) for r in rows]
    summary={
        'total':len(rows),'schema_valid':sum(validity),'deterministic_contradictions':len(validity)-sum(validity),
        'classes':dict(classes),'categories':dict(categories),'atomic':atomic,'splits':split_counts,
        'exact_duplicate_inputs':len(rows)-len({input_key(r) for r in rows}),
        'exact_duplicate_responses':len(rows)-len({normalize(r['agent_response']) for r in rows}),
        'unique_sub_intents':len({r['metadata']['sub_intent'] for r in rows}),
        'source_scenario_groups':len({r['metadata']['source_template_id'] for r in rows}),
        'contrastive_records':sum(r['metadata']['contrastive'] for r in rows),
        'contrastive_target':round(len(rows)*config['contrastive_fraction']/5)*5,
        'boundaries':dict(sorted(boundary.items())),
        'missing_boundaries':[f'B{i:02}' for i in range(1,21) if f'B{i:02}' not in boundary],
        'dimensions':{field:dict(Counter(str(r['metadata'][field]) for r in rows)) for field in ['difficulty','conversation_type','recommendation_style','personalisation','mixed_content','voice_style','asr_imperfections','disclaimer','context_dependent']},
        'response_words':{'min':min(lengths),'max':max(lengths),'mean':round(sum(lengths)/len(lengths),2)},
        'repeated_core_bodies_after_number_normalization':len(rows)-len(body_counts),
        'core_bodies_present_in_multiple_splits':sum(len(v)>1 for v in bodies_to_splits.values()),
        'known_slot_masked_cores':len(masked_to_splits),
        'known_slot_masked_cores_present_in_multiple_splits':sum(len(v)>1 for v in masked_to_splits.values()),
        'lexical_near_duplicate_pairs':len(findings),'near_duplicate_pair_checks':checks,
        'cross_split_lexical_near_duplicate_pairs':sum(f['cross_split'] for f in findings),
        'near_duplicate_threshold':config['near_duplicate_threshold'],
        'most_repeated_response_bodies':body_counts.most_common(15),
        'most_repeated_opening_4_words':Counter(' '.join(r['agent_response'].split()[:4]) for r in rows).most_common(10),
        'recommendation_keyword_by_class':{c:sum(bool(re.search(r'\b(recommend|should|best)\b',r['agent_response'],re.I)) for r in rows if r['labels']['D6']==c) for c in CLASSES},
        'teacher_verified_count':sum(bool(r['metadata']['annotation'].get('independent_teacher_verified')) for r in rows),'annotation_status':'bootstrap_unverified',
        'api_cost_usd':0,'semantic_embedding_screen':'not_run',
        'tokenizer_validation':'not_run_no_local_Gemma_tokenizer','unsloth_build_dataset':'not_run_no_runtime_or_model',
        'training_integration':'D1-D6 exports require adapting legacy advice_type training configuration',
        'source_scenario_and_contrastive_family_leakage':sum(len(v)>1 for v in identifier_splits.values()),
        'independent_benchmark':False,
    }
    if summary['exact_duplicate_inputs'] or summary['exact_duplicate_responses']:
        raise ValueError('Exact duplicate input or response remains')
    (out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    csv_write(out/'class_distribution.csv',['class','target','actual'],[{'class':c,'target':distribution['classes'][c],'actual':classes[c]} for c in CLASSES])
    csv_write(out/'call_reason_distribution.csv',['category','target','actual'],[{'category':c,'target':v,'actual':categories[c]} for c,v in distribution['categories'].items()])
    csv_write(out/'atomic_decision_distribution.csv',['decision','true','false'],[{'decision':k,**v} for k,v in atomic.items()])
    csv_write(out/'boundary_coverage.csv',['boundary','actual'],[{'boundary':f'B{i:02}','actual':boundary[f'B{i:02}']} for i in range(1,21)])
    cross=[]
    for dim in ('call_category','product_type','difficulty','recommendation_style','personalisation','conversation_type'):
        counts=Counter((r['metadata'][dim],r['labels']['D6']) for r in rows)
        cross.extend({'dimension':dim,'value':v,'class':c,'count':n} for (v,c),n in sorted(counts.items()))
    csv_write(out/'cross_coverage.csv',['dimension','value','class','count'],cross)
    (out/'near_duplicate_pairs.json').write_text(json.dumps(findings,indent=2)+'\n')
    (out/'teacher_agreement.json').write_text(json.dumps({'status':'not_applicable_local_bootstrap','annotator_verifier_agreement':None,'teacher_calls':0,'automatically_verified':0},indent=2)+'\n')
    (out/'rejected_examples.jsonl').write_text('')
    (out/'generation_costs.json').write_text(json.dumps({'mode':'bootstrap','teacher_calls':0,'input_tokens':0,'output_tokens':0,'api_cost_usd':0,'cost_per_bootstrap_example_usd':0,'estimated_api_cost_2000':None,'estimated_api_cost_15000':None,'note':'No API provider or pricing selected. Do not interpret local costs as a teacher estimate.'},indent=2)+'\n')
    lines=[f'# Bootstrap pilot: {len(rows):,} records', '',
        'Labels are assigned by template construction. No independent teacher or human legal review was performed.', '',
        '| Class | Count |','|---|---:|',*[f'| {c} | {classes[c]} |' for c in CLASSES], '',
        f"Splits: {', '.join(f'{k} {v}' for k,v in split_counts.items())}.", '',
        f"All {len(rows):,} records pass structure, evidence-span and simplified label-consistency checks. Exact repeated inputs: {summary['exact_duplicate_inputs']}; exact repeated complete agent responses: {summary['exact_duplicate_responses']}.", '',
        'The master data contains no repeated classification instruction. Six direct decision questions are stored once in the shared schema. Clef exports include that schema in each training row, as required by the format.', '',
        f"Coverage: {len(categories)} call categories, {summary['unique_sub_intents']} sub-intents, {summary['contrastive_records']} contrastive records. Missing boundary tags: {summary['missing_boundaries']}.", '',
        f"Repetition remains at the underlying template level: {summary['repeated_core_bodies_after_number_normalization']} records repeat a core response body after numbers are normalized. Conversational openings and endings create wording variants; they do not create independent legal scenarios.", '',
        f"Lexical near-duplicate pairs at threshold {config['near_duplicate_threshold']}: {len(findings)}. Cross-split pairs: {summary['cross_split_lexical_near_duplicate_pairs']}. Shared normalized core bodies across splits: {summary['core_bodies_present_in_multiple_splits']}.", '',
        'Complete source scenarios and contrastive families stay in one split. Broad response patterns are shared across splits, so closely related paraphrases can remain. These splits do not meet the original independent-template benchmark standard.', '',
        'Difficulty is a requested design setting, not a measured legal difficulty. D3-only personalisation was not forced: asserting actual consideration will generally also support reasonable expectations in these scenarios. Contrastive wording is not a minimal-pair guarantee.', '',
        'No embedding-based semantic screening, independent semantic verification, production traffic matching, fixed challenge benchmark, Gemma token-length check or FastDecisionModel.build_dataset execution was performed. The existing training stack still expects its older advice_type schema and must be adapted before using these D1–D6 exports.', '',
        'Use this as a format and pipeline bootstrap. It is not a compliance-approved or independently verified training dataset. Broader scenario writing and independent annotation are needed before relying on classification performance.', '']
    (out/'dataset_quality.md').write_text('\n'.join(lines))
    return summary
