"""V4 export transaction: deduplicate first, split second, export last."""
from collections import Counter,defaultdict
import csv
import hashlib
import json
from pathlib import Path
import random
import re
import tempfile
from .schemas import ROOT,CLASSES,questions,read_yaml,validate
from .coverage_planner import plan,apportion
from .v4_generator import generate,GENERATOR_VERSION
from .clef_converter import convert
from .splitter import assert_disjoint


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

def jsonl(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))

def key(row):
    # This is the exact state that downstream consumers receive, not a metadata key.
    return ' '.join(convert(row)['state'].casefold().split())


def split_balanced(rows,sizes,seed):
    groups=defaultdict(list)
    for r in rows:groups[r['metadata']['source_template_id']].append(r)
    keys=list(groups);random.Random(seed).shuffle(keys)
    desired={'calibration':(50,30,40,30),'test':(50,30,40,30),'validation':(70,35,50,45)}
    result={};categories=sorted({r['metadata']['call_category'] for r in rows})
    proportions=Counter(r['metadata']['call_category'] for r in rows)
    for name in sorted(sizes,key=sizes.get):
        capacity=sizes[name]
        if name=='train':result[name]=[r for k in keys for r in groups[k]];keys=[];continue
        target=desired.get(name,tuple(apportion(dict(zip(CLASSES,[700,350,500,450])),capacity).values()))
        if capacity!=sum(target):target=tuple(apportion(dict(zip(CLASSES,target)),capacity).values())
        states={0:[((0,0,0,0),(0,)*len(categories),())]}
        for group_key in keys:
            rs=groups[group_key];n=len(rs)
            cls=Counter(r['labels']['D6'] for r in rs);vec=tuple(cls[c] for c in CLASSES)
            cats=tuple(sum(r['metadata']['call_category']==c for r in rs) for c in categories)
            additions=defaultdict(list)
            for used,opts in list(states.items()):
                if used+n>capacity:continue
                for v,catv,chosen in opts:
                    additions[used+n].append((tuple(a+b for a,b in zip(v,vec)),tuple(a+b for a,b in zip(catv,cats)),chosen+(group_key,)))
            for used,opts in additions.items():
                opts+=states.get(used,[])
                def score(item):
                    return sum(abs(a-b*used/capacity) for a,b in zip(item[0],target))+.12*sum(abs(a-proportions[c]*used/len(rows)) for a,c in zip(item[1],categories))
                unique={}
                for item in opts:
                    signature=item[0]
                    if signature not in unique or score(item)<score(unique[signature]):unique[signature]=item
                states[used]=sorted(unique.values(),key=score)[:20]
        feasible=[x for x in states.get(capacity,[]) if capacity<120 or min(x[0])>=30]
        if not feasible:raise ValueError(f'Cannot fill grouped {name} size with required class coverage')
        v,cv,chosen=min(feasible,key=lambda x:sum(abs(a-b) for a,b in zip(x[0],target)))
        selected=set(chosen);result[name]=[r for k in keys if k in selected for r in groups[k]];keys=[k for k in keys if k not in selected]
    if keys:raise ValueError('Unassigned scenario groups')
    assert_disjoint(result)
    if {k:len(v) for k,v in result.items()}!=sizes:raise ValueError('Split size mismatch')
    return {s:result[s] for s in sizes}


def context_ngrams(rows):
    counts=defaultdict(Counter)
    for r in rows:
        words=re.findall(r"[a-z']+",r['customer_context'].casefold())
        seen={tuple(words[i:i+n]) for n in range(1,6) for i in range(len(words)-n+1)}
        for gram in seen:counts[gram][r['labels']['D6']]+=1
    issues=[]
    for gram,c in counts.items():
        support=sum(c.values());cls,n=c.most_common(1)[0]
        if support>=30 and n/support>.8:issues.append({'ngram':' '.join(gram),'support':support,'class':cls,'precision':round(n/support,4)})
    return sorted(issues,key=lambda x:(-x['precision'],-x['support']))


def binary_context_baseline(splits):
    import math
    classes=('general_advice','personal_advice');tr=[r for r in splits['train'] if r['labels']['D6'] in classes]
    tokens=lambda r:re.findall(r"[a-z']+",r['customer_context'].casefold())
    counters={c:Counter() for c in classes};prior=Counter()
    for r in tr:prior[r['labels']['D6']]+=1;counters[r['labels']['D6']].update(tokens(r))
    vocab={w for c in counters.values() for w in c};totals={c:sum(v.values()) for c,v in counters.items()}
    predict=lambda r:max(classes,key=lambda c:__import__('math').log(prior[c]+1)+sum(__import__('math').log((counters[c][w]+1)/(totals[c]+len(vocab))) for w in tokens(r)))
    result={}
    for s,rs in splits.items():
        rs=[r for r in rs if r['labels']['D6'] in classes]
        if not rs:continue
        correct=sum(predict(r)==r['labels']['D6'] for r in rs);base=max(Counter(r['labels']['D6'] for r in rs).values())/len(rs)
        result[s]={'n':len(rs),'correct':correct,'accuracy':round(correct/len(rs),4),'majority_baseline':round(base,4),'within_majority_plus_10pp':correct/len(rs)<=base+.1}
    return result


def report(rows,splits):
    context_class=defaultdict(Counter)
    for r in rows:context_class[r['customer_context']][r['labels']['D6']]+=1
    issues=context_ngrams(rows)
    rule_splits=defaultdict(set)
    for s,rs in splits.items():
        for r in rs:rule_splits[r['metadata']['response_rule_id']].add(s)
    return {'records':len(rows),'distinct_states':len({key(r) for r in rows}),'unique_scenario_contexts':len(context_class),
        'classes':dict(Counter(r['labels']['D6'] for r in rows)),
        'categories':dict(Counter(r['metadata']['call_category'] for r in rows)),
        'split_counts':{s:len(rs) for s,rs in splits.items()},
        'split_classes':{s:dict(Counter(r['labels']['D6'] for r in rs)) for s,rs in splits.items()},
        'split_categories':{s:dict(Counter(r['metadata']['call_category'] for r in rs)) for s,rs in splits.items()},
        'duplicate_states_by_export':{s:len(rs)-len({key(r) for r in rs}) for s,rs in splits.items()},
        'credit_only_recommendations_by_split':{s:sum(r['metadata']['credit_only_recommendation'] for r in rs) for s,rs in splits.items()},
        'disclosure_by_class':{c:dict(Counter(str(r['metadata']['disclosure_present']) for r in rows if r['labels']['D6']==c)) for c in CLASSES},
        'general_request_by_class':{c:sum(r['metadata']['general_request_present'] for r in rows if r['labels']['D6']==c) for c in CLASSES},
        'disclaimer_by_class':{c:sum(r['metadata']['disclaimer'] for r in rows if r['labels']['D6']==c) for c in CLASSES},
        'context_ngram_violations':issues,'context_ngram_rule':'document support >=30 and class precision >0.8; word ngrams 1..5',
        'advice_only_context_baseline':binary_context_baseline(splits),
        'response_rules':len(rule_splits),'response_rules_shared_across_splits':sum(len(v)>1 for v in rule_splits.values()),
        'response_template_independent_holdout':False,'separate_challenge_author_required':True,
        'review_id_files_read':False,'human_legal_reviewed':False,'independently_verified_labels':False,
        'notes':['Contexts precede class assignment and are reused across target classes.','A general opinion after disclosure requires individual legal review of reasonable expectations, not just checking a disclaimer.','Shared response rules remain; these are context-grouped development splits, not an independent legal benchmark.']}


def run_v4(config,distribution,output,total,seed,resume=False,dry_run=False):
    config=Path(config).resolve();distribution=Path(distribution).resolve();out=Path(output)
    if total<4:raise ValueError('At least four records required')
    cfg=read_yaml(config);dist=read_yaml(distribution);tax=read_yaml(ROOT/'config/dataset/call_taxonomy.yaml')
    matrix=plan(dist,tax,total,seed);sizes=apportion(dist['splits'],total)
    settings={'generator':GENERATOR_VERSION,'target':total,'seed':seed,'inputs':{str(p.relative_to(ROOT)):digest(p) for p in [config,distribution,ROOT/'config/dataset/call_taxonomy.yaml',ROOT/'config/dataset/scenario_profiles_v4.yaml',ROOT/'config/dataset/question_schema_v1.yaml',ROOT/'src/decision_guardrail/data_generation/v4_generator.py',ROOT/'src/decision_guardrail/data_generation/v4_pipeline.py',ROOT/'src/decision_guardrail/data_generation/clef_converter.py',ROOT/'src/decision_guardrail/data_generation/schemas.py',ROOT/'src/decision_guardrail/data_generation/coverage_planner.py',ROOT/'src/decision_guardrail/data_generation/pipeline.py',ROOT/'src/decision_guardrail/data_generation/splitter.py']}}
    if dry_run:return {'settings':settings,'external_teacher_calls':0,'api_cost_usd':0,'split_targets':sizes}
    if out.exists() and any(out.iterdir()):
        if not resume:raise ValueError('Destination must be new; no artifact is overwritten')
        manifest=out/'manifest.json'
        if not manifest.exists():raise ValueError('Incomplete output differs from a completed verified run; preserve it and use a new output directory')
        saved=json.loads(manifest.read_text())
        if saved['settings']!=settings:raise ValueError('Resume settings or source differ')
        for name,sha in saved['files'].items():
            if digest(out/name)!=sha:raise ValueError(f'Resume artifact hash differs: {name}')
        return {'resumed':True,'records':saved['record_count'],'output':str(out)}
    rows=generate(matrix,tax,cfg,seed)
    dedup={};rejected=[]
    for r in rows:
        validate(r);k=key(r)
        if k in dedup:rejected.append({'id':r['id'],'duplicate_of':dedup[k]['id'],'reason':'duplicate_export_state'})
        else:dedup[k]=r
    accepted=list(dedup.values())
    if len(accepted)!=total:raise ValueError('Deduplication left a quota shortfall; no duplicate rows will be exported')
    if total==2000:splits=split_balanced(accepted,sizes,seed)
    else:
        from .splitter import split
        splits=split(accepted,sizes,seed)
    for s,rs in splits.items():
        for r in rs:r['metadata']['split']=s
    metrics=report(accepted,splits)
    if metrics['context_ngram_violations']:raise ValueError('Customer-context ngram cue acceptance failed')
    if total==2000:
        for s in ('validation','calibration','test'):
            if min(metrics['split_classes'][s].values())<30:raise ValueError('Heldout class minimum violated after deduplication')
        if metrics['credit_only_recommendations_by_split']['train']<80:raise ValueError('Credit recommendation coverage below 80 in train')
        if any(not v['within_majority_plus_10pp'] for s,v in metrics['advice_only_context_baseline'].items() if s!='train'):raise ValueError('Advice-only context shortcut baseline failed')
    # Nothing is written to the final output until structural/quality gates pass.
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='v4-dataset-',dir=out.parent) as temporary:
        staged=Path(temporary)/'result';staged.mkdir()
        jsonl(staged/'master_dataset.jsonl',accepted);jsonl(staged/'rejected_candidates.jsonl',rejected)
        dump(staged/'questions.json',questions());dump(staged/'quality_report.json',metrics)
        index=[];master_lines={r['id']:n for n,r in enumerate(accepted,1)}
        for s,rs in splits.items():
            jsonl(staged/'splits'/f'{s}.jsonl',rs);jsonl(staged/'clef'/f'{s}.jsonl',[convert(r) for r in rs])
            for n,r in enumerate(rs,1):index.append({'record_id':r['id'],'master_line':master_lines[r['id']],'split':s,'split_line':n,'clef_line':n,'scenario_family_id':r['metadata']['scenario_family_id']})
        with (staged/'record_index.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=['record_id','master_line','split','split_line','clef_line','scenario_family_id']);writer.writeheader();writer.writerows(index)
        (staged/'quality_report.md').write_text('# Direct v4 dataset\n\nAll exports are built from the same deduplicated rows. Contexts are shared across different target classes. See quality_report.json for exact counts, cue checks, credit coverage and split tables.\n\nLabels remain local construction labels pending independent and legal review. Shared response rules still limit main-split generalisation claims. A separate blind-authored challenge set is packaged separately.\n')
        dump(staged/'manifest.json',{'dataset_version':GENERATOR_VERSION,'schema_version':'financial_advice_v1','record_count':len(accepted),'settings':settings,'provenance':{'generator':GENERATOR_VERSION,'annotator':'authored_response_spec','independent_verifier':None,'human_legal_reviewed':False},'generation_timestamp_policy':'omitted_to_keep_content_replays_byte_identical','files':{str(p.relative_to(staged)):digest(p) for p in sorted(staged.rglob('*')) if p.is_file() and p.name!='manifest.json'}})
        if out.exists():out.rmdir()
        staged.rename(out)
    return {'records':len(accepted),'output':str(out),'splits':sizes,'api_cost_usd':0,'annotation_status':'v4_construction_labels_pending_independent_review'}
