"""Publication gate for an explicitly authored v14 pack; never a quota expander.

There is no v14 dataset until real authored records pass this path. Reviewed
designs are not shuffled into train or renamed to satisfy coverage floors.
"""
from collections import Counter, defaultdict
import json
from pathlib import Path
import tempfile

import yaml

from .dialogue_exposure import design_fingerprint, exposure_hits, read_jsonl, sha, source_paths
from .dialogue_exposure_policy import load_policy
from .context_v14_authoring import inherited


def load_ledger(root):
    return load_policy(root, Path('config/dataset/dialogue_exposure_policy_v14.json'))
from .dialogue_release_audit import audit, SPLITS
from .context_v5_release import lexical_candidates
from .context_v5_review import digest, write_json, write_rows
from .context_v6_release import native_questions, normal_input, validate_rows
from .context_v11_audits import naturalness_report
from ..dataset import state_text

GENERATOR = "streaming-context-dialogue-v14"
ACCEPTANCE = "config/dataset/acceptance_context_v14.yaml"


class ConstructionBlocked(ValueError):
    def __init__(self, report: dict):
        self.report = report
        super().__init__("V14 construction blocked: " + json.dumps(report["failures"]))


def validate_design_registry(rows: list[dict], designs: list[dict]) -> list[dict]:
    failures, by_id, fingerprints = [], {}, {}
    required = {"design_id", "product_topic", "domain", "call_category", "customer_goal", "decision_basis", "split", "source_design_ids"}
    for design in designs:
        if not required <= design.keys() or not all(isinstance(design.get(k), str) and design[k].strip()
                    for k in required - {"source_design_ids"}) or not isinstance(design.get("source_design_ids"), list):
            failures.append(dict(check="invalid_authored_design", design_id=design.get("design_id")))
            continue
        key = design["design_id"]
        fp = design_fingerprint(design)
        if key in by_id or fp in fingerprints:
            failures.append(dict(check="duplicate_design_identity_or_content", design_id=key))
        by_id[key] = design
        fingerprints[fp] = key
    used = set()
    for row in rows:
        meta = row["metadata"]
        key = meta.get("contrast_family")
        design = by_id.get(key)
        used.add(key)
        if design is None:
            failures.append(dict(check="unregistered_design", record_id=row["id"]))
            continue
        if (meta.get("design_sha256") != design_fingerprint(design) or
                meta.get("parent_topic") != design["product_topic"] or
                meta.get("call_category") != design["call_category"] or
                meta.get("scenario_product_domains") != [design["domain"]] or
                meta.get("split") != design["split"]):
            failures.append(dict(check="record_design_binding_mismatch", record_id=row["id"]))
    if set(by_id) - used:
        failures.append(dict(check="unused_authored_designs", actual=sorted(set(by_id) - used)))
    return failures


def construction_report(root: Path, rows: list[dict], designs: list[dict], bindings: dict) -> dict:
    cumulative = load_ledger(root)
    cfg = yaml.safe_load((root / ACCEPTANCE).read_text())
    options = dict(minimum_contexts_per_call=cfg["minimum_contexts_per_call_per_partition"],
                   minimum_designs_per_call=cfg["minimum_designs_per_call_per_partition"],
                   minimum_rows_per_class=cfg["minimum_rows_per_class_per_partition"],
                   minimum_other_fraction=cfg["minimum_other_fraction_per_partition"])
    report = audit(rows, set(cumulative["reviewed_design_ids"]), bindings, options, cfg["minimum_records_exclusive"])
    product_topics = {r["metadata"]["parent_topic"] for r in rows if r["metadata"]["scenario_product_domains"] != ["service"]}
    if len(product_topics) < cfg["minimum_product_topics"]:
        report["failures"].append(dict(check="minimum_product_topics", actual=len(product_topics)))
    for split in SPLITS:
        count = report["partitions"][split]["product_topics"]
        if count < cfg["minimum_product_topics_per_partition"]:
            report["failures"].append(dict(check="minimum_product_topics_per_partition", split=split, actual=count))
    classes = Counter(r["labels"]["D7"] for r in rows)
    if len(classes) != 4 or min(classes.values(), default=0) < cfg["minimum_each_final_class"]:
        report["failures"].append(dict(check="minimum_each_final_class", actual=dict(classes)))
    report["failures"].extend(validate_design_registry(rows, designs))
    # Filter invalid entries before content indexing. They are already failures.
    usable = [d for d in designs if all(isinstance(d.get(k), str) for k in
              ("design_id", "product_topic", "customer_goal", "decision_basis"))]
    hits = exposure_hits(rows, cumulative, usable)
    report.update(cumulative_exposure_hits=hits, cumulative_review_files=sorted(cumulative["review_files"]),
                  cumulative_ledger_sha256=cumulative["ledger_sha256"], approved_training_records=0,
                  generator=GENERATOR)
    if hits:
        report["failures"].append(dict(check="cumulative_review_exposure", actual=len(hits)))
    if not report["failures"]:
        natural = naturalness_report(rows)
        report["naturalness"] = natural
        for name, (lo, hi) in cfg["fractions"].items():
            value = natural["fractions"][name]
            if not lo <= value <= hi:
                report["failures"].append(dict(check=name, actual=value, expected=[lo, hi]))
        for name in ("self_quotation_rows", "invented_speaker_rows", "counterweight_rows"):
            if natural[name]:
                report["failures"].append(dict(check=name, actual=natural[name]))
        if natural["personal_i_would_fraction"] > cfg["maximum_personal_i_would_fraction"]:
            report["failures"].append(dict(check="personal_i_would", actual=natural["personal_i_would_fraction"]))
        if natural["max_noninitial_turn_repetitions"] > cfg["maximum_noninitial_turn_repetitions"]:
            report["failures"].append(dict(check="repeated_noninitial_turn", actual=natural["max_noninitial_turn_repetitions"]))
        baseline = natural["word_baselines"]["agent_response"]
        test_classes = Counter(r["labels"]["D7"] for r in rows if r["metadata"]["split"] == "test")
        majority = max(test_classes.values()) / sum(test_classes.values())
        report["response_only_diagnostic"] = dict(**baseline, majority_baseline=majority,
            test_class_counts=dict(test_classes),
            status="not_informative_below_majority" if baseline["accuracy"] < majority else "descriptive_only")
        if baseline["accuracy"] > cfg["maximum_response_only_nb_accuracy"]:
            report["failures"].append(dict(check="response_only_nb_accuracy", actual=baseline["accuracy"]))
    report["training_allocation"] = {}
    for name, values in (("snapshots", rows), ("designs", designs)):
        count = sum(v["metadata"]["split"] == "train" if name == "snapshots" else v["split"] == "train" for v in values)
        value = count / len(values) if values else 0.0
        report["training_allocation"][name] = dict(train=count, total=len(values), fraction=value)
        if not .60 <= value <= .70: report["failures"].append(dict(check="training_share_"+name, actual=value))
    if report["partitions"]["train"]["product_topics"] < 35:
        report["failures"].append(dict(check="training_product_topic_breadth", actual=report["partitions"]["train"]["product_topics"]))
    report["boundary_support_by_partition"] = {}
    for split in SPLITS:
        selected = [r for r in rows if r["metadata"]["split"] == split and r["labels"]["D7"] == "personal_advice"]
        support = {}; personal_designs = {r["metadata"]["contrast_family"] for r in selected}
        for group, d3, d4 in (("D3_only", True, False), ("D4_only", False, True)):
            found = [r for r in selected if (r["labels"]["D3"],r["labels"]["D4"]) == (d3,d4)]
            ids = {r["metadata"]["contrast_family"] for r in found}
            complete = {r["input"]["agent_response"] for r in found if any(s["is_final"] for s in r["metadata"]["source_refs"])}
            topics={r['metadata']['parent_topic'] for r in found}
            domains=sorted({domain for r in found for domain in r['metadata']['scenario_product_domains']})
            support[group] = dict(designs=len(ids), distinct_topics=len(topics), domains=domains,
                complete_targets=len(complete), fraction_of_personal_designs=len(ids)/max(1,len(personal_designs)))
            if group=='D3_only' and len(topics)<5:
                report['failures'].append(dict(check='D3_only_topic_breadth', split=split, actual=len(topics)))
            if len(ids) < 5 or len(ids)/max(1,len(personal_designs)) < .15:
                report["failures"].append(dict(check="discordant_design_support",split=split,group=group,actual=len(ids)))
        report["boundary_support_by_partition"][split] = support
    report["construction_gate_passed"] = not report["failures"]
    return report


def validate_retention_provenance(root, rows, provenance):
    retained=[r for r in rows if r['id'].startswith('sctxv13-')]
    allowed={r['id']:r for r in inherited(root)[0]}
    if any(r != allowed.get(r['id']) for r in retained):
        raise ValueError('V14 retention contains a row outside the exact curated source')
    expected=[dict(record_id=r['id'],source='data/generated/streaming_context_v13_release/records.jsonl',
        source_manifest_sha256=sha(root/'data/generated/streaming_context_v13_release/manifest.json'),
        source_row_sha256=digest(r),split=r['metadata']['split']) for r in retained]
    if provenance.get('retention') != expected:
        raise ValueError('V14 retention provenance does not match the exact inherited records')


def verify(root: Path, output: Path) -> dict:
    manifest = json.loads((output / "manifest.json").read_text())
    if (manifest.get("generator") != GENERATOR or manifest.get("training_ready") is not False or
            manifest.get("approved_training_records") != 0 or manifest.get("native_export_directory") != "construction_clef" or
            manifest.get("status") != "pre_annotation_not_trainable" or
            (output / "clef").exists() or json.loads((output / "annotation_ledger.json").read_text()) != []):
        raise ValueError("Invalid v14 construction manifest or annotation state")
    actual_files = {str(p.relative_to(output)) for p in output.rglob("*") if p.is_file() and p.name != "manifest.json"}
    if actual_files != set(manifest["files"]):
        raise ValueError("V14 manifest does not cover every artifact")
    for name, expected in manifest["files"].items():
        if not (output / name).resolve().is_relative_to(output.resolve()) or sha(output / name) != expected:
            raise ValueError("V14 artifact hash mismatch: " + name)
    for name, expected in manifest["source_hashes"].items():
        if not (root / name).resolve().is_relative_to(root.resolve()) or sha(root / name) != expected:
            raise ValueError("V14 source hash mismatch: " + name)
    rows = read_jsonl(output / "records.jsonl")
    validate_retention_provenance(root, rows, json.loads((output / "assembly_provenance.json").read_text()))
    if manifest["records"] != len(rows):
        raise ValueError("V14 manifest record count differs")
    report = construction_report(root, rows, read_jsonl(output / "designs.jsonl"),
                                 json.loads((output / "dialogue_bindings.json").read_text()))
    if not report["construction_gate_passed"]:
        raise ConstructionBlocked(report)
    integrity, trajectories = structural_report(root, rows, exclude=output)
    report["structural_report"] = integrity
    if report != json.loads((output / "quality_report.json").read_text()) or trajectories != json.loads((output / "trajectories.json").read_text()):
        raise ValueError("V14 quality or speech trajectories differ from revalidation")
    schema, qs = native_questions(root)
    if json.loads((output / "questions.json").read_text()) != schema or json.loads((output / "native_questions.json").read_text()) != qs:
        raise ValueError("V14 saved question contract differs")
    for split in SPLITS:
        selected = [r for r in rows if r["metadata"]["split"] == split]
        if (read_jsonl(output / "splits" / f"{split}.jsonl") != selected or
                read_jsonl(output / "construction_clef" / f"{split}.jsonl") != [dict(state=state_text(**r["input"]), questions=qs, gold=r["labels"]) for r in selected]):
            raise ValueError("V14 native export differs from candidate records")
    return report


def structural_report(root: Path, rows: list[dict], exclude: Path | None = None) -> tuple[dict, list]:
    """Retain the earlier contract, leakage, prefix and shortcut checks too."""
    _, qs = native_questions(root)
    history = set()
    candidate_identity = json.dumps(rows, sort_keys=True, ensure_ascii=False)
    for path in source_paths(root):
        if exclude is not None and path.resolve().is_relative_to(exclude.resolve()):
            continue
        source = read_jsonl(path)
        manifest_path = path.parent / "manifest.json"
        # A deterministic replay can coexist with its exact published v14
        # corpus. Compare all records, not merely inputs: changing annotations,
        # labels, lineage or taking a subset does not receive this exemption.
        if (path.name == "records.jsonl" and manifest_path.exists() and
                json.loads(manifest_path.read_text()).get("generator") == GENERATOR and
                json.dumps(source, sort_keys=True, ensure_ascii=False) == candidate_identity):
            continue
        for row in source:
            inp = row.get("input", row)
            if "customer_context" in inp and "agent_response" in inp:
                history.add(normal_input(inp))
    retained, _, _, _ = inherited(root)
    allowed = {normal_input(r['input']): r for r in retained}
    for row in rows:
        if normal_input(row['input']) in history and row != allowed.get(normal_input(row['input'])):
            raise ValueError('Historical input reused outside exact checked retention ledger in v14')
    text_splits = {field: defaultdict(set) for field in ("customer_context", "agent_response")}
    for row in rows:
        for field, groups in text_splits.items():
            groups[normal_input(row["input"])[0 if field == "customer_context" else 1]].add(row["metadata"]["split"])
    if any(len(splits) > 1 for groups in text_splits.values() for splits in groups.values()):
        raise ValueError("Context or target crosses v14 partitions")
    if lexical_candidates(rows):
        raise ValueError("Cross-partition lexical neighbours require remediation")
    return validate_rows(rows, [], qs)


def build(root: Path, authored: Path, output: Path) -> dict:
    if output.exists():
        raise ValueError("Use a new output path; preserve frozen releases")
    required = ("records.jsonl", "designs.jsonl", "dialogue_bindings.json", "assembly_report.json")
    rows = read_jsonl(authored / required[0])
    designs = read_jsonl(authored / required[1])
    bindings = json.loads((authored / required[2]).read_text())
    validate_retention_provenance(root, rows, json.loads((authored / "assembly_report.json").read_text()))
    report = construction_report(root, rows, designs, bindings)
    # Nothing is created at output, including an apparently usable partial
    # release, unless all mandatory construction and structural checks pass.
    if not report["construction_gate_passed"]:
        raise ConstructionBlocked(report)
    integrity, trajectories = structural_report(root, rows)
    report["structural_report"] = integrity
    schema, qs = native_questions(root)
    inputs = {str((authored / name).resolve().relative_to(root.resolve())): sha(authored / name) for name in required}
    sources = [ACCEPTANCE, "config/dataset/dialogue_exposure_policy_v14.json",
               "src/decision_guardrail/data_generation/context_v14_release.py",
               "src/decision_guardrail/data_generation/dialogue_release_audit.py",
               "src/decision_guardrail/data_generation/dialogue_exposure.py",
               "src/decision_guardrail/data_generation/context_v5_release.py",
               "src/decision_guardrail/data_generation/context_v5_review.py",
               "src/decision_guardrail/data_generation/context_v6_release.py",
               "src/decision_guardrail/data_generation/context_v10_audits.py",
               "src/decision_guardrail/data_generation/context_v11_audits.py",
               "src/decision_guardrail/data_generation/streaming_15k_catalog.py",
               "src/decision_guardrail/dataset.py", "src/decision_guardrail/schema.py",
               "config/dataset/question_schema_streaming_v6.yaml"]
    sources += [str(p.relative_to(root)) for p in sorted((root / 'data/authored/streaming_context_v14').glob('*.json'))]
    sources += ['src/decision_guardrail/data_generation/context_v14_authoring.py',
                'src/decision_guardrail/data_generation/dialogue_exposure_policy.py',
                'src/decision_guardrail/data_generation/context_v12_authoring.py',
                'src/decision_guardrail/data_generation/context_v14_review.py',
                'docs/annotation_standard_streaming_v14.md',
                'scripts/assemble_context_v14.py', 'scripts/build_context_v14_release.py',
                'data/generated/streaming_context_v13_release/records.jsonl',
                'data/generated/streaming_context_v13_release/designs.jsonl',
                'data/generated/streaming_context_v13_release/dialogue_bindings.json',
                'data/generated/streaming_context_v13_release/manifest.json',
                'outputs/context_v14_corrections_20261025/stage02/unexposed_working_pool_not_release.jsonl',
                'outputs/context_v14_corrections_20261025/stage02/exposure_ledger.json',
                'data/generated/streaming_context_v12_release/review.html']
    inventory=json.loads((root/'data/authored/streaming_context_v14/build_sources.json').read_text())
    for name in inventory['python_sources']:
        if not name.startswith('src/decision_guardrail/') or not (root/name).resolve().is_relative_to(root.resolve()):
            raise ValueError('Invalid pinned source inventory path')
    sources += inventory['python_sources']
    sources += ['scripts/audit_dialogue_release.py','scripts/verify_historical_context.py']
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="context-v14-", dir=output.parent) as tmp:
        stage = Path(tmp) / "release"
        stage.mkdir()
        write_rows(stage / "records.jsonl", rows)
        write_rows(stage / "designs.jsonl", designs)
        write_json(stage / "dialogue_bindings.json", bindings)
        write_json(stage / "quality_report.json", report)
        write_json(stage / "trajectories.json", trajectories)
        write_json(stage / "questions.json", schema)
        write_json(stage / "native_questions.json", qs)
        write_json(stage / "annotation_ledger.json", [])
        write_json(stage / 'assembly_provenance.json', json.loads((authored / 'assembly_report.json').read_text()))
        write_json(stage / 'comparison_correction_ledger.json', json.loads((root / 'outputs/context_v14_corrections_20261025/stage02/label_changes.json').read_text()))
        from .context_v14_review import write_review_artifacts
        write_review_artifacts(root, stage, rows, designs, report)
        guide = stage / "README.md"
        guide.write_text(guide.read_text() + "\nExact rebuild, from the project root, to a NEW in-project output path:\n\n```sh\n.venv/bin/python scripts/build_context_v14_release.py --authored " + str(authored.resolve().relative_to(root.resolve())) + " --output outputs/a_new_v14_replay\n```\n\nAll annotations are proposals. The paired category-question histories must be adjudicated separately from actual customer-use histories.\n")
        index = {r["id"]: i for i, r in enumerate(rows, 1)}
        for folder in ("splits", "construction_clef", "clef_index"):
            (stage / folder).mkdir()
        for split in SPLITS:
            selected = [r for r in rows if r["metadata"]["split"] == split]
            write_rows(stage / "splits" / f"{split}.jsonl", selected)
            write_rows(stage / "construction_clef" / f"{split}.jsonl", [dict(state=state_text(**r["input"]), questions=qs, gold=r["labels"]) for r in selected])
            write_rows(stage / "clef_index" / f"{split}.jsonl", [dict(export_line=i, record_id=r["id"], records_jsonl_line=index[r["id"]],
                recommendation_withdrawn_in_target=r["metadata"].get("recommendation_withdrawn_in_target", False)) for i, r in enumerate(selected, 1)])
        write_json(stage / "manifest.json", dict(generator=GENERATOR, schema_version=rows[0]["schema_version"], records=len(rows),
            status="pre_annotation_not_trainable", construction_acceptance_passed=True, training_ready=False,
            approved_training_records=0, native_export_directory="construction_clef", annotation_ledger_path="annotation_ledger.json",
            cumulative_ledger_sha256=report["cumulative_ledger_sha256"],
            source_hashes={**inputs, **{name: sha(root / name) for name in sources}},
            files={str(p.relative_to(stage)): sha(p) for p in sorted(stage.rglob("*")) if p.is_file()}))
        if output.exists():
            raise ValueError("Output appeared while building; refusing replacement")
        stage.rename(output)
    return report
