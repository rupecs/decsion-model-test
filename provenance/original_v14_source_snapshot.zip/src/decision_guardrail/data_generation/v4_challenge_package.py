"""Package a blind-authored bank without revising its substantive annotations.

Screening is performed after authoring. Quarantined cases stay available for audit.
This does not turn an author's labels into independent verification of those labels.
"""
from collections import Counter
import json
from pathlib import Path
import re
import shutil
import tempfile
from .schemas import ROOT, CLASSES, load_rows, questions
from .clef_converter import convert
from .v4_pipeline import digest, dump, jsonl, key, context_ngrams, binary_context_baseline

AUTHOR_FILES = (
    'independent_challenge_v4.jsonl',
    'independent_challenge_v4_author_report.md',
    'independent_challenge_v4_reserve.jsonl',
    'independent_challenge_v4_reserve_author_note.md',
    'independent_challenge_v4_reserve_implicit.jsonl',
    'independent_challenge_v4_reserve_implicit_author_note.md',
    'independent_challenge_v4_additional_reserves.jsonl',
    'independent_challenge_v4_additional_reserves_author_note.md',
)


def words(text):
    return set(re.findall(r"[a-z0-9']+", text.casefold()))


def screen(rows, pilot, threshold=.5):
    reference = [words(r['agent_response']) for r in pilot]
    results = []
    for row in rows:
        target = words(row['agent_response'])
        score, index = max((len(target & ref) / len(target | ref), i) for i, ref in enumerate(reference))
        results.append({'record_id': row['id'], 'nearest_pilot_id': pilot[index]['id'],
                        'target_token_set_jaccard': round(score, 6), 'quarantine': score >= threshold})
    return results


def package(pilot_path, output):
    pilot_path = Path(pilot_path).resolve(); output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise ValueError('Challenge output must be new; no author file is overwritten')
    pilot = load_rows(pilot_path)
    author_dir = ROOT / 'data/authoring'
    original = load_rows(author_dir / AUTHOR_FILES[0])
    reserves = load_rows(author_dir / AUTHOR_FILES[2]) + load_rows(author_dir / AUTHOR_FILES[4]) + load_rows(author_dir / AUTHOR_FILES[6])
    checks = screen(original + reserves, pilot)
    flagged = {x['record_id'] for x in checks if x['quarantine']}
    selected = [r for r in original if r['id'] not in flagged]
    replacements = []
    for excluded in [r for r in original if r['id'] in flagged]:
        candidates = [r for r in reserves if r['id'] not in flagged and r not in selected
                      and r['labels'] == excluded['labels']
                      and r['metadata']['conversation_type']==excluded['metadata']['conversation_type']]
        if not candidates:
            raise ValueError('No independently authored reserve with the same decision stratum')
        replacement = candidates[0]; selected.append(replacement)
        replacements.append({'excluded': excluded['id'], 'replacement': replacement['id'],
                             'reason': 'post_authoring_target_similarity_screen'})
    # Explicit post-authoring coverage curation. No labels or text are rewritten.
    # The blind author received coverage requests, never a pilot target or review.
    coverage_pairs=[('independent_v4_044','independent_v4_204'),
                    ('independent_v4_091','independent_v4_205'),
                    ('independent_v4_122','independent_v4_206')]
    for old_id,new_id in coverage_pairs:
        old=next(r for r in selected if r['id']==old_id)
        new=next(r for r in reserves if r['id']==new_id)
        if new_id in flagged or old['labels']['D6']!=new['labels']['D6']:
            raise ValueError('Invalid blind-authored coverage replacement')
        selected[selected.index(old)]=new
        replacements.append({'excluded':old_id,'replacement':new_id,
                             'reason':'ordinary_credit_context_across_non_other_classes_and_substantive_long_histories'})
    if len(selected) != 200 or Counter(r['labels']['D6'] for r in selected) != Counter(dict.fromkeys(CLASSES, 50)):
        raise ValueError('Challenge must contain 200 records with 50 per class')
    states = {key(r) for r in selected}; pilot_states = {key(r) for r in pilot}
    if len(states) != 200 or states & pilot_states:
        raise ValueError('Duplicate challenge input or exact pilot overlap')
    selected_ids = {r['id'] for r in selected}
    nearest = {x['record_id']:x for x in checks}
    tags = lambda r: set(r['metadata'].get('challenge_tags', []))
    class_context = {c: {tag:sum(tag in tags(r) for r in selected if r['labels']['D6'] == c)
                         for tag in ('disclosure', 'general_request', 'category_question', 'disclaimer')}
                     for c in CLASSES}
    splits = {'train':load_rows(pilot_path/'splits/train.jsonl'), 'challenge': selected}
    metrics = {
        'records':len(selected), 'distinct_export_states':len(states),
        'classes':dict(Counter(r['labels']['D6'] for r in selected)),
        'individually_authored_scenario_ids':len({r['metadata']['scenario_family_id'] for r in selected}),
        'conversation_lengths_by_class':{c:dict(Counter(r['metadata']['conversation_type'] for r in selected if r['labels']['D6']==c)) for c in CLASSES},
        'credit_only_recommendations':sum('ordinary_credit_recommendation' in tags(r) for r in selected),
        'general_after_disclosure':sum(r['labels']['D6']=='general_advice' and 'disclosure' in tags(r) for r in selected),
        'D3_false_D4_true':sum(not r['labels']['D3'] and r['labels']['D4'] for r in selected),
        'author_tag_counts_by_class':class_context,
        'post_authoring_replacements':replacements,
        'exact_pilot_state_overlap':0,
        'maximum_selected_target_token_jaccard':max(nearest[i]['target_token_set_jaccard'] for i in selected_ids),
        'similarity_screen_threshold':.5,
        'similarity_screen_limit':'Target token-set Jaccard only; no embedding screen or proof of semantic independence.',
        'context_ngram_diagnostics':context_ngrams(selected),
        'advice_only_pilot_trained_context_baseline':binary_context_baseline(splits)['challenge'],
        'independently_authored_from_main_generator':True,
        'author': 'separate blind_challenge_author model agent; same model family',
        'author_and_labeler_are_same_agent':True,
        'independently_verified_labels':False, 'human_legal_reviewed':False,
        'status':'blind_authored_candidate_benchmark_pending_independent_annotation_and_legal_review',
        'uncertainty_note':'50 records/class: an observed 50% class accuracy has a 95% Wilson interval of approximately 36.6%-63.4%, assuming independent Bernoulli trials. No accuracy is asserted here.',
        'limitations':[
            'The parent performed a post-authoring similarity screen, selected a matched-stratum/length reserve, and made three coverage replacements. This is disclosed curation.',
            'Context properties are not exactly balanced by class. Author tags are not an exhaustive linguistic census.',
            'Ordinary-credit contexts span all four target classes after coverage curation; this does not establish absence of every lexical or semantic cue.',
            'No reviewer has independently adjudicated every challenge label. Claims exceptions, scope and general-after-disclosure boundaries need legal review.',
            'Scenario identifier uniqueness is not evidence that all situations are statistically independent.',
        ],
    }
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='v4-challenge-',dir=output.parent) as temporary:
        staged=Path(temporary)/'result';staged.mkdir()
        jsonl(staged/'master_dataset.jsonl',selected)
        jsonl(staged/'clef.jsonl',[convert(r) for r in selected])
        jsonl(staged/'quarantined_author_rows.jsonl',[r for r in original+reserves if r['id'] in flagged])
        jsonl(staged/'coverage_excluded_author_rows.jsonl',[r for r in original if r['id'] in {old for old,new in coverage_pairs}])
        jsonl(staged/'unused_reserve_rows.jsonl',[r for r in reserves if r['id'] not in selected_ids and r['id'] not in flagged])
        dump(staged/'questions.json',questions());dump(staged/'nearest_pilot_screen.json',checks)
        dump(staged/'quality_report.json',metrics)
        (staged/'raw_authoring').mkdir()
        for name in AUTHOR_FILES:shutil.copyfile(author_dir/name,staged/'raw_authoring'/name)
        (staged/'record_index.csv').write_text('record_id,master_line,clef_line\n'+''.join(f'{r["id"]},{n},{n}\n' for n,r in enumerate(selected,1)))
        (staged/'quality_report.md').write_text('# Blind-authored v4 candidate challenge\n\n200 records, 50 per class, written and labelled by a separate agent without access to the pilot, generator or reviews. The same agent authored and labelled these cases. They remain unverified construction labels, not independent legal annotation.\n\nOne response was quarantined after the target-only similarity screen and replaced with a blind-authored reserve matching its D1-D6 stratum and history length. Three additional coverage replacements add ordinary-credit contexts with factual, general and personal targets. Original files, notes, all similarity matches and replacement identities are included.\n\nSee quality_report.json for exact counts, context-only baseline results and limitations. Context properties remain uneven by class. The simple pilot-trained context classifier is only one diagnostic. There are 50 cases per class, so class estimates remain imprecise.\n')
        dump(staged/'manifest.json',{
            'dataset_version':'blind_authored_challenge_v4', 'record_count':len(selected),
            'pilot_manifest_sha256':digest(pilot_path/'manifest.json'),
            'author_input_hashes':{name:digest(author_dir/name) for name in AUTHOR_FILES},
            'packager_sha256':digest(Path(__file__)),
            'provenance':{'author_agent':'blind_challenge_author','human_legal_reviewed':False,'independent_verifier':None},
            'files':{str(p.relative_to(staged)):digest(p) for p in sorted(staged.rglob('*')) if p.is_file() and p.name!='manifest.json'},
        })
        if output.exists():output.rmdir()
        staged.rename(output)
    return metrics


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pilot',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args()
    result=package(args.pilot,args.output)
    print(json.dumps({'records':result['records'],'classes':result['classes'],'output':args.output},indent=2))


if __name__=='__main__':main()
