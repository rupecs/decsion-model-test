"""Dataset-only repairs of the reviewed v2 pilot, preserving a record-level audit.

The original data and Claude review remain immutable. This is a local corrective
pass, not independent semantic/legal verification. Existing splits are explicitly
smoke/plumbing sets because template leakage cannot be repaired by relabelling.
"""
from collections import Counter,defaultdict
import copy
import csv
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import random
import re
from . import generator as G
from .schemas import ROOT,read_yaml,questions,validate,load_rows
from .pipeline import write_json,write_jsonl,sha,sample_reference
from .clef_converter import convert
from .splitter import assert_disjoint
from .coverage_report import normalize,input_key

VERSION='pilot-dataset-remediation-v3'


def unwrapped(row):
    text=row['agent_response']
    for opening in sorted(G.RESPONSE_OPENERS,key=len,reverse=True):
        if opening and text.startswith(opening):text=text[len(opening):];break
    for ending in sorted(G.RESPONSE_ENDINGS,key=len,reverse=True):
        if ending and text.endswith(ending):text=text[:-len(ending)];break
    return text


def mask_core(text):
    text=text.removeprefix('This is general information, not personal advice. ').casefold()
    for _,product,fact,goal,circ in G.PRODUCTS:
        text=text.replace(fact.casefold(),'')
        for value in (product,goal,circ,re.sub(r'\bI\b','you',circ).replace('my ','your ').replace(' am ',' are ')):
            text=text.replace(value.casefold(),'<SLOT>')
    return normalize(re.sub(r'\$[\d,.]+','<AMOUNT>',text))


def span(field,text,fragment):
    pos=text.index(fragment)
    return {'field':field,'start':pos,'end':pos+len(fragment),'text':fragment}


def clean_context(text):
    for request in G.GENERAL_REQUESTS:
        text=text.replace(request,'')
    text=text.replace('Only a general product view, please; do not assess my position.','Could you answer that part now?')
    text=re.sub(r' I am 52 and my balance is \$[\d,]+\. I only need the process explained\.','',text)
    for prefix in G.PREFIXES[1:]:
        if text.startswith(prefix):
            text=text[len(prefix):]
            break
    if text.startswith('Um, '):text=text[4:]
    # Also fix malformed starts inside role-marked multi-turn context.
    for prefix in G.PREFIXES[1:]:
        text=text.replace('CUSTOMER: '+prefix,'CUSTOMER: ')
    text=text.replace('CUSTOMER: Um, ','CUSTOMER: ')
    if text and text[0].islower():text=text[0].upper()+text[1:]
    text=re.sub(r'(CUSTOMER: )([a-z])',lambda m:m[1]+m[2].upper(),text)
    return '\n'.join(re.sub(' +',' ',s).strip() for s in text.splitlines()).strip()


def generic_context(row,sub):
    """No personal goal/balance paired with an allegedly generic recommendation."""
    product=row['metadata']['product_type']
    noun={'at_call_savings':'at-call savings accounts','term_deposit':'term deposits','managed_fund':'managed funds','superannuation':'superannuation funds','insurance':'income protection insurance','shares':'company shares'}[product]
    question=f'What is your view of {noun} as a product category?'
    # Preserve the call reason as a completed prior service topic, not an ignored request.
    topic=sub['id'].replace('_',' ')
    initial=f'That answers my question about {topic}. {question}'
    count={'single':1,'two_three':2,'four_plus':4}[row['metadata']['conversation_type']]
    if count==1:return initial
    turns=[('CUSTOMER',f'I have a question about {topic}.'),('AGENT',sub['fact'].format(amount='$10,000',interest='$400'))]
    if count>=4:
        turns.extend([('CUSTOMER','Does that describe the process, or choose a product for me?'),('AGENT','That explains the service process.'),('CUSTOMER',f'Could we also discuss {noun}?'),('AGENT','What would you like to know about that category?')])
    turns.append(('CUSTOMER',question))
    return '\n'.join(f'{role}: {text}' for role,text in turns)


def balanced_groups(rows,seed):
    """Keep source scenarios/families together; beam-search exact split capacities.

    Still smoke splits: response-pattern holdout is not claimed.
    """
    groups=defaultdict(list)
    for r in rows:groups[r['metadata']['source_template_id']].append(r)
    rng=random.Random(seed); keys=list(groups);rng.shuffle(keys)
    targets={'calibration':(50,30,40,30),'test':(50,30,40,30),'validation':(70,35,50,45)}
    result={}
    classes=G.CLASSES
    for name,target in targets.items():
        capacity=sum(target);states={0:[((0,0,0,0),())]}
        for key in keys:
            counts=Counter(r['labels']['D6'] for r in groups[key]);vector=tuple(counts[c] for c in classes);n=len(groups[key])
            additions=defaultdict(list)
            for used,options in list(states.items()):
                if used+n>capacity:continue
                additions[used+n].extend((tuple(a+b for a,b in zip(vec,vector)),chosen+(key,)) for vec,chosen in options)
            for used,new in additions.items():
                options=states.get(used,[])+new
                # Keep diverse candidates, score deviation from proportional target.
                unique={vec:(vec,chosen) for vec,chosen in options}
                score=lambda item:sum(abs(a-b*used/capacity) for a,b in zip(item[0],target))
                states[used]=sorted(unique.values(),key=score)[:32]
        feasible=[(vec,chosen) for vec,chosen in states.get(capacity,[]) if min(vec)>=30]
        if not feasible:raise ValueError(f'Cannot meet exact grouped {name} size and minimum 30 per class')
        vec,chosen=min(feasible,key=lambda item:sum(abs(a-b) for a,b in zip(item[0],target)))
        selected=set(chosen);result[name]=[r for key in keys if key in selected for r in groups[key]];keys=[key for key in keys if key not in selected]
    result['train']=[r for key in keys for r in groups[key]]
    assert_disjoint(result)
    return {k:result[k] for k in ('train','validation','calibration','test')}


def run(output,source=None,review=None,seed=3407):
    source=Path(source or ROOT/'data/generated/pilot_bootstrap_v2_final')
    review=Path(review or ROOT/'data/reviews/claude_pilot_review')
    out=Path(output)
    if out.exists():raise ValueError('Use a new output path; remediation never overwrites a dataset')
    original=load_rows(source)
    taxonomy=read_yaml(ROOT/'config/dataset/call_taxonomy.yaml')
    lookup={s['id']:s for c in taxonomy.values() for s in c['sub_intents']}
    affected=json.loads((review/'affected_ids.json').read_text())
    by_finding={k:set(v['ids']) for k,v in affected.items()}
    rows=[];audit=[];rng=random.Random(seed)
    # Allocate the request cue within every class, not from the target class alone.
    cue_ids=set()
    for cls in G.CLASSES:
        ids=[r['id'] for r in original if r['labels']['D6']==cls];rng.shuffle(ids)
        cue_ids.update(ids[:round(.3*len(ids))])
    for old in original:
        r=copy.deepcopy(old);m=r['metadata'];sub=lookup[m['sub_intent']];lab=r['labels'];changes=[]
        text=unwrapped(r);context=clean_context(r['customer_context'])
        if lab['D6']=='factual_information':
            scoped=sub['product_scope']=='in_scope'
            override=text.startswith('As a factual explanation,') or 'managed fund' in text and 'complaint record' in text
            lab['D1']=True if override else scoped
            m['product_scope_annotation']={'value':'in_scope' if lab['D1'] else 'out_of_scope','basis':sub['scope_basis'],'override':'explicit_product_in_target' if override else None,'independently_reviewed':False}
            if sub['id']=='international_transfer':
                context=context.replace('from my account','from my transaction account')
                text=text.replace('from your account','from your transaction account')
                changes.append('F03b: authored transaction-account scope explicitly')
            if sub['id']=='bonus_interest':text=text.replace('Bonus interest is','Savings-account bonus interest is')
            if sub['id']=='available_balance':text=text.replace('Available balance','The available balance on your savings account')
            if sub['id']=='transaction_description':text=text.replace('on a statement','on a debit-account statement')
            if sub['id']=='pending_card_payment':text=text.replace('A pending card payment','A pending debit-card payment on your transaction account')
        if lab['D6']=='general_advice':
            context=generic_context(r,sub)
            changes.append('F06/F07: removed disclosed personal circumstances from general-advice context')
        if r['id'] in by_finding['F04_refusal_ambiguous']:
            product=next((p[1] for p in G.PRODUCTS if p[1] in text),'that financial product')
            text=f'I am unable to give an opinion on whether {product} suits you.'
            changes.append('F04: rewritten as inability to provide an opinion, without suitability judgement')
        if r['id'] in by_finding['F05_expected_only_amount_d3']:
            # This pass rewrites the contested observable basis rather than asserting
            # that Claude resolved the legal question about the original wording.
            product=next(p[1] for p in G.PRODUCTS if p[1] in text)
            text=f'{product[0].upper()+product[1:]} is the option I would choose for you.'
            lab['D3']=False;lab['D4']=True
            m['mixed_content']=False
            changes.append('F05: removed amount-directed instruction from expectation-only target')
        if lab['D2'] and 'time frame you described' in text:
            text=text.replace('needs and time frame you described','needs you described')
            changes.append('F15: removed unsupported time-frame assertion')
        if m['product_type']=='shares' and lab['D2']:
            for _,_,fact,_,_ in G.PRODUCTS:
                if text.startswith(fact+' '):text=text[len(fact)+1:]
            m['mixed_content']=False
            changes.append('F15: removed facts about a different product')
        if lab['D6']=='other' and m['call_category'] in ('C10','C11','C12'):
            # Credit-only discussion is responsive and contains no procedural claim.
            topic={'C10':'the credit question','C11':'the payment difficulty','C12':'the overdue repayment'}[m['call_category']]
            text=f'I understand. Which part of {topic} would you like to discuss first?'
            lab.update(D1=False,D2=False,D3=False,D4=False,D5=False)
            m['separate_conduct_review']='No credit product recommendation is being made in this revised clarification.'
            changes.append('F13: removed unsupported credit recommendation; retained other as clarification')
        # Disclaimers are not pasted onto acknowledgments, complaints or case notes.
        if not lab['D2'] or 'complaint record' in text:
            text=text.removeprefix('This is general information, not personal advice. ')
        if r['id'] in cue_ids:
            context+=' '+rng.choice(G.GENERAL_REQUESTS)
        # Restore sentence case after comma-bearing old wrappers by removing them,
        # rather than adding wording solely to obtain exact-string uniqueness.
        r['customer_context']=context;r['agent_response']=text
        m['response_body']=text;m['legacy_difficulty_requested_random']=m.pop('difficulty',None)
        m['difficulty']='complex' if m['conversation_type']=='four_plus' or m.get('exception_context') else ('boundary' if lab['D4'] or m.get('mixed_content') else 'straightforward')
        m['difficulty_basis']='Content heuristic (turn count/exception/personalisation), not a legal-review judgement'
        m['context_dependent']=None;m['context_dependence_status']='not_validated_by_ablation'
        m['legacy_contrastive']=m.pop('contrastive');m['contrastive']=False
        m['contrastive_status']='Legacy family is not a controlled minimal pair'
        m['legacy_recommendation_style']=m.pop('recommendation_style')
        m['request_general_present']=r['id'] in cue_ids
        m['voice_style']=False;m['asr_imperfections']=False
        m['disclaimer']=text.startswith('This is general information, not personal advice. ')
        m['personalisation']='actual_and_expected' if lab['D3'] else ('reasonable_expectation_only' if lab['D4'] else 'not_applicable')
        m['annotation_status']='bootstrap_corrected_pending_review'
        m['evaluation_role']='plumbing_only_template_overlap_remains'
        if lab['D2'] and m['call_category'] in ('C03','C11','C17','C18'):
            m['scenario_purpose']='deliberate_advice_in_sensitive_call_edge_case_not_typical_traffic'
        ann=m['annotation'];ann.update(generator=VERSION,annotator='local_dataset_remediation',verifier=None,status=m['annotation_status'],human_reviewed=False,independent_teacher_verified=False)
        ann['legal_references']=['Corporations Act 2001 ss763A,764A,765A,766B','ASIC RG244.24–244.49']
        m['remediation']={'source_version':'pilot-bootstrap-v2','source_record_id':r['id'],'source_line':int(r['id'].split('_')[1]),'version':VERSION,'human_legal_reviewed':False,'original_findings':[k for k,ids in by_finding.items() if r['id'] in ids]}
        m['legacy_boundaries']=m.pop('boundaries');m['boundaries']=[]
        m['boundary_status']='Legacy tags removed; need evidence-backed case annotations'
        r['evidence']={}
        if lab['D2']:r['evidence']['D2_target']=span('agent_response',text,text)
        if lab['D3']:r['evidence']['D3_target']=span('agent_response',text,text)
        if lab['D4']:
            basis=next((p[4] for p in G.PRODUCTS if p[4] in context),context)
            r['evidence']['D4_context']=span('customer_context',context,basis)
        if lab['D1']:
            phrases=('savings account','transaction account','debit card','term deposit','managed fund','superannuation','insurance','company share','travel money card','deposit account')
            for field in ('agent_response','customer_context'):
                found=next((s for s in phrases if s in r[field].casefold()),None)
                if found:
                    pos=r[field].casefold().index(found)
                    r['evidence']['D1_product']=span(field,r[field],r[field][pos:pos+len(found)])
                    break
        if lab['D5']:r['evidence']['D5_target']=span('agent_response',text,text)
        m['evidence_status']='Decision-specific fields; span semantic sufficiency still requires independent review'
        if old['labels']!=lab:changes.append('D1: explicit product-scope correction' if old['labels']['D1']!=lab['D1'] else 'atomic_label_change')
        validate(r)
        audit.append({'record_id':r['id'],'source_line':m['remediation']['source_line'],'new_line':len(rows)+1,'changes':changes,'old_labels':old['labels'],'new_labels':dict(lab),'context_changed':old['customer_context']!=context,'response_changed':old['agent_response']!=text,'old_record_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest()})
        rows.append(r)
    # Expose and quarantine repetition instead of making identical records appear
    # unique through greetings or arbitrary numeric identifiers.
    first_by_input={};deduplicated=[];quarantined=[]
    for r in rows:
        key=input_key(r);first=first_by_input.get(key)
        r['metadata']['duplicate_input_of']=first
        r['metadata']['included_in_deduplicated_candidates']=first is None
        if first is None:
            first_by_input[key]=r['id'];deduplicated.append(r)
        else:
            quarantined.append({'record_id':r['id'],'duplicate_of':first,'reason':'Exact normalized input duplication after removing wording wrappers','record':r})
    splits=balanced_groups(rows,seed)
    out.mkdir(parents=True)
    for name,group in splits.items():
        for r in group:r['metadata']['split']=name
        write_jsonl(out/'splits'/f'{name}.jsonl',group)
        write_jsonl(out/'clef'/f'{name}.jsonl',[convert(r) for r in group])
    write_jsonl(out/'master_dataset.jsonl',rows);write_json(out/'questions.json',questions())
    write_jsonl(out/'deduplicated_candidates.jsonl',deduplicated)
    write_jsonl(out/'quarantined_duplicates.jsonl',quarantined)
    write_jsonl(out/'remediation_audit.jsonl',audit)
    cores=Counter(mask_core(r['agent_response']) for r in rows)
    split_cores={s:{mask_core(r['agent_response']) for r in group} for s,group in splits.items()}
    original_classes=Counter(r['labels']['D6'] for r in original);classes=Counter(r['labels']['D6'] for r in rows)
    assert original_classes==classes
    classcue={c:{'total':classes[c],'general_request':sum(r['metadata']['request_general_present'] for r in rows if r['labels']['D6']==c)} for c in G.CLASSES}
    scope_change=[a for a in audit if a['old_labels']['D1']!=a['new_labels']['D1']]
    all_byid={r['id']:r for r in rows}
    confirmed=by_finding['F01_d1_password_reset_regex']|by_finding['F02_d1_keyword_false_negative']
    confirmed_remaining=[key for key in confirmed if all_byid[key]['labels']['D1']==next(a['old_labels']['D1'] for a in audit if a['record_id']==key)]
    if confirmed_remaining:raise ValueError('Confirmed D1 repairs incomplete')
    summary={'version':VERSION,'records':len(rows),'classes':dict(classes),'D1_changes':len(scope_change),'confirmed_D1_errors_corrected':len(confirmed),'confirmed_D1_errors_remaining':len(confirmed_remaining),'ambiguous_refusals_rewritten':len(by_finding['F04_refusal_ambiguous']),'amount_directed_D3_cases_rewritten':len(by_finding['F05_expected_only_amount_d3']),'general_request_cue_by_class':classcue,'split_classes':{s:dict(Counter(r['labels']['D6'] for r in rs)) for s,rs in splits.items()},'split_categories':{s:dict(Counter(r['metadata']['call_category'] for r in rs)) for s,rs in splits.items()},'split_counts':{s:len(rs) for s,rs in splits.items()},'unique_masked_cores':len(cores),'heldout_records_with_core_seen_in_train':{s:sum(mask_core(r['agent_response']) in split_cores['train'] for r in splits[s]) for s in ('validation','calibration','test')},'exact_duplicate_responses':len(rows)-len({normalize(r['agent_response']) for r in rows}),'deduplicated_candidate_count':len(deduplicated),'quarantined_duplicate_count':len(quarantined),'deduplicated_classes':dict(Counter(r['labels']['D6'] for r in deduplicated)),'notes':['No uniqueness wrappers were added; response repetition is exposed instead of hidden.','All four legacy-derived splits remain plumbing sets, not independent evaluations.','No external teacher, embedding screen or human legal review.','Training-related review comments were excluded from this work.']}
    write_json(out/'dataset_remediation_report.json',summary)
    sample_reference(rows,out)
    lines=['# Dataset-only remediation v3','','The reviewed v2 pilot remains unchanged. No training code was changed.','',f"Records: {len(rows)}; confirmed D1 errors corrected: {len(confirmed)}; total D1 changes: {len(scope_change)}.",'',f"There are {len(deduplicated)} distinct input candidates. {len(quarantined)} duplicate inputs are quarantined separately. master_dataset.jsonl preserves all 2,000 corrected source records for audit; deduplicated_candidates.jsonl is the distinct candidate subset. Do not mistake the 2,000-row audit corpus for 2,000 distinct scenarios.",'',f"Ambiguous refusals rewritten: {summary['ambiguous_refusals_rewritten']}; amount-directed D3 cases rewritten: {summary['amount_directed_D3_cases_rewritten']}.",'','All 350 general-advice contexts were rewritten without disclosed personal circumstances. General-request phrases are now assigned at 30% within every class; they no longer identify the general-advice class. This removes the specific cue, not every possible statistical shortcut.','','Greeting/ending uniqueness wrappers and the factual-only age/balance cue were removed. Identical substantive responses are retained visibly rather than disguised with filler. Unsupported credit advice was replaced by non-advisory clarification. Difficulty is a content heuristic; old random settings are identified as legacy. Legacy uncontrolled contrasts and unvalidated context-dependence claims are not carried forward as validated coverage.','','Grouped audit split sizes remain 1500/200/150/150, with at least 30 examples of each class in validation, calibration and test. These counts apply before duplicate quarantine. Core-template reuse is measured and remains a blocker for independent evaluation. Every audit split is explicitly marked plumbing-only.','','The separate challenge candidates use a new authored case bank. They are not independently authored or legally verified, and are not evidence of regulatory performance.','','See dataset_remediation_report.json and remediation_audit.jsonl for counts and record-level changes. Remaining work includes independent case annotation, human review of legal boundaries, real conversational diversity, semantic leakage screening and ablation-validated long contexts.','']
    (out/'dataset_remediation_report.md').write_text('\n'.join(lines))
    write_json(out/'manifest.json',{'version':VERSION,'generated_at_utc':datetime.now(timezone.utc).isoformat(),'source_master_sha256':sha(source/'master_dataset.jsonl'),'source_review_sha256':sha(review/'errors.csv'),'scope':'dataset_only_no_training_changes','record_count':len(rows),'provenance':{'generator':VERSION,'independent_verifier':None,'human_legal_reviewed':False},'files':{str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}})
    return summary
