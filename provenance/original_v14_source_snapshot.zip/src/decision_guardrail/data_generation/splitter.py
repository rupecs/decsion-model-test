"""Exact capacity subset-sum assignment, grouping complete source scenarios."""
from collections import defaultdict
import random


def split(rows, sizes, seed):
    if sum(sizes.values()) != len(rows):
        raise ValueError('Split total mismatch')
    groups = defaultdict(list)
    for row in rows:
        groups[row['metadata']['source_template_id']].append(row)
    keys = sorted(groups)
    random.Random(seed).shuffle(keys)
    result = {}
    # Small heldout capacities first; bounded subset sum avoids greedy dead ends.
    for name in sorted(sizes, key=sizes.get):
        target = sizes[name]
        reachable = {0:[]}
        for key in keys:
            n = len(groups[key])
            for old, chosen in list(reachable.items()):
                if old+n <= target and old+n not in reachable:
                    reachable[old+n] = chosen + [key]
            if target in reachable:
                break
        if target not in reachable:
            raise ValueError(f'Source groups cannot fill exact {name} capacity {target}')
        chosen = set(reachable[target])
        result[name] = [r for k in keys if k in chosen for r in groups[k]]
        keys = [k for k in keys if k not in chosen]
    assert not keys
    assert_disjoint(result)
    return {k:result[k] for k in sizes}


def assert_disjoint(splits):
    for field in ('scenario_family_id', 'source_template_id'):
        used = set()
        for rows in splits.values():
            keys = {r['metadata'][field] for r in rows}
            if used & keys:
                raise ValueError(f'{field} leaks across splits')
            used |= keys
