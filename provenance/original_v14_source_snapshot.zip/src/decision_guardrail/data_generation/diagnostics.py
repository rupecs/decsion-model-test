"""Cheap leakage/shortcut diagnostics, unrelated to student model training."""
from collections import Counter
import json
import math
from pathlib import Path
import re
from .schemas import load_rows,CLASSES
from .pipeline import write_json


def nb_fit(rows,field):
    counts={c:Counter() for c in CLASSES};prior=Counter()
    tokens=lambda s:re.findall(r"[a-z']+",s.casefold())
    for r in rows:
        c=r['labels']['D6'];prior[c]+=1;counts[c].update(tokens(r[field]))
    vocabulary={w for counter in counts.values() for w in counter}
    totals={c:sum(counter.values()) for c,counter in counts.items()}
    def predict(row):
        return max(CLASSES,key=lambda c:math.log(prior[c]+1)+sum(math.log((counts[c][w]+1)/(totals[c]+len(vocabulary))) for w in tokens(row[field])))
    return predict


def run(pilot,challenge,output):
    pilot=Path(pilot);tr=load_rows(pilot/'splits/train.jsonl')
    sets={s:load_rows(pilot/'splits'/f'{s}.jsonl') for s in ('validation','calibration','test')}
    sets['challenge_candidates']=load_rows(Path(challenge)/'master_dataset.jsonl')
    result={'kind':'Dataset shortcut diagnostic only; not Gemma training or performance validation','fit_rows':len(tr),'features':{}}
    for field in ('customer_context','agent_response'):
        predict=nb_fit(tr,field)
        result['features'][field]={}
        for name,rs in sets.items():
            correct=sum(predict(r)==r['labels']['D6'] for r in rs)
            majority=max(Counter(r['labels']['D6'] for r in rs).values())/len(rs)
            result['features'][field][name]={'correct':correct,'n':len(rs),'accuracy':round(correct/len(rs),4),'majority_baseline':round(majority,4)}
    result['interpretation']='High development scores can still reflect shared templates and class cues. Candidate challenge scores have not been calibrated against independent legal labels. No threshold is treated as proof of suitability.'
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    write_json(output,result)
    return result
