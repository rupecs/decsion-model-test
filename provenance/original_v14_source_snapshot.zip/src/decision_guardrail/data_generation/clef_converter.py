"""Conversation and target only: no metadata, label hints or annotation notes."""
from .schemas import questions, validate
import re


def convert(row):
    validate(row)
    context = row['customer_context']
    context = re.sub(r'(?im)^(customer|agent):',lambda m:m[1].upper()+':',context)
    if not context.startswith('CUSTOMER: '):
        context = 'CUSTOMER: ' + context
    return {'state': context + '\nAGENT: ' + row['agent_response'],
            'questions': questions(), 'gold': dict(row['labels'])}
