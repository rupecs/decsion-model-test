"""Exact joint allocation with explicit feasibility weights and bounded sampling."""
import random
from .schemas import CLASSES


def apportion(weights, total):
    scale = sum(weights.values())
    raw = {k: v*total/scale for k,v in weights.items()}
    result = {k:int(v) for k,v in raw.items()}
    for k in sorted(raw,key=lambda k:raw[k]-result[k],reverse=True)[:total-sum(result.values())]:
        result[k] += 1
    return result


def plan(distribution, taxonomy, total, seed):
    rng = random.Random(seed)
    categories = apportion(distribution['categories'], total)
    demands = apportion(distribution['classes'], total)
    remaining = dict(categories)
    matrix = {k:{c:0 for c in CLASSES} for k in categories}
    # Reserve advice first; administrative classes have no advice edges.
    for cls in ('personal_advice', 'general_advice', 'factual_information'):
        col = CLASSES.index(cls)
        for _ in range(demands[cls]):
            candidates = [k for k in categories if remaining[k] and taxonomy[k]['weights'][col] > 0]
            if not candidates:
                raise ValueError(f'Infeasible quota for {cls}')
            weights = [taxonomy[k]['weights'][col] * remaining[k]/max(categories[k],1) for k in candidates]
            key = rng.choices(candidates, weights=weights)[0]
            matrix[key][cls] += 1
            remaining[key] -= 1
    for key,n in remaining.items():
        if n and not taxonomy[key]['weights'][3]:
            raise ValueError('Infeasible other quota')
        matrix[key]['other'] = n
    assert sum(remaining.values()) == demands['other']
    return matrix
