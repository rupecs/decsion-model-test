"""Replay frozen context v13 in its publication-era input/review inventory.

V14 intentionally retains exact unexposed v13 rows. V13's original history scan
has no chronology field and otherwise mistakes that future retention for older
input reuse. This tool preserves every old check in an isolated hard-link view;
it never removes or edits live reviews, releases or policies.
"""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import re
import tempfile


@contextmanager
def historical_root(root: Path):
    pinned=json.loads((root/'data/reviews/dialogue_exposure_ledger_v2.json').read_text())
    with tempfile.TemporaryDirectory(dir=root/'outputs',prefix='historical-v13-') as temp:
        snapshot=Path(temp)
        def link(source):
            target=snapshot/source.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True)
            if not target.exists():os.link(source,target)
        for directory in ('src','scripts','config','docs','data/generated','data/authored','data/authoring'):
            for source in (root/directory).rglob('*'):
                if not source.is_file() or '__pycache__' in source.parts:continue
                if directory=='data/generated':
                    match=re.search(r'context_v(\d+)',str(source.relative_to(root)))
                    if match and int(match.group(1))>13:continue
                link(source)
        for name in pinned['review_files']:link(root/name)
        for name in ('dialogue_exposure_ledger_v1.json','dialogue_exposure_ledger_v2.json'):
            link(root/'data/reviews'/name)
        for source in (root/'outputs/context_v13_final_20261025/pack08').iterdir():
            if source.is_file():link(source)
        yield snapshot


if __name__=='__main__':
    from decision_guardrail.data_generation.context_v13_release import verify
    root=Path(__file__).resolve().parents[1]
    with historical_root(root) as snapshot:
        result=verify(snapshot,snapshot/'data/generated/streaming_context_v13_release')
        print(json.dumps(dict(version='v13',historical_validation_passed=True,records=result['records'],
            live_resources_modified=False,scope='Publication-era source inventory, not a current training approval')))
