"""Run the post-v11 construction gates without changing a frozen release."""
import argparse
import hashlib
import json
from pathlib import Path

from decision_guardrail.data_generation.dialogue_release_audit import audit, read_jsonl, reviewed_designs
from decision_guardrail.data_generation.dialogue_exposure import exposure_hits

from decision_guardrail.data_generation.dialogue_exposure_policy import load_policy


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exposure-policy", type=Path, help="Versioned policy; defaults to the current dataset pointer")
    parser.add_argument("--records", type=Path, required=True)
    parser.add_argument("--review-records", type=Path, action="append", default=[])
    parser.add_argument("--review-source-records", type=Path, action="append", default=[],
                        help="Unfiltered records from the release the reviewer actually read")
    parser.add_argument("--binding-ledger", type=Path)
    parser.add_argument("--designs", type=Path, help="Authored design registry for content-bound exposure checks")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = read_jsonl(args.records)
    if len(args.review_records) != len(args.review_source_records):
        parser.error("Pair each review file with its full reviewed source")
    root = Path(__file__).resolve().parents[1]
    cumulative = load_policy(root, args.exposure_policy)
    reviewed = set(cumulative["reviewed_design_ids"])
    for review, source in zip(args.review_records, args.review_source_records, strict=True):
        records = read_jsonl(review)
        if not records:
            parser.error("Review exposure must not be silently replaced by an empty ledger")
        reviewed.update(reviewed_designs(read_jsonl(source), records))
    ledger = json.loads(args.binding_ledger.read_text()) if args.binding_ledger else None
    report = audit(rows, reviewed, ledger)
    hits = exposure_hits(rows, cumulative, read_jsonl(args.designs) if args.designs else None)
    report["cumulative_exposure_hits"] = hits
    report["cumulative_review_files"] = sorted(cumulative["review_files"])
    report["cumulative_ledger_sha256"] = cumulative["ledger_sha256"]
    if hits:
        report["failures"].append(dict(check="cumulative_review_exposure", actual=len(hits)))
        report["construction_gate_passed"] = False
    inputs = dict(records=args.records, cumulative_ledger=root / cumulative["ledger_path"],
                  exposure_policy=root / cumulative["policy_path"])
    for i, (review, source) in enumerate(zip(args.review_records, args.review_source_records, strict=True)):
        suffix = "" if i == 0 else f"_{i+1}"
        inputs["review_records" + suffix] = review
        inputs["reviewed_source" + suffix] = source
    if args.designs:
        inputs["designs"] = args.designs
    if args.binding_ledger:
        inputs["binding_ledger"] = args.binding_ledger
    report["input_files"] = {key: dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
                             for key, path in inputs.items()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({k: report[k] for k in ("records", "construction_gate_passed", "training_ready", "failures")}, indent=2))
    return 0 if report["construction_gate_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
